#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
security_scan.py — pre-deploy automated security scanner for the Zion Login
integrated guide (stage 04).

Purpose: automatically judge the machine-checkable items of
    04_predeploy_verification.md and emit a report for HQ submission
    (JSON + Markdown, including a code fingerprint). The remaining items
    that require code comprehension (permission logic, audit, IDOR, ...)
    are judged by the AI.

Principles:
- Standard library only (no installation; works on Windows/Mac/Linux).
- Never write real values or secrets into the report (evidence is masked
  as [REDACTED]).
- Five verdicts: PASS/FAIL/NEEDINPUT/WARN/SKIP. NEEDINPUT means a required
  input (e.g. Supabase RLS probe credentials) was missing; WARN/SKIP are
  finalized by the AI or a human.

Usage:
  python security_scan.py --root .                 # static scan from project root
  python security_scan.py --root . --deploy-url https://myapp.example.com
  python security_scan.py --root . --supabase-url https://xxx.supabase.co \
         --supabase-key <ANON_KEY> --supabase-table members   # live RLS probe
  python security_scan.py --root . --out-dir ./outputs         # report location
Exit code: 0 = no FAIL/NEEDINPUT, 1 = one or more FAIL or NEEDINPUT
(critical verdicts are finalized by the AI).
"""

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.request
import urllib.error
from datetime import datetime, timezone

SCANNER_VERSION = "1.0.2"

# ── Scan targets / exclusions ─────────────────────────────────
CODE_EXT = {".py", ".js", ".ts", ".jsx", ".tsx", ".vue", ".svelte", ".go",
            ".rb", ".php", ".java", ".kt", ".cs", ".html", ".htm", ".sql",
            ".env.example", ".yml", ".yaml", ".toml", ".cfg", ".ini", ".sh"}
# .claude is skipped so this skill's own guide files (which quote the very
# patterns we grep for, e.g. JWT_SECRET / /oauth2/) never self-flag the scan.
SKIP_DIRS = {".git", "node_modules", "dist", "build", ".next", ".nuxt",
             ".svelte-kit", "venv", ".venv", "__pycache__", "coverage",
             ".mypy_cache", ".pytest_cache", "vendor", ".idea", ".vscode",
             ".claude", "zion-login-integrated"}
CLIENT_DIRS = {"public", "static", "client", "frontend", "www", "assets"}
MAX_FILE_BYTES = 2_000_000
PLACEHOLDER_HINTS = ("your", "xxx", "placeholder", "example", "changeme",
                     "<", "${", "여기", "자리표시", "todo", "dummy", "sample")


def mask(s, keep=4):
    s = str(s)
    if len(s) <= keep:
        return "[REDACTED]"
    return s[:keep] + "…[REDACTED]"


def is_placeholder(val):
    v = val.strip().strip('"').strip("'")
    if v == "" or len(v) < 8:
        return True
    low = v.lower()
    return any(h in low for h in PLACEHOLDER_HINTS)


def iter_source_files(root):
    self_path = os.path.abspath(__file__)
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            ext = os.path.splitext(fn)[1].lower()
            special = fn.lower() in (".env.example", ".gitignore")
            if ext in CODE_EXT or special:
                fp = os.path.join(dirpath, fn)
                if os.path.abspath(fp) == self_path:
                    continue
                try:
                    if os.path.getsize(fp) > MAX_FILE_BYTES:
                        continue
                except OSError:
                    continue
                yield fp


def read_text(fp):
    try:
        with open(fp, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except OSError:
        return ""


def rel(root, fp):
    try:
        return os.path.relpath(fp, root).replace("\\", "/")
    except ValueError:
        return fp


def under_client_dir(relpath):
    parts = relpath.split("/")
    return any(p in CLIENT_DIRS for p in parts[:-1]) or relpath.endswith((".html", ".htm"))


# ── Verdict container ─────────────────────────────────────────
class Result:
    def __init__(self):
        self.findings = []  # {id, vc, name, status, evidence}

    def add(self, cid, vc, name, status, evidence):
        self.findings.append({"id": cid, "vc": vc, "name": name,
                              "status": status, "evidence": evidence})

    def counts(self):
        c = {"PASS": 0, "FAIL": 0, "NEEDINPUT": 0, "WARN": 0, "SKIP": 0}
        for f in self.findings:
            c[f["status"]] = c.get(f["status"], 0) + 1
        return c


# ── HTTP probe ────────────────────────────────────────────────
def http_status(url, timeout=8):
    req = urllib.request.Request(url, headers={"User-Agent": "zion-scan/1.0",
                                               "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read(4096)
    except urllib.error.HTTPError as e:
        return e.code, b""
    except Exception as e:  # noqa
        return None, str(e).encode()


def git_remote(root):
    try:
        out = subprocess.run(["git", "-C", root, "remote", "get-url", "origin"],
                             capture_output=True, text=True, timeout=10)
        if out.returncode == 0:
            return out.stdout.strip()
    except Exception:  # noqa
        pass
    return ""


def git_head(root):
    try:
        out = subprocess.run(["git", "-C", root, "rev-parse", "HEAD"],
                             capture_output=True, text=True, timeout=10)
        if out.returncode == 0:
            return out.stdout.strip()
    except Exception:  # noqa
        pass
    return "no-git"


def normalize_remote(url):
    """SSH/HTTPS remote → (host, owner, repo). (None, None, None) on failure."""
    url = url.strip()
    m = re.match(r"git@([^:]+):([^/]+)/(.+?)(?:\.git)?$", url)
    if m:
        return m.group(1), m.group(2), m.group(3)
    m = re.match(r"https?://(?:[^@/]+@)?([^/]+)/([^/]+)/(.+?)(?:\.git)?$", url)
    if m:
        return m.group(1), m.group(2), m.group(3)
    return None, None, None


# ── Checks ────────────────────────────────────────────────────
def check_repo_visibility(root, res):
    remote = git_remote(root)
    if not remote:
        res.add("VC3", "VC3/E5", "저장소 공개 여부(레포 private)", "SKIP",
                "git remote(origin) 없음 → 배포처 소스공개 여부를 수동 확인 필요")
        return
    host, owner, repo = normalize_remote(remote)
    if not host:
        res.add("VC3", "VC3/E5", "저장소 공개 여부(레포 private)", "WARN",
                f"remote 형식 파싱 실패: {mask(remote,10)} → 수동 실측")
        return
    # Judge public visibility via the host's API (unauthenticated)
    if "github.com" in host:
        api = f"https://api.github.com/repos/{owner}/{repo}"
    elif "gitlab" in host:
        api = f"https://{host}/api/v4/projects/{owner}%2F{repo}"
    else:
        api = f"https://{host}/{owner}/{repo}"
    status, _ = http_status(api)
    if status == 200:
        res.add("VC3", "VC3/E5", "저장소 공개 여부(레포 private)", "FAIL",
                f"{host}/{owner}/{repo} 비인증 접근 200(공개) → private 전환 + 커밋 비밀값 유출 간주(재발급)")
    elif status == 404:
        res.add("VC3", "VC3/E5", "저장소 공개 여부(레포 private)", "PASS",
                f"{host}/{owner}/{repo} 비인증 404(비공개/없음)")
    elif status in (401, 403, 429):
        res.add("VC3", "VC3/E5", "저장소 공개 여부(레포 private)", "WARN",
                f"상태 {status}(rate limit/인증) → 잠시 후 재시도 또는 로그아웃 창으로 수동 확인")
    else:
        res.add("VC3", "VC3/E5", "저장소 공개 여부(레포 private)", "WARN",
                f"상태 {status} → 수동 확인 필요")


def check_git_config_exposure(root, res, deploy_url):
    if not deploy_url:
        res.add("VC3b", "VC3", "배포 URL의 /.git/config 노출", "SKIP",
                "--deploy-url 미제공 → 정적 배포면 수동 확인")
        return
    url = deploy_url.rstrip("/") + "/.git/config"
    status, _ = http_status(url)
    if status == 200:
        res.add("VC3b", "VC3", "배포 URL의 /.git/config 노출", "FAIL",
                f"{mask(deploy_url,20)}/.git/config 200 → 소스 전체 유출(치명)")
    else:
        res.add("VC3b", "VC3", "배포 URL의 /.git/config 노출", "PASS",
                f"/.git/config 상태 {status}(노출 아님)")


def _find_named(root, name, max_depth=2):
    # Monorepo layouts keep these per sub-project (backend/.gitignore etc.),
    # so look a couple of levels deep, not only at the root.
    found = []
    root = os.path.abspath(root)
    for dirpath, dirnames, filenames in os.walk(root):
        rel = os.path.relpath(dirpath, root)
        depth = 0 if rel == "." else rel.count(os.sep) + 1
        if depth >= max_depth:
            dirnames[:] = []
        else:
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        if name in filenames:
            found.append(os.path.join(dirpath, name))
    return found


def check_gitignore_env(root, res):
    gis = _find_named(root, ".gitignore")
    if not gis:
        res.add("VC2a", "VC2/G1", ".gitignore에 .env 포함", "FAIL",
                ".gitignore 없음 → .env가 커밋될 위험")
        return
    for gi in gis:
        lines = [ln.strip() for ln in read_text(gi).splitlines()]
        if any(re.fullmatch(r"\*?\.env\*?", ln) or ln == ".env" for ln in lines):
            res.add("VC2a", "VC2/G1", ".gitignore에 .env 포함", "PASS",
                    f".gitignore가 .env 무시({os.path.relpath(gi, root)})")
            return
    res.add("VC2a", "VC2/G1", ".gitignore에 .env 포함", "FAIL",
            ".gitignore에 .env 규칙 없음 → 추가 필요")


def check_env_example(root, res):
    exs = _find_named(root, ".env.example")
    if not exs:
        res.add("VC2b", "VC2/D9", ".env.example 자리표시자만", "WARN",
                ".env.example 없음 → 자리표시자 예시 파일 제공 권장")
        return
    leaks = []
    for ex in exs:
        rel = os.path.relpath(ex, root)
        for i, ln in enumerate(read_text(ex).splitlines(), 1):
            if "=" in ln and not ln.strip().startswith("#"):
                k, _, v = ln.partition("=")
                v = v.split("#")[0].strip()
                if v.startswith(("http://", "https://")) and "ziongroup.net" in v:
                    continue  # canonical Zion endpoint URL, not a secret
                if v and not is_placeholder(v) and re.search(r"[A-Za-z0-9_\-]{12,}", v):
                    leaks.append(f"{rel}:L{i}:{k.strip()}={mask(v)}")
    if leaks:
        res.add("VC2b", "VC2/D9", ".env.example 자리표시자만", "FAIL",
                "실제 값으로 보이는 항목: " + "; ".join(leaks[:5]))
    else:
        res.add("VC2b", "VC2/D9", ".env.example 자리표시자만", "PASS",
                "자리표시자/빈값만 확인")


def _grep(files_texts, pattern, flags=0):
    rx = re.compile(pattern, flags)
    hits = []
    for relpath, txt in files_texts:
        for i, ln in enumerate(txt.splitlines(), 1):
            if rx.search(ln):
                hits.append((relpath, i, ln.strip()))
    return hits


def check_hardcoded_secrets(files_texts, res):
    # Reading via os.getenv/process.env is fine; catch only literal assignments.
    secret_name = r"(client[_-]?secret|api[_-]?key|access[_-]?token|" \
                  r"secret[_-]?key|password|passwd|oauth2?[_-]?client[_-]?id|client[_-]?id)"
    pat = re.compile(
        secret_name + r"""\s*[:=]\s*["']([^"']{8,})["']""", re.IGNORECASE)
    hits = []
    for relpath, txt in files_texts:
        for i, ln in enumerate(txt.splitlines(), 1):
            if "getenv" in ln or "process.env" in ln or "os.environ" in ln:
                continue
            m = pat.search(ln)
            if m and not is_placeholder(m.group(2)):
                hits.append(f"{relpath}:L{i} {m.group(1)}={mask(m.group(2))}")
    if hits:
        res.add("VC1", "VC1/G1/D9", "하드코딩된 비밀값/자격증명", "FAIL",
                "리터럴 대입 발견: " + "; ".join(hits[:6]))
    else:
        res.add("VC1", "VC1/G1/D9", "하드코딩된 비밀값/자격증명", "PASS",
                "코드 내 비밀값 리터럴 대입 없음(env 로드로 판단)")


def check_jwt_secret(files_texts, res):
    hits = _grep(files_texts, r"JWT_SECRET")
    hits = [h for h in hits if "없" not in h[2] and "no " not in h[2].lower()
            and "not" not in h[2].lower() and "금지" not in h[2]]
    if hits:
        loc = "; ".join(f"{r}:L{i}" for r, i, _ in hits[:6])
        res.add("D2", "D2/하드룰2", "자체 JWT(JWT_SECRET) 부재", "FAIL",
                f"JWT_SECRET 사용 정황({loc}) → 이 에디션은 자체 토큰 금지(세션=시온 access_token)")
    else:
        res.add("D2", "D2/하드룰2", "자체 JWT(JWT_SECRET) 부재", "PASS",
                "JWT_SECRET 사용 정황 없음")


def check_oauth_path(files_texts, res):
    hits = _grep(files_texts, r"/oauth2/")
    # Guide-style comments quote the wrong path to warn against it
    # ("path is /oauth/, NOT /oauth2/") — a real misuse has no negation.
    hits = [h for h in hits if "not" not in h[2].lower() and "아님" not in h[2]
            and "금지" not in h[2] and "/oauth/" not in h[2]]
    if hits:
        loc = "; ".join(f"{r}:L{i}" for r, i, _ in hits[:6])
        res.add("PATH1", "자주틀리는값", "OAuth 경로 /oauth/ (NOT /oauth2/)", "FAIL",
                f"/oauth2/ 발견({loc}) → 경로는 /oauth/ 여야 함(로그인 실패 주범)")
    else:
        res.add("PATH1", "자주틀리는값", "OAuth 경로 /oauth/ (NOT /oauth2/)", "PASS",
                "/oauth2/ 오용 없음")


def check_userinfo_version(files_texts, res):
    hits = _grep(files_texts, r"v2_0/me")
    if hits:
        loc = "; ".join(f"{r}:L{i}" for r, i, _ in hits[:6])
        res.add("API1", "api-catalog", "회원조회 v3_0/me 사용(v2_0 금지)", "FAIL",
                f"v2_0/me 발견({loc}) → v3_0/me 사용")
    else:
        res.add("API1", "api-catalog", "회원조회 v3_0/me 사용(v2_0 금지)", "PASS",
                "v2_0/me 사용 없음")


def check_member_ceiling(files_texts, res):
    banned = r"\b(MOBILE|EMAIL|ADDRESS|BIRTHDAY|SEX|PICTURE)\b"
    # Zion userinfo properties-request context: a line mentioning
    # 'properties'/'v3_0/me', or one containing a Zion-specific allowed token
    # (NEW_NO/ORGANIZATION_PATH/ORGANIZATION_WITH_DUTY) — even if the variable
    # is named e.g. `props` — is treated as a properties list.
    zion_ctx = re.compile(r"NEW_NO|ORGANIZATION_PATH|ORGANIZATION_WITH_DUTY")
    hits = []
    for relpath, txt in files_texts:
        for i, ln in enumerate(txt.splitlines(), 1):
            in_props_ctx = ("properties" in ln.lower() or "v3_0/me" in ln
                            or "/me?" in ln or zion_ctx.search(ln))
            if in_props_ctx:
                m = re.search(banned, ln)
                if m:
                    hits.append(f"{relpath}:L{i} {m.group(1)}")
    if hits:
        res.add("B1", "B1/하드룰3", "회원데이터 4개 필드 상한", "FAIL",
                "properties 문맥에 초과 필드: " + "; ".join(hits[:6]) +
                " → 총회 승인 없이 금지(허용: NAME/NEW_NO/ORGANIZATION_PATH/ORGANIZATION_WITH_DUTY)")
    else:
        res.add("B1", "B1/하드룰3", "회원데이터 4개 필드 상한", "PASS",
                "properties 문맥에 초과 필드 없음")


def check_xss_sinks(files_texts, res):
    hits = _grep(files_texts, r"\.innerHTML\s*=|dangerouslySetInnerHTML")
    if hits:
        loc = "; ".join(f"{r}:L{i}" for r, i, _ in hits[:8])
        res.add("VC8", "VC8/G14", "XSS 원시 sink(innerHTML 등)", "WARN",
                f"미이스케이프 가능 지점({loc}) → 이스케이프 여부를 AI가 확인")
    else:
        res.add("VC8", "VC8/G14", "XSS 원시 sink(innerHTML 등)", "PASS",
                "innerHTML/dangerouslySetInnerHTML 없음")


def check_sql_string_build(files_texts, res):
    # On lines containing SQL keywords, WARN when 'string + variable'
    # concatenation, 'string % variable' formatting, or f-string
    # interpolation ({..}) appears alongside — evidence of assembled SQL.
    # Parameterized forms (execute("...%s", (x,)) / "...:name") are not
    # flagged, to avoid false positives.
    sql_kw = re.compile(r"\b(SELECT|INSERT\s+INTO|UPDATE\s+\w|DELETE\s+FROM|FROM\s+\w+\s+WHERE)\b",
                        re.IGNORECASE)
    concat = re.compile(r"""["']\s*\+|\+\s*["']|["']\s*%\s*[\w(]""")
    fstr = re.compile(r"""[fF]["'][^"']*\{""")
    hits = []
    for relpath, txt in files_texts:
        for i, ln in enumerate(txt.splitlines(), 1):
            if sql_kw.search(ln) and (concat.search(ln) or fstr.search(ln)):
                hits.append((relpath, i, ln.strip()))
    if hits:
        loc = "; ".join(f"{r}:L{i}" for r, i, _ in hits[:8])
        res.add("VC7", "VC7/D6", "문자열 조립 SQL(인젝션)", "WARN",
                f"문자열 조립 SQL 정황({loc}) → 파라미터화 여부를 AI가 확인")
    else:
        res.add("VC7", "VC7/D6", "문자열 조립 SQL(인젝션)", "PASS",
                "문자열 조립 SQL 정황 없음(또는 파라미터화)")


def check_service_role_client(files_texts, res):
    hits = [(r, i, ln) for (r, i, ln) in _grep(files_texts, r"service_role")
            if under_client_dir(r)]
    if hits:
        loc = "; ".join(f"{r}:L{i}" for r, i, _ in hits[:6])
        res.add("G3", "G3/하드룰1", "service_role 클라이언트 노출", "FAIL",
                f"클라이언트/정적 경로에 service_role({loc}) → 서버 전용")
    else:
        res.add("G3", "G3/하드룰1", "service_role 클라이언트 노출", "PASS",
                "클라이언트 경로에 service_role 없음")


def check_state_and_validate(files_texts, res):
    has_state = bool(_grep(files_texts, r"\bstate\b") and
                     _grep(files_texts, r"callback"))
    has_validate = bool(_grep(files_texts, r"v1_0/validate|/validate"))
    ev = f"state 처리 정황={'있음' if has_state else '불명'}, " \
         f"validate 재검증 정황={'있음' if has_validate else '불명'}"
    res.add("D1D3", "D1/D3", "state 검증·세션 재검증 정황(휴리스틱)", "WARN",
            ev + " → 실제 CSRF 검증·fail-closed 여부는 AI가 코드로 확정")


def detect_managed_backend(files_texts):
    found = set()
    for _, txt in files_texts:
        low = txt.lower()
        if ("supabase" in low or "supabase_url" in low
                or "@supabase" in low or "createclient(" in low):
            found.add("supabase")
        if "firebase" in low or "firestore" in low or "firebaseconfig" in low:
            found.add("firebase")
    return found


def check_supabase_rls(res, url, key, table, backends):
    if not (url and key and table):
        if "supabase" in backends:
            res.add("VC4", "VC4/G7", "anon 키 무단 조회(RLS) 실측", "NEEDINPUT",
                    "코드에서 Supabase 사용 감지 → RLS 실측 필수(미제공이면 '적합'이 아님). "
                    "Supabase 대시보드 → Project Settings → API에서 'Project URL'과 'anon public' 키를 복사하고, "
                    "점검할 테이블명과 함께 --supabase-url/--supabase-key/--supabase-table 로 재실행. "
                    "(anon 키는 공개키라 넣어도 안전)")
        elif "firebase" in backends:
            res.add("VC4", "VC4/G7", "Firebase 보안 규칙 잠금", "NEEDINPUT",
                    "코드에서 Firebase 사용 감지 → 스캐너가 규칙을 직접 못 읽는다. Firebase 콘솔 → "
                    "Firestore/Realtime Database → Rules 탭 내용을 복사해 AI에게 붙여넣어 "
                    "`allow read/write: if true`·`.read:true`가 없고 auth+소유자/역할로 잠겼는지 판정받으라.")
        else:
            res.add("VC4", "VC4/G7", "anon 키 무단 조회(RLS) 실측", "SKIP",
                    "관리형 백엔드(Supabase/Firebase) 사용 정황 없음 → 미해당(쓰는데 인자 미제공이면 --supabase-* 지정)")
        return
    probe = url.rstrip("/") + f"/rest/v1/{table}?select=*&limit=1"
    req = urllib.request.Request(probe, headers={
        "apikey": key, "Authorization": "Bearer " + key,
        "User-Agent": "zion-scan/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            body = resp.read(4096).decode("utf-8", "ignore")
            status = resp.status
    except urllib.error.HTTPError as e:
        status, body = e.code, ""
    except Exception as e:  # noqa
        res.add("VC4", "VC4/G7", "anon 키 무단 조회(RLS) 실측", "WARN",
                f"프로브 실패: {mask(str(e),20)}")
        return
    if status == 200 and body.strip() not in ("[]", ""):
        res.add("VC4", "VC4/G7", "anon 키 무단 조회(RLS) 실측", "FAIL",
                f"세션 없는 anon 요청이 행 반환(status 200) → RLS 열림(치명). 표={table}")
    elif status == 200:
        res.add("VC4", "VC4/G7", "anon 키 무단 조회(RLS) 실측", "PASS",
                f"anon 요청 200이나 빈 결과(정책 차단). 표={table}")
    else:
        res.add("VC4", "VC4/G7", "anon 키 무단 조회(RLS) 실측", "PASS",
                f"anon 요청 status {status}(비인증 거부). 표={table}")


def check_dependency_audit(root, res):
    if os.path.isfile(os.path.join(root, "requirements.txt")):
        if shutil.which("pip-audit"):
            try:
                out = subprocess.run(["pip-audit", "-r",
                                      os.path.join(root, "requirements.txt")],
                                     capture_output=True, text=True, timeout=120)
                status = "PASS" if out.returncode == 0 else "FAIL"
                res.add("VC14", "VC14/D10", "의존성 취약점(pip-audit)", status,
                        (out.stdout or out.stderr)[-500:].strip() or "결과 없음")
            except Exception as e:  # noqa
                res.add("VC14", "VC14/D10", "의존성 취약점(pip-audit)", "WARN",
                        f"실행 실패: {mask(str(e),20)}")
        else:
            res.add("VC14", "VC14/D10", "의존성 취약점(pip-audit)", "SKIP",
                    "pip-audit 미설치 → `pip install pip-audit && pip-audit -r requirements.txt`")
    elif os.path.isfile(os.path.join(root, "package.json")):
        if shutil.which("npm"):
            try:
                out = subprocess.run(["npm", "audit", "--omit=dev"],
                                     cwd=root, capture_output=True, text=True, timeout=180)
                status = "PASS" if out.returncode == 0 else "WARN"
                res.add("VC14", "VC14/D10", "의존성 취약점(npm audit)", status,
                        (out.stdout or out.stderr)[-500:].strip() or "결과 없음")
            except Exception as e:  # noqa
                res.add("VC14", "VC14/D10", "의존성 취약점(npm audit)", "WARN",
                        f"실행 실패: {mask(str(e),20)}")
        else:
            res.add("VC14", "VC14/D10", "의존성 취약점(npm audit)", "SKIP",
                    "npm 미설치 → `npm audit`")
    else:
        res.add("VC14", "VC14/D10", "의존성 취약점", "SKIP",
                "requirements.txt/package.json 없음 → 스택에 맞는 감사 도구를 AI가 안내")


# ── Code fingerprint (for HQ reproduction/verification) ───────
def code_fingerprint(root, files_texts):
    digest = hashlib.sha256()
    for relpath, txt in sorted(files_texts, key=lambda x: x[0]):
        h = hashlib.sha256(txt.encode("utf-8", "ignore")).hexdigest()
        digest.update((relpath + ":" + h + "\n").encode("utf-8"))
    return digest.hexdigest()


def build_report(root, res, meta):
    ts = meta["scanned_at"]
    fp = meta["code_fingerprint"]
    commit = meta["git_commit"]
    counts = res.counts()
    report_id = hashlib.sha256((fp + ts).encode("utf-8")).hexdigest()[:16]

    md = []
    md.append(f"# 자동 보안 스캔 리포트 (04 단계) — report_id `{report_id}`")
    md.append("")
    md.append(f"- 스캐너 버전: `{SCANNER_VERSION}`")
    md.append(f"- 스캔 시각(UTC): `{ts}`")
    md.append(f"- git commit: `{commit}`")
    md.append(f"- 스캔 파일 수: `{meta['file_count']}`")
    md.append(f"- **코드 지문(SHA-256): `{fp}`**")
    md.append(f"- **스캔 파일 목록 지문(SHA-256): `{meta['manifest_sha256']}`**  "
              f"(무엇을 스캔했는지까지 고정 — 파일 은닉 방지)")
    md.append(f"- 집계: PASS {counts['PASS']} · **FAIL {counts['FAIL']}** · "
              f"**NEEDINPUT(추가확인필요) {counts['NEEDINPUT']}** · "
              f"WARN {counts['WARN']} · SKIP {counts['SKIP']}")
    md.append("")
    md.append("> 이 리포트는 **기계가 확인 가능한 항목만** 판정한다. "
              "WARN/SKIP과 권한·감사·IDOR 등 코드 이해가 필요한 항목은 04 본문 기준으로 AI가 최종 판정한다. "
              "**NEEDINPUT은 관리형 백엔드(예: Supabase RLS) 실측에 필요한 값이 없어 판정 못 한 항목**으로, "
              "'적합'이 아니라 값을 받아 재실행해야 하는 '추가확인필요'다. "
              "이 리포트는 **바이브코더가 직접 실행해 총회에 결과만 제출**하는 자기완결 산출물이다 — "
              "코드 지문·파일목록 지문이 위변조 방지 표지이며, 총회는 이 리포트만으로 검사한다.")
    md.append("")
    md.append("| 판정 | ID | VC/시온 | 검사 | 근거(마스킹) |")
    md.append("|------|----|---------|------|--------------|")
    order = {"FAIL": 0, "NEEDINPUT": 1, "WARN": 2, "SKIP": 3, "PASS": 4}
    for f in sorted(res.findings, key=lambda x: order.get(x["status"], 9)):
        ev = f["evidence"].replace("|", "\\|")
        md.append(f"| {f['status']} | {f['id']} | {f['vc']} | {f['name']} | {ev} |")
    md.append("")
    md.append("## 스캔 파일 목록(지문 대상)")
    md.append(f"제외 디렉터리: `{', '.join(meta['excluded_dirs'])}`")
    if meta["file_count"] <= 40:
        for p in meta["manifest"]:
            md.append(f"- `{p}`")
    else:
        md.append(f"- 총 {meta['file_count']}개 — 전체 목록은 "
                  "`security_scan_report.json`의 `scanned_files` 참조.")
    md.append("")
    md.append("## 총회 검증(결과만 제출)")
    md.append("바이브코더가 이 스캐너를 **직접 실행**해 산출한 이 리포트(코드 지문·파일목록 지문 포함)를 "
              "총회에 **결과만 제출**한다. 총회는 레포 전체를 받을 필요 없이 이 리포트로 검사한다: "
              "**FAIL·NEEDINPUT이 0이어야 하며**, 지문이 보고서 본문과 일치해야 한다. "
              "(선택적 표본 감사 — 총회가 특정 시스템에 한해 레포 읽기 권한을 요청하면, 같은 커밋에서 "
              "재실행해 두 지문이 일치하는지로 위변조 없음을 확인할 수 있다.)")

    js = {
        "report_id": report_id,
        "scanner_version": SCANNER_VERSION,
        "scanned_at_utc": ts,
        "git_commit": commit,
        "file_count": meta["file_count"],
        "code_fingerprint_sha256": fp,
        "file_manifest_sha256": meta["manifest_sha256"],
        "excluded_dirs": meta["excluded_dirs"],
        "scanned_files": meta["manifest"],
        "counts": counts,
        "findings": res.findings,
    }
    return "\n".join(md), js


def main():
    ap = argparse.ArgumentParser(description="시온로그인 배포전 자동 보안 스캐너")
    ap.add_argument("--root", default=".", help="프로젝트 루트")
    ap.add_argument("--deploy-url", default="", help="배포 URL(정적 /.git/config 노출 실측)")
    ap.add_argument("--supabase-url", default="", help="Supabase URL(RLS 무단조회 실측)")
    ap.add_argument("--supabase-key", default="", help="Supabase anon key(공개키)")
    ap.add_argument("--supabase-table", default="", help="RLS 실측 대상 테이블")
    ap.add_argument("--out-dir", default="", help="리포트 저장 폴더(기본: 루트)")
    ap.add_argument("--scanned-at", default="", help="스캔 시각 override(UTC ISO). 미지정 시 현재시각")
    args = ap.parse_args()

    root = os.path.abspath(args.root)
    if not os.path.isdir(root):
        print(f"[ERROR] --root 경로 없음: {root}", file=sys.stderr)
        return 2

    files_texts = [(rel(root, fp), read_text(fp)) for fp in iter_source_files(root)]
    res = Result()

    # Static / network checks
    check_repo_visibility(root, res)
    check_git_config_exposure(root, res, args.deploy_url)
    check_gitignore_env(root, res)
    check_env_example(root, res)
    check_hardcoded_secrets(files_texts, res)
    check_jwt_secret(files_texts, res)
    check_oauth_path(files_texts, res)
    check_userinfo_version(files_texts, res)
    check_member_ceiling(files_texts, res)
    check_xss_sinks(files_texts, res)
    check_sql_string_build(files_texts, res)
    check_service_role_client(files_texts, res)
    check_state_and_validate(files_texts, res)
    backends = detect_managed_backend(files_texts)
    check_supabase_rls(res, args.supabase_url, args.supabase_key,
                       args.supabase_table, backends)
    check_dependency_audit(root, res)

    ts = args.scanned_at or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    manifest = sorted(relpath for relpath, _ in files_texts)
    manifest_hash = hashlib.sha256("\n".join(manifest).encode("utf-8")).hexdigest()
    meta = {
        "scanned_at": ts,
        "git_commit": git_head(root),
        "code_fingerprint": code_fingerprint(root, files_texts),
        "file_count": len(files_texts),
        "manifest": manifest,
        "manifest_sha256": manifest_hash,
        "excluded_dirs": sorted(SKIP_DIRS),
    }
    md, js = build_report(root, res, meta)

    out_dir = os.path.abspath(args.out_dir) if args.out_dir else root
    os.makedirs(out_dir, exist_ok=True)
    md_path = os.path.join(out_dir, "security_scan_report.md")
    js_path = os.path.join(out_dir, "security_scan_report.json")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(md + "\n")
    with open(js_path, "w", encoding="utf-8") as f:
        json.dump(js, f, ensure_ascii=False, indent=2)

    counts = res.counts()
    print(f"[security_scan] report_id={js['report_id']} "
          f"PASS={counts['PASS']} FAIL={counts['FAIL']} "
          f"NEEDINPUT={counts['NEEDINPUT']} WARN={counts['WARN']} SKIP={counts['SKIP']}")
    print(f"[security_scan] wrote: {md_path}")
    print(f"[security_scan] wrote: {js_path}")
    return 1 if (counts["FAIL"] > 0 or counts["NEEDINPUT"] > 0) else 0


if __name__ == "__main__":
    sys.exit(main())
