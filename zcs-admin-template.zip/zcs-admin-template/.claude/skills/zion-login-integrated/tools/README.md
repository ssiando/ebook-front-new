# tools/ — Automated Security Scanner

`security_scan.py` : the pre-deploy automated security scanner executed during the `04_predeploy_verification.md` stage.
It automatically judges the machine-checkable items and produces the **HQ (총회) submission report (with code fingerprint)**.

## Running it

```bash
python tools/security_scan.py --root <project root>
# Static deployment:   --deploy-url https://<deploy-address>
# Using Supabase:      --supabase-url https://xxx.supabase.co --supabase-key <ANON_KEY> --supabase-table <table>
# Report output dir:   --out-dir <folder>
```

- Standard library only → **no installation** (Python 3.7+). Works on Windows/Mac/Linux.
- Outputs: `security_scan_report.md`, `security_scan_report.json` (in the working folder or `--out-dir`).
- Exit codes: `0` = no FAIL/NEEDINPUT, `1` = at least one FAIL or NEEDINPUT (추가확인필요).

## What it checks (machine verification)

Repo visibility (VC3/E5) · `/.git/config` exposure · `.env` in `.gitignore` and `.env.example` placeholders (VC2) ·
hardcoded secrets (VC1) · `JWT_SECRET` (D2) · the `/oauth/` path · `v3_0/me` · the 4-field member-data ceiling (B1) ·
`service_role` client exposure (G3) · raw XSS sinks (VC8, WARN) · string-built SQL (VC7, WARN) ·
live anon-key unauthorized-read probe (VC4, when arguments are provided) · dependency vulnerabilities (VC14).

**A WARN/SKIP is not a pass.** Items requiring code comprehension — permission logic, audit, IDOR, actual CSRF behavior —
are not judged by the scanner; the AI makes the final judgment against the body of `04_predeploy_verification.md`.

## NEEDINPUT (추가확인필요)

When a managed backend (Supabase/Firebase, etc.) is detected in the code but the live-probe arguments (or rules) are missing, the result is **NEEDINPUT, not SKIP** —
it is not a pass. The report's evidence column states where to get what and how to re-run (e.g. Supabase dashboard → Settings → API — Project URL + anon key + table name), so obtain those values and re-run (or paste the Firebase rules and judge). Any remaining NEEDINPUT means exit code 1 and blocks deployment and production.

## HQ verification (submit only the result)

The report contains the **code fingerprint (SHA-256)** + the **file-manifest fingerprint (SHA-256)** + the git commit + the **list of scanned files**.
The vibe coder runs the scanner personally and submits **only the result (this report)** to 총회 — no full repo upload needed.
총회 inspects by checking that FAIL/NEEDINPUT are 0 and that both fingerprints match the report body. The file-manifest fingerprint also pins down "what was scanned", preventing vulnerable files from being hidden.
(Optional sample audit: if 총회 requests read access to a specific system's repo, it re-runs at the same commit and confirms no tampering via matching fingerprints.)

No secrets or real values remain in the report (evidence is masked as `[REDACTED]`).
