# 01 · Pre-development — Zion Login Canon (시온로그인 캐논)

> This file preserves **every substantive rule of the original Zion Login skill (`SKILL.md`) in the original English** — reformatted and reordered only; no rule was removed or changed. On conflict, this canon wins.
> It is the integration canon for tribe-level (지파, the 12 tribes) sites that authenticate with Zion Login, handed down by HQ (총회).
> **Do not deviate — a broken auth flow or permission model means a member-data leak.**
> Where this document conflicts with anything you know about other Zion sites, this document wins for tribe sites.

---

## When to read this file

- **First.** Before development starts, the AI ingests this canon so that all subsequent code, design, and guidance is built on these rules.
- Per the routing in `00_START_HERE.md`, read it together with `01b_common_security_conflicts.md` in the pre-development stage.

## What this file contains

- **The 8 hard rules (non-negotiable)** — full text of the eight rules that are never compromised.
- **Core flow (strict order)** — the fixed sequence from the frontend click through session creation to the frontend callback.
- **Session model** — using the ZAuth JWT as the session token (hash storage, per-request lookup, periodic revalidation, expiry, logout).
- **Environment variable table** — exact names and purposes. The absence of `JWT_SECRET` is normal.
- **Credentials & environments** — keys are not bundled and are issued by HQ on request, the `/oauth/` path, the alpha/production split, and the four frequently mistaken values.
- **Member data** — the four-field ceiling and its shapes, plus the response envelope.
- **Permission model summary** — 고유번호-based local permissions, SUPER_ADMIN, fail-closed, the two mandatory pages.
- **User-facing naming rules** — never surface 'ZAuth', login button = "시온로그인", no codes/internal IDs.
- **Mandatory security rules (with the original why-clauses)**.
- **Review gate introduction (A–E)** — mandatory before deploy, with links to the details.

This file is `[AI directive]`-centric. Because it is the canon, vibe coder (바이브코더 — the non-expert builder) guidance is kept to a minimum here.

---

## 1. Hard Rules (non-negotiable)

[AI directive] The eight rules below are **non-negotiable**. Never produce code, designs, or guidance that violates any of them. **Never invent** a new auth flow or a new permission model.

| # | Hard rule | Core provision |
|---|--------|-----------|
| 1 | Credential = `client_id` only | The `client_id` issued to your tribe's app IS the ZAuth REST API Key. There is **NO** `client_secret`, and tribe apps do **NOT** hold an Admin Key — no server-to-server ZAuth calls; member data refreshes happen only when the user logs in. |
| 2 | Never issue your own JWT | The only session token is the **access_token issued by Zion Login** (a ZAuth JWT). Do not mint HS256/RS256 tokens, do not add a `JWT_SECRET`, do not wrap the ZAuth token inside another token. Sessions are validated against Zion Login (§3 Session Model). |
| 3 | Member data ceiling = name, affiliation, duty | The member data ceiling is **name, affiliation, duty** (이름·소속·직책) plus **고유번호 (`newNo`)** as the unique key. Request exactly `NAME, NEW_NO, ORGANIZATION_PATH, ORGANIZATION_WITH_DUTY` — nothing more. MOBILE/EMAIL/ADDRESS/BIRTHDAY/SEX/PICTURE are **forbidden** in this edition; if a feature truly needs one, get HQ approval first and record it in the spec. |
| 4 | Permissions are resolved by 고유번호 (newNo), not by duty | Tribe duties are numerous and complex, so the downstream edition assigns permissions **directly to 고유번호s** in a local table — that table is the single source of truth (SSOT) for ordinary permissions. Duty→permission mapping is intentionally NOT the model here; duty (직책) is still fetched, but for **display only** (member directory), never as a permission input. See `references/permission-model.md`. (This supersedes the earlier duty-ID-mapping design.) **user-authorities is used for exactly ONE thing — SUPER_ADMIN detection (rule 5) — and nothing else.** Ordinary permissions never come from ZAuth. |
| 5 | SUPER_ADMIN = ZAuth `DO_EVERYTHING`, no DB row required | SUPER_ADMIN is the reserved local master role that **wraps ZAuth's canonical global master authority `DO_EVERYTHING`** (role `super-admin`, id `*:ROLE:DO_EVERYTHING`). At login the app calls **user-authorities once** and, if the `roleBased` permissions (global or app) contain `DO_EVERYTHING`, the user is SUPER_ADMIN — **all access by default, bypassing every permission check, without any local grant**. This solves bootstrap: whoever holds `DO_EVERYTHING` in the member registry is master on day one with an empty DB. A local `SUPER_ADMIN` grant row is an optional offline fallback (for setups where authorities can't be reached). ZAuth returns `DO_EVERYTHING`, never the name `SUPER_ADMIN` — check for `DO_EVERYTHING`. Detection is fail-closed (authorities error → not super), and every SUPER_ADMIN action is still audit-logged. |
| 6 | The privacy & security review is a built-in, blocking gate | Before delivering any feature that touches member data (screens, APIs, logs, exports), run the full checklist in `references/privacy-security-review.md` and fix every blocking finding. This is **part of the definition of done**, not an optional extra. |
| 7 | Login is required whenever the system handles internal information — not only personal data | The trigger for authentication is *internal information* (member data, contact lists, org intelligence, operational/strategic data, anything not meant for the public), not the narrower category of *personal data*. If a system exposes any internal information, it **MUST sit behind Zion Login**. A system that holds **zero** internal information (a purely public page — public notices, public marketing) needs no login. When in doubt, it is internal → add login. Client-side password gates do **NOT** satisfy this — see `references/privacy-security-review.md` §E. **[Org policy — `01b_common_security_conflicts.md` §A2 policy P-1]:** the integrated edition's confirmed policy **matches** the Zion original above — login is mandatory whenever internal information is handled (including personal data, and including sensitive aggregates that identify no individual); only fully public content is exempt. Also consistent with HQ §E. |
| 8 | The GitHub/GitLab repository MUST be private | Any repo for a Zion Login system (or any system handling internal information) is **private, always**. Source, config, and history routinely leak endpoints, internal data shapes, and structure even when secrets are externalized — a public repo is itself an internal-information disclosure. Verify visibility before the first push and at the review gate. |

---

## 2. Core Flow (strict order)

[AI directive] Follow the order below **strictly**. Do not skip or reorder steps.

```
[Frontend] click "시온로그인"
  → window.location.href = {API_BASE}/auth/login
[Backend] GET /auth/login
  → state = cryptographically random (32+ bytes), stored server-side (or signed cookie)
  → 302 → {OAUTH2_AUTH_URL}?client_id&redirect_uri&response_type=code&state
[Zion Login] user signs in → 302 → {redirect_uri}?code=...&state=...
[Backend] GET /auth/callback?code&state
  → verify state (reject mismatch — CSRF)
  → POST {OAUTH2_TOKEN_URL} (grant_type=authorization_code, client_id, redirect_uri, code) timeout=10
     # no client_secret — Zion Login does not use one
  → GET {OAUTH2_USERINFO_URL}?properties=NAME,NEW_NO,ORGANIZATION_PATH,ORGANIZATION_WITH_DUTY
     (Authorization: Bearer {access_token})
  → unwrap: resp["data"]["properties"] (fallback resp["properties"])
  → upsert user (newNo, name, org path snapshot, duties snapshot)
  → GET {OAUTH2_AUTHORITIES_URL} (Bearer) → SUPER_ADMIN iff roleBased contains DO_EVERYTHING  # ONLY use of authorities
  → effective permissions = local 고유번호 grants  ∪  (ALL if SUPER_ADMIN)
  → create session row keyed by SHA-256(access_token) with identity + permissions + expiry
  → 302 → {FRONTEND_URL}/#/auth/callback?token={access_token}
[Frontend] parse token from hash → store → attach "Authorization: Bearer {token}" to every API call
```

[Check] Every element of the core flow exists in the code, in order: (1) frontend click → `/auth/login`, (2) server-side `state` generation, (3) `authorize` redirect, (4) `state` verification in `callback`, (5) token exchange (no `client_secret`, timeout=10), (6) `userinfo` fetch (properties = the 4 above), (7) `data.properties` unwrap (fallback `properties`), (8) user upsert, (9) `user-authorities` checked for `DO_EVERYTHING` only, (10) effective permissions computed, (11) session row keyed by `SHA-256(access_token)`, (12) token handed to the frontend via the callback hash.

---

## 3. Session Model (ZAuth JWT as the session token)

[AI directive]

- **Store only a hash.** The backend session row is keyed by `SHA-256(access_token)`; the raw token is never persisted server-side and never written to logs.
- **Per request:** Bearer token → hash lookup → session row must exist and not be expired → attach identity + permissions to the request context. No session row = **401**.
- **Periodic revalidation:** at most every `SESSION_REVALIDATE_SECONDS` (default 300), revalidate the token via `GET {API_URL}/api/auth/v1_0/validate` (Bearer). Any non-valid result — `valid=false`, `success=false`, 401/403, or a network error — invalidates the session (**fail-closed**) and returns 401 so the frontend re-runs login.
- **Expiry:** the session's absolute lifetime follows the token's `exp` claim. You may decode the JWT payload *unverified* solely to read `exp` for scheduling — trust never comes from local verification (there is no published key for tribe apps); trust comes from the validate endpoint.
- **Logout:** delete the session row and clear the frontend token. There is no local token to "revoke" — deleting the row is the revocation.
- **Permissions are resolved at login and stored in the session.** After changing a 고유번호's assignments, the affected user picks it up on next login; an admin "force re-login" (delete that user's sessions) covers urgent revocations.

---

## 4. Environment Variables (exact names)

[AI directive] Use exactly the variable names below.

| Variable | Purpose |
|------|------|
| `OAUTH2_CLIENT_ID` | The app credential — the ZAuth **REST API Key**. No secret pair exists. **Not bundled** — issued by HQ on request after a usage note (§5 Credentials & Environments); keep it in a local gitignored `.env`, never committed |
| `OAUTH2_AUTH_URL` / `OAUTH2_TOKEN_URL` | `{AUTH_URL}/oauth/authorize`, `{AUTH_URL}/oauth/token` — path is **`/oauth/`, NOT `/oauth2/`** |
| `OAUTH2_USERINFO_URL` | `{API_URL}/api/auth/v3_0/me` |
| `OAUTH2_VALIDATE_URL` | `{API_URL}/api/auth/v1_0/validate` — session revalidation |
| `OAUTH2_AUTHORITIES_URL` | `{API_URL}/api/external/v1/user-authorities` — **used only to detect the `DO_EVERYTHING` master → SUPER_ADMIN** (rule 5), never for ordinary permissions |
| `OAUTH2_REDIRECT_URI` | If unset, auto-detect from `X-Forwarded-Proto` + `Host` |
| `SESSION_REVALIDATE_SECONDS` | Default 300 — max age of a validation result before re-checking |
| `CORS_ORIGINS` (comma-separated) | First entry is the OAuth callback frontend origin |

**Environments:** auth `https://auth.ziongroup.net`, api `https://api.ziongroup.net`; alpha adds the `alpha-` prefix. There is **no `JWT_SECRET`** in this edition — its presence in a config is a review finding (someone is minting local tokens).

---

## 5. Credentials & Environments (the `client_id` is NOT bundled — request it)

[AI directive] **No `client_id` ships with this skill.** The key is a controlled credential: HQ issues it only after you tell them what you are building and how you will use it. This applies to the alpha/development key too, not just production — the difference is the bar, not whether you have to ask.

Endpoints are fixed (only the key is variable):

```
OAUTH2_CLIENT_ID=            # ← issued by HQ on request; do NOT hardcode or commit
# alpha (development/testing)
OAUTH2_AUTH_URL=https://alpha-auth.ziongroup.net/oauth/authorize
OAUTH2_TOKEN_URL=https://alpha-auth.ziongroup.net/oauth/token
OAUTH2_USERINFO_URL=https://alpha-api.ziongroup.net/api/auth/v3_0/me
OAUTH2_VALIDATE_URL=https://alpha-api.ziongroup.net/api/auth/v1_0/validate
OAUTH2_AUTHORITIES_URL=https://alpha-api.ziongroup.net/api/external/v1/user-authorities
# production drops the alpha- prefix on both hosts
```

- **redirect_uri registration is not required to start** — only the key is needed. Build against your local `redirect_uri` (auto-detected from request headers) once you hold a key.
- **Alpha/development key — request with a short usage note:** contact HQ (총회 정보통신부 전산개발과) stating **what you are building and how the key will be used** (system, department, member data touched). They deliver the alpha key after that contact. This is intentional — no key changes hands without HQ knowing the use.
- **Production key — request after the review gate passes:** the production `client_id` is issued only after the mandatory privacy & security review gate completes with **zero blocking findings and a "production operation possible" verdict**. Do not request it for an unreviewed or failing system. The request includes all five items (template: `references/privacy-security-review.md` §Production key request):
  1. **기능** — feature summary; endpoints/screens touching member data
  2. **사용부서** — operating/using department(s)
  3. **개인정보처리시 우려할 점** — privacy-handling concerns + mitigations
  4. **보안점검결과 요약** — review summary (findings, fixes, report location)
  5. **프로덕션 운영 가능 여부** — the review's explicit production-readiness verdict

  If the verdict is "not yet possible", fix and re-review — do not send the request.
- **One `client_id` per system — never reuse a key.** A key issued for one system/tribe must not be reused in another app, site, or environment. Each deployment requests its own. Reuse defeats per-system attribution and revocation: if a shared key leaks, every system on it must be rotated at once, and HQ cannot tell which system's usage is which. (The sole exception: the HQ master may reuse one key while testing across scaffolds — that is not a pattern to copy downstream.)
- **Locally, use the `client_id` you have already been issued.** Put it in a local `.env` (gitignored) — never in `.env.example`, source, or the distributed skill.

> ### ⚠️ Frequently mistaken values (NEVER change these)
> 1. **The OAuth path is `/oauth/`** — not `/oauth2/` — even though the env var names say `OAUTH2_*`.
> 2. **The request property is singular `ORGANIZATION_WITH_DUTY`** — requesting the plural makes Zion Login reject it and the login fails.
> 3. **The response JSON key is plural `organizationWithDuties`** — send singular, read plural. This asymmetry is real.
> 4. **There is no `client_secret`.** `client_id` IS the REST API Key. Tribe apps make no Bearer-less server-to-server calls.

---

## 6. Member Data (what you get, and its shape)

[AI directive] Every Zion Login API responds with the envelope `{success, data, error{type, code, message}, traceId}` — **always check `success`** (HTTP 200 with `success=false` happens). Member payload wrapper: `data.properties` (fallback `properties`). Fields used in this edition:

| Field | Shape | Rule |
|------|------|------|
| `newNo` | string | **고유번호**, the member's public unique key, e.g. `"00341130-00036"`. Used as the user primary key and for exceptional individual grants. Displayed in full in admin UIs, **always labeled '고유번호'** (never the field name). |
| `name` | string | Display name (이름). |
| `organizationPaths` | `ZatOrganizationDto[]` | Org path array (tribe → church → department → …); the affiliation (소속) source and the data-scope input. `organization.level` enum: `HEAD | TRIBE | CHURCH | ADMIN_DEPARTMENT | NONE` — map only HEAD/TRIBE/CHURCH, treat the rest as NONE. |
| `organizationWithDuties` | `OrganizationWithDutyDto[]` | `[{ duty:{id, name, positionName}, organization:{id, name, type, level, ...}, type:"MEMBER"\|"DUTY" }]` — the 직책 (duty) source. In this edition it is **display-only** (member directory / profile), NOT a permission input — permissions come from the 고유번호 table. **Filter `type == "DUTY"`** for the list of held duties. |

- **API version:** use `/api/auth/v3_0/me` (typed); do not use `v2_0/me`.
- **Response envelope:** always check `success`. Full verified schemas and the do-not-call list: `references/api-catalog.md`.

---

## 7. Permission Model (summary — full canon in `references/permission-model.md`)

[AI directive]

- **Catalog:** permissions are UPPER_SNAKE codes defined in a DB catalog table with user-facing `label` + `description`. `SUPER_ADMIN` is the reserved master code.
- **Assignment (the model):** `user_permissions` rows — `고유번호(new_no) → permission code`. The super-admin assigns/revokes these on a management page. Because ZAuth's authorization is not used and duty mapping is intentionally dropped downstream, **this table is the SSOT** (single source of truth).
- **SUPER_ADMIN:** determined at login from ZAuth **user-authorities** — if `roleBased` contains `DO_EVERYTHING`, the caller is master (all access), **no DB row needed**. A local `SUPER_ADMIN` grant row is an optional offline fallback.
- **Effective permissions = codes assigned to the caller's 고유번호** (or ALL if SUPER_ADMIN via DO_EVERYTHING). Permission (what) and data scope (whose data — from `organizationPaths`) are **separate axes**: every data query additionally filters by the caller's tribe/church scope.
- **Fail-closed:** resolution errors, unknown 고유번호, empty assignment → empty permission set, never a default-allow.

[AI directive] **Two mandatory pages:**
1. **Permission guide/catalog (권한 안내)** — any authenticated user may view. Shows labels + "my permissions", **never raw codes**.
2. **Permission management (권한 관리)** — assign/revoke permission codes by 고유번호 + audit history. **`SUPER_ADMIN` or a delegated `PERMISSION_ADMIN` holder only.**

Specs: `references/permission-model.md`. (Read it before any permission work: the 고유번호-based schema, resolution algorithm, SUPER_ADMIN bootstrap, the two mandatory pages, audit rules.)

---

## 8. User-Facing Naming Rules

[AI directive]

- **Never surface 'ZAuth'** in end-user copy. Users sign in with their **Zion 계정**; the login button says "시온로그인" (or the site's polished equivalent), and account inquiries are directed to the 정보통신부 ("계정 문의는 정보통신부로 연락해 주세요.").
- Duty-sourced permissions are described as **"교적에 등록된 직책에 따라 자동 부여"** (auto-granted by the duty registered in the member registry) — never "by ZAuth" / "in a console".
- No developer terminology in end-user UI: no permission codes, internal IDs, enum values, or schema field names. Every user-visible concept gets a friendly label + short description. `newNo` is always labeled **'고유번호'**.
- All user-facing Korean text is polished natural Korean — AI-flavored phrasing must not reach end users.

---

## 9. Mandatory Security Rules (with the original why-clauses)

[AI directive]

- **A permission check on every API** + a data-scope filter on every data query. *(why)* Authentication without authorization means every member can read all member data.
- Validate `state` on callback (CSRF). Set a timeout on the token exchange. *(why)* Prevents hangs.
- Never log the access_token, and never log `newNo` together with behavioral data in general app logs. *(why)* Audit tables are the sanctioned place for who-did-what.
- Secrets and `client_id` config live in env/secret stores, never in the repo.
- Behind a proxy, forward `X-Forwarded-Proto` and trust it when assembling `redirect_uri`. *(why)* Zion Login requires the registered (https) callback to match exactly.

---

## 10. Mandatory Review Gate (A–E, built into this skill)

[AI directive] Before delivering ANY feature that displays, stores, logs, exports, or downloads member data — and before the first production deploy — run the five-area A–E checklist in `references/privacy-security-review.md`:

| Gate | Name | What it covers |
|--------|------|-------------|
| **A** | Exposure (노출) | Screens, API over-response, URLs, logs, error messages |
| **B** | Management (관리) | Minimization, retention, access control, audit |
| **C** | Download/Export (다운로드) | Gating, audit, scope, format hygiene |
| **D** | Security risks (보안 리스크) | Auth flow, session, IDOR, injection, fail-closed |
| **E** | Access boundary & repository (접근 경계·저장소) | Login required for any *internal information* (not just personal data), server-side enforcement, **private repo** |

Produce the review report, fix every item marked *blocking*, and record the result. Skipping this gate is a canon violation.

The integrated run of this gate (merged with the common web-hygiene checks VC1–VC16) and the report format are covered in `04_predeploy_verification.md`. The original checklist lives in `references/privacy-security-review.md`.

---

## References

- `references/permission-model.md` — local RBAC canon: 고유번호-based schema, resolution algorithm, SUPER_ADMIN bootstrap, the two mandatory pages, audit rules. **Read before any permission work.**
- `references/api-catalog.md` — verified Zion Login API schemas for this edition (/me, token validation, public org lists, duty catalog) + the do-not-call list. **Read before calling any endpoint beyond the core flow.**
- `references/privacy-security-review.md` — the mandatory review checklist + report format. **Run at the review gate.**

---

## [⚠ Conflict resolution]

Wherever the pre-existing in-house security guide (rules G1–G24, VC1–VC16, R0) conflicts with this canon, **this Zion Login canon wins unconditionally**. The verdict table for the 11 concrete conflict items is in `01b_common_security_conflicts.md`. Representative examples: no self-issued JWT (hard rule 2) beats the guide's own-login flow; the internal-information login trigger (hard rule 7) beats the personal-data trigger; 고유번호-based RBAC (hard rules 4·5) beats duty-based automatic permissions; the four-field ceiling (hard rule 3) beats the generic minimal-collection principle. (Organization-level policy decisions are maintained in `01b_common_security_conflicts.md` §A2, the "organization policy registry"; the current login-trigger policy P-1 matches this canon.)

## [Next step]

After ingesting this canon, read `01b_common_security_conflicts.md` — it applies the common security rules (G1–G24) **on top of** this canon and finalizes the Zion-wins conflict-resolution verdict table.
