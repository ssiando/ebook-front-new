# 06 · Deploy + Operations (production switch · deployment by hosting type · incident response / key retrieval)

## When to read this file
Read this immediately after receiving the **production `client_id`** from HQ (총회) via `05_production_key_request.md`. This one file carries you from the alpha→production switch through the actual deployment, and on through operations and incident response.

## What this file contains
- **Production switch:** inject the production key into `.env`, drop the `alpha-` prefix from the endpoints, re-confirm there is no `JWT_SECRET`.
- **Deployment by hosting type (the four G5 types):** static / serverless / container·self-hosted / managed backend — per type: source kept private, secrets in environment variables, private repo.
- **Post-deploy live verification (the VC3/VC4 philosophy):** source URL 404 · unauthorized public-key DB reads blocked · token revalidation working · HTTPS.
- **Operations & incident response (minimal):** on key leak, staff change, or end of operation, **request key retrieval from HQ (총회)**; forced re-login (session deletion); audit-log retention.
- **[Check] deployment completion criteria** + the re-verification path on change.

---

## 0. Governing principles of this stage (Zion-first, restated)

`[AI directive]`
- For every deploy/operations decision in this file, **Hard Rules 1–8 of `01_zion_login_canon.md` take precedence**, with the G rules of `01b_common_security_conflicts.md` applied on top. On any conflict, the Zion Login rule always wins (the conflict-resolution table is in `01b_common_security_conflicts.md`).
- Proceed only when the `04_predeploy_verification.md` report shows **0 blocking findings + the "프로덕션 운영 가능" (fit for production operation) verdict**, and the **production key has already been issued** via `05_production_key_request.md`. If either is unmet, do not execute this file — return to that stage.

---

## 1. Production switch (alpha → production)

`[AI directive]` The switch changes exactly three things; leave the rest of the core-flow, session-model, and permission-model code **untouched** (reuse the logic built in stage 3 per the `01` canon).

| # | Switch item | Alpha value | Production value | Rule basis |
|---|---|---|---|---|
| 1 | `OAUTH2_CLIENT_ID` | alpha key | replace with the **HQ-issued production key** | Hard Rule 1, D11 |
| 2 | Endpoint hosts | `alpha-*.ziongroup.net` | **drop the `alpha-` prefix** → `auth.ziongroup.net` / `api.ziongroup.net` | credentials/environment |
| 3 | `JWT_SECRET` | absent (correct) | **re-confirm absent** — if present, halt the deploy | Hard Rule 2 |

Production `.env` (local, gitignored, never committed):

```
OAUTH2_CLIENT_ID=            # ← 총회 발급 프로덕션 키. 하드코딩·커밋 금지 (하드룰1·G1)
OAUTH2_AUTH_URL=https://auth.ziongroup.net/oauth/authorize
OAUTH2_TOKEN_URL=https://auth.ziongroup.net/oauth/token
OAUTH2_USERINFO_URL=https://api.ziongroup.net/api/auth/v3_0/me
OAUTH2_VALIDATE_URL=https://api.ziongroup.net/api/auth/v1_0/validate
OAUTH2_AUTHORITIES_URL=https://api.ziongroup.net/api/external/v1/user-authorities
OAUTH2_REDIRECT_URI=         # 미설정 시 X-Forwarded-Proto+Host로 자동감지 (https여야 함)
SESSION_REVALIDATE_SECONDS=300
CORS_ORIGINS=                # 첫 항목 = OAuth 콜백 프론트 오리진 (https)
# JWT_SECRET 은 존재하지 않는다. 있으면 누군가 로컬 토큰을 발급 중이라는 신호 → 제거 후 04로 회귀.
```

`[AI directive]` Verify on switch, without exception:
- The OAuth path is **`/oauth/`** — not `/oauth2/`. Even though the env vars are named `OAUTH2_*`, the path is `/oauth/`. (A frequently wrong value.)
- userinfo is **`v3_0/me`**; `v2_0/me` is forbidden.
- There is no `client_secret` — do not put one in the token exchange.
- **The production key is unique per system (D11).** Use it only for the exact system that was verified and issued through `04_predeploy_verification.md`–`05_production_key_request.md`. Never reuse the alpha key in production, and never reuse the production key in another app/site/environment.

`[⚠ Conflict resolution]` Credentials (conflict-resolution table row 10): guide G1 (no hardcoding) and Zion D11 (unique key per system, no reuse) **both** apply — G1 keeps the key out of the code, D11 keeps one key per system.

`[바이브코더 안내]`
- 알파 키를 지우고, 총회에서 새로 받은 **프로덕션 키**를 `.env`의 `OAUTH2_CLIENT_ID=` 뒤에 붙여 넣으세요.
- 주소에 있던 `alpha-`라는 글자를 지워 주세요(예: `alpha-auth.ziongroup.net` → `auth.ziongroup.net`). 위 예시 그대로면 이미 지워져 있습니다.
- **진짜 `.env`(실제 키가 들어간 파일)는 절대 깃(Git)에 올리지 말고, 채팅창에 통째로 붙여 넣지도 마세요.** AI에게는 "키를 넣었다"는 사실만 알려주면 됩니다. (`.env.example`에는 자리표시자만 둡니다.)

---

## 2. Deployment by hosting type (the four G5 types)

`[바이브코더 안내]` **[R0-2 예외 · 배포 시 1회만 묻는다]** 아직 호스팅 유형을 확정하지 않았다면, AI는 정확히 다음을 묻고 답을 받은 뒤 구성한다:

```
이 결과물을 어디에 올릴 계획인지 골라주세요. 잘 모르겠으면 1번(가장 통제됨)을 고르세요.
1. 회사 서버 / 시놀로지 NAS 등 내부 서버 (내부망, 소스 비공개)
2. Cloudflare Pages / Vercel / Netlify 같은 무료 호스팅
3. GitHub에 올려서 쓰고 싶다
4. 아직 안 정했다
```

`[AI directive]` Classify hosting **by how the code runs (its type), not by vendor name**. When a new vendor not on any list comes up, map it to one of the four types below and the rules apply unchanged.

| Answer | Mapped type | Deployment setup (the AI generates exactly this) |
|---|---|---|
| **1** | Container / self-hosted · PaaS | Keep the source private. If Docker: slim image, **non-root**, open only the required ports. Secrets in container environment variables. |
| **2** | Static / serverless | The AI generates a deploy config that **serves only build artifacts from a private repo** → source stays private. Secrets in the platform's environment-variable store (never committed). |
| **3** | GitHub | **Private repo, mandatory.** GitHub Pages is free only for public repos, so to stay private either (a) connect the private repo to a static/serverless vendor (free, private-capable) or (b) use a paid plan. **Default recommendation: (a).** Ask the user for exactly one step: "set the repo to private". |
| **4** | Undecided | Recommend 1 or 2, collect the information, then finalize. |

Mandatory setup per type (G5·G6·G3·Hard Rule 8):

| Type | Source privacy | Secret location | Authorization / defense |
|---|---|---|---|
| Static hosting | Serve build artifacts only, source repo private | Secrets in the client **forbidden** (G3) | (backend required — see the directive below) |
| Serverless / edge functions | Private repo, deploy artifacts only | Platform env-var store (never committed) | Per-function auth, fail-closed (G11) |
| Container / self-hosted · PaaS | Source private | Container env vars | Non-root, least privilege, required ports only |
| Managed backend (Supabase/Firebase) | Source private (repo private) | Server-only keys on the server only (G3) | RLS/rules + **backend session gate** (see conflict resolution below) |

`[AI directive]` **Zion Login requires a backend.** The core flow requires server-side `GET /auth/login` (state storage) and `GET /auth/callback` (token exchange, session-row creation, permission determination) (01 core flow). Therefore **pure static hosting alone can never be complete** — even with a statically hosted front-end, the callback/session/permission backend lives on a **serverless or container type**. Keep RLS-bypassing keys such as `service_role`, and the `client_id`, only in that backend's (server-side) environment variables — never in the browser or in static files (G3, Hard Rule 1).

`[⚠ Conflict resolution]` Managed backend (conflict-resolution table row 2): guide G7 assumes "browser→Supabase anon key / browser→Firebase direct", but **Zion Login fixes identity via the backend session, not via browser-direct access.** → **Zion wins.** Even when using Supabase/Firebase as the local DB, member-data access goes **through the backend (behind the session gate)**; identity is the **고유번호 (newNo) of the Zion session**, not `auth.uid()`, and data scope is judged by `organizationPaths`. **The primary control for scope enforcement is the backend query filter** (`organizationPaths`); keep table **RLS (default-deny) enabled as a second line of defense blocking non-`service_role` paths** (G3 preserved) — `service_role` bypasses RLS, so RLS is not evaluated on `service_role` backend queries (to actually apply a '고유번호-context' RLS policy, that query must run under a role other than `service_role`).

`[⚠ Conflict resolution]` Source privacy (conflict-resolution table row 8): guide G5/G6/VC3 and Zion Hard Rule 8/E5 **do not conflict.** Adopt the Zion principle (repo always private) plus the guide's live verification (VC3, the stronger check) → actually confirm the 404 in §3.

---

## 3. Post-deploy live verification (the VC3/VC4 philosophy — verify for real, not on screen)

`[AI directive]` "Hiding things in the client/UI is not security" (R0-6, E3). Immediately after deploying, **actually attempt** the four checks below and confirm by the result. If any one fails, halt the deployment, fix the cause, and re-verify.

| # | Check | Method | Pass criterion | Rule basis |
|---|---|---|---|---|
| 1 | Source privacy | Open the repo/source URL in a **logged-out (incognito) window** | 404 (private) | VC3, G6, Hard Rule 8·E5 |
| 2 | Unauthorized DB reads blocked | Try reading member data directly with the public (anon) key, **without a session** | Rejected, or empty result (policy-allowed rows only) | VC4, G7·G8, Hard Rule 2·E3 |
| 3 | Token revalidation working | With a live session, confirm the `OAUTH2_VALIDATE_URL` (`/api/auth/v1_0/validate`) revalidation cycle | Validates every `SESSION_REVALIDATE_SECONDS` (default 300s); on `valid=false`, `success=false`, 401/403, or network error → **401 fail-closed** → front-end re-login | Hard Rule 2, session model |
| 4 | HTTPS | Access the production callback and every API over https | https end to end; `redirect_uri` **exactly matches** the registered https callback (trust `X-Forwarded-Proto` behind a proxy) | mandatory security rules |

`[바이브코더 안내]`
- **실측 1(소스 404):** 로그인 안 한 상태의 시크릿(비공개) 브라우저 창을 새로 열고, 소스가 있는 주소(예: GitHub 레포 주소)에 들어가 보세요. **"찾을 수 없음(404)"이 떠야 정상**입니다. 소스가 그대로 보이면 레포가 아직 공개 상태입니다 → 레포 → Settings → Danger Zone → Change repository visibility → **Private**로 바꾸세요.
- 실측 2~4는 AI가 대신 확인합니다. 로컬에서 명령 실행이 필요하면 AI가 안내하는 명령을 실행하세요(실행 방법은 지금 쓰는 AI에 따라 다릅니다 — `03_build_and_alpha_test.md` (개발·알파테스트 파일)의 「손잡이: 로컬 명령을 실행해야 할 때」 표 참고).

`[AI directive]` **Past-exposure check (G4).** If `.env` was ever committed/pushed, or the repo was ever public, treat the key as **already leaked** — switching to private, adding `.gitignore`, forking, or rewriting git history does not retrieve it. In that case, connect immediately to the key retrieval/reissue procedure in §4.

---

## 4. Operations · Incident response (minimal · Zion-first)

> The original Zion Login skill has **no key-retrieval procedure.** Every situation requiring retrieval is therefore handled by **requesting retrieval/reissue from HQ (총회 정보통신부 전산개발과)**. The skill/AI never sends anything to HQ automatically — the vibe coder contacts them directly.

### 4-1. Actions by situation

| Situation | Action | Rule basis |
|---|---|---|
| **Key leak** (commit history, past public exposure, suspected leak) | **Immediately** request HQ to **retire the current `client_id` and reissue a new key**. Replace it in `.env` with the reissued key, then redeploy. | G4 (treated as already leaked), D11 |
| **Staff change** | Request key retrieval/reissue from HQ (invalidates the former owner's access). The new owner operates with the new key. | D11 |
| **End of operation** | Request HQ to **retire the key** (key disposal). Delete all session rows; keep/destroy audit logs per the retention policy. | D11, session model |
| **Emergency permission revocation** | **Delete that user's session rows = forced re-login.** The next request finds no session → 401 → the updated permissions apply on re-login. | Session model |
| **Applying permission changes** | Grants/revocations for a 고유번호 (newNo) take effect **at the next login**. If immediate effect is needed, combine with the forced re-login above (session deletion). | Permission model, session model |

`[AI directive]`
- **Forced re-login = session deletion.** A Zion session has no separate local token to "revoke" — **deleting the session row is the invalidation.** Handle logout the same way, as session-row deletion (session model). Creating a `JWT_SECRET` to revoke self-issued tokens is forbidden (Hard Rule 2).
- **Keys are unique per system (D11).** Because one key per system was maintained, a leak of one system's key requires retiring and replacing only that system's key. If a key had been reused across systems, a leak would force replacing all of them at once, and HQ could not tell which system a key belongs to — that is why reuse is forbidden.

### 4-2. Audit-log retention

`[AI directive]` The following operational actions are **audit targets** and are retained in the audit table (conflict-resolution table row 6 — a gap in the guide filled by Zion; Zion adopted):

| Audit target | Item |
|---|---|
| Bulk reads | B4 |
| Permission grant/revoke | B5 |
| Exports (download / external transfer) | C2 |
| SUPER_ADMIN (`DO_EVERYTHING`) actions | D7 |

- **Never write `access_token` to general app logs, and never log `newNo` (고유번호) together with behavioral data** — who-did-what records live only in the audit table (mandatory security rule).
- Do not expose personal data, stack traces, or internal paths in responses, logs, or error messages (G19).

### 4-3. Key retrieval/reissue request to HQ (총회) — template for the vibe coder

`[바이브코더 안내]` 아래를 채워 총회(총회 정보통신부 전산개발과)에 **직접** 보내세요. AI가 대신 보내지 않습니다. (접수 경로를 모르면 `02_spec_and_alpha_key.md` (기획안·알파키 신청 파일)의 알파키 신청 창구 안내 참고.)

```
[시온로그인 키 회수/재발급 요청]
- 시스템명:
- 지파:
- 사유: (키 유출 / 담당자 변경 / 운영 종료 중 택1)
- 현재 키 상태: (커밋 이력 있음 / 과거 public 노출 있음 / 미상 등)
- 요청 내용: 현재 client_id 회수 및 (필요 시) 신규 키 재발급
- 연락처(담당자):
```

- 유출이 의심되면 **회수 요청을 먼저 보내고**, 재발급 키를 받은 뒤에 `.env`를 교체하세요. 유출된 키는 그대로 두면 계속 위험합니다.

---

## 5. [Check] Deployment completion criteria

Every item below must be met for the deployment to count as complete. If any is unmet, fix that item and re-check.

- [ ] **Prerequisites:** `04_predeploy_verification.md` report with 0 blocking findings + the "프로덕션 운영 가능" verdict; production key issued via `05_production_key_request.md`.
- [ ] **Production switch:** production key injected into `.env`, `alpha-` prefix removed from the endpoints, no-`JWT_SECRET` re-confirmed, `/oauth/` paths, `v3_0/me`, and no-`client_secret` preserved.
- [ ] **Hosting:** type finalized + per-type setup (source private, secrets in env vars, private repo). The callback/session/permission backend runs on a server (serverless/container), and neither `service_role` nor `client_id` is in the client.
- [ ] **Post-deploy verification, all 4 passed:** source URL 404 · unauthorized public-key DB reads blocked · token revalidation (fail-closed) working · HTTPS end to end.
- [ ] **Operations readiness:** forced re-login (session deletion) procedure confirmed; audit logs (B4·B5·C2·D7) working; the HQ key-retrieval channel known; no past exposure (G4), or reissue completed.

---

## [Next step]

- **The full flow is complete.** Pre-development canon injection (`01_zion_login_canon.md`, `01b_common_security_conflicts.md`) → spec & alpha key (`02_spec_and_alpha_key.md`) → build & alpha test (`03_build_and_alpha_test.md`) → pre-deploy verification (`04_predeploy_verification.md`) → production key (`05_production_key_request.md`) → deploy & operations (this file).
- **Re-verification on change:** any change to code, permissions, data scope, endpoints, or hosting **must be re-verified starting from `04_predeploy_verification.md`** before redeploying. Never push to production unverified.
- **To handle member data beyond the 4 fields (NAME, NEW_NO, ORGANIZATION_PATH, ORGANIZATION_WITH_DUTY)**, HQ approval comes first (Hard Rule 3) — never add fields without approval.
- Keep one production key per system (D11) — on redeploys or migrations, request a separate key if it is a new system.
