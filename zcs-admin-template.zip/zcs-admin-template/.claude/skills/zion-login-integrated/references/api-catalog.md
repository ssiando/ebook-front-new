# Zion Login API Catalog — Downstream Edition

Verified against the ZAuth alpha OpenAPI spec (2026-06-12; `https://alpha-api.ziongroup.net/v3/api-docs`). Prod base drops the `alpha-` prefix. This edition lists only what tribe apps may call. The OAuth2 auth-server endpoints (`{AUTH_URL}/oauth/authorize`, `{AUTH_URL}/oauth/token` — path `/oauth/`, NOT `/oauth2/`) are not in that spec; their canonical values live in `01_zion_login_canon.md` (SKILL.md in the standalone skill).

## Common response envelope (every endpoint)

```jsonc
{
  "success": true,            // ALWAYS check — HTTP 200 with success=false is a real failure mode
  "data": { ... },
  "error": { "type": "UNAUTHORIZED|AUTHENTICATION|BAD_REQUEST|FORBIDDEN|NOT_FOUND|NETWORK|SERVER_ERROR|UNKNOWN",
             "code": "ZAT-04001", "message": "..." },
  "traceId": "...",           // include in error logs when reporting issues to HQ
  "datetime": "..."
}
```

## 1. Member info — `GET /api/auth/v3_0/me` (Bearer access_token)

Query `properties` = comma-joined enums. **Downstream ceiling: `NAME,NEW_NO,ORGANIZATION_PATH,ORGANIZATION_WITH_DUTY`** (singular `ORGANIZATION_WITH_DUTY` — the plural is rejected and breaks login). Other properties exist upstream (MOBILE, EMAIL, ADDRESS, BIRTHDAY, SEX, PICTURE, …) — do not request them without HQ approval.

Response `data` (`MeDtoV3`): `{ id: int64, nickname, properties: {...} }`. Only requested fields are populated (camelCase):

| Field | Type | Notes |
|-------|------|-------|
| `name` | string | 이름 |
| `newNo` | string | 고유번호 — public unique key, e.g. `"00341130-00036"` |
| `organizationPaths` | `ZatOrganizationDto[]` | 소속: tribe → church → … path |
| `organizationWithDuties` | `OrganizationWithDutyDto[]` | **plural key** (request is singular) — the RBAC input |

`OrganizationWithDutyDto`: `{ organization: ZatOrganizationDto, duty: DutyDto, type: "MEMBER"|"DUTY" }` — filter `type == "DUTY"` for permission resolution.
`DutyDto`: `{ id: string, name: string, positionName: string }` — match on `id` only; `positionName` is mutable per spec.

`ZatOrganizationDto` (exact enums):
```
{ id: int64, name, type: ROOT|TRIBE|CHURCH|DEPARTMENT|AREA|TEAM|CELL|CUSTOM|DE24|DE24_DEPT|DUTY|ORG_UNIT,
  parentId: int64, chartId, depth: int32, sibling: int32, meta: map<string,string>,
  level: HEAD|TRIBE|CHURCH|ADMIN_DEPARTMENT|NONE, syncCode }
```
Map only the levels you recognize (HEAD/TRIBE/CHURCH); treat ADMIN_DEPARTMENT and unknowns as NONE.

Use **v3_0** only. `v2_0/me` returns an untyped properties map — do not use.

## 2. Token validation — the session revalidation endpoint

- `GET /api/auth/v1_0/validate` — Bearer access_token → `data: {valid: boolean}` (401/403 use the standard error envelope). **This is the per-interval session revalidation call** in this edition's session model: any non-valid outcome (valid=false, success=false, 4xx, network error) kills the session, fail-closed.
- `POST /api/auth/v1_0/access_token/validate` — body `{"accessToken": "..."}` → `{valid}`. Validates a token passed by value; useful in a worker that holds the raw token transiently. Prefer the GET/Bearer form in request middleware.

## 3. Org lists (public, no auth) — reference-data migration sources

- `GET /api/external/v0_0/tribes` → `data: [{ id: string, name, headChurch }]`
- `GET /api/external/v1_0/churches?tribeId={tribeId}` → `data: [{ id: string, name, tribeId: string, enabled: boolean }]` (`enabled→is_active`)
- **Tribe/church `id`s here are strings**, while org-tree/`organizationWithDuties` ids are int64 — they do not interchange; store both mappings deliberately.
- Sync rule: idempotent upsert + **soft-deactivate, no hard delete** (FK safety); run in the deploy migrate step; HTTP calls inside schema migrations are forbidden (migrations must be deterministic and offline).

Org tree, when tribe/church lists aren't enough:
- `GET /api/external/v1_0/organizations?organizationChartId=...` (required; optional `parentId`, `type`, `depthLessThan`, `withDescendants`) → `data: ZatOrganizationDto[]`
- `GET /api/external/v1_0/organizations/{id}` → one node.

## 4. Duty catalog (optional — display reference only)

Permissions are resolved by 고유번호, so these are NOT required for RBAC. Use them only if you want richer 직책 display data (labels, grouping) in the member directory.

- `GET /api/external/v1_0/duties?name=&positionName=` → `data: DutyDto[]` — duty catalog for display labels.
- `GET /api/external/v1/duty-groups` → `data: [{code, name, dutyIds: string[]}]` — duty grouping for display.

## 5. user-authorities — SUPER_ADMIN detection ONLY

`GET /api/external/v1/user-authorities` (Bearer access_token) → `data`:
```jsonc
{
  "global": { "roleBased": [{ "permissions": ["DO_EVERYTHING", ...] }], "orgBased": [...] },
  "app":    { "roleBased": [{ "permissions": [...] }],                  "orgBased": [...] }
}
```
Downstream reads this for one boolean: **is `DO_EVERYTHING` present in `global.roleBased ∪ app.roleBased` permissions?** → SUPER_ADMIN. Ignore `orgBased` and every other permission name; ordinary permissions come from the local 고유번호 table. Fail-closed: non-200, `success=false`, or any error → not super. ZAuth returns `DO_EVERYTHING` (never `SUPER_ADMIN`).

## 6. What NOT to call (downstream)

- **`/api/external/*/user-authorities*`** — call it for **exactly one purpose: detecting the `DO_EVERYTHING` master → SUPER_ADMIN** at login (see permission-model.md §3). Do NOT use it as a source of ordinary permissions — those come from the local 고유번호 table. Reading `orgBased`/non-master `roleBased` into the permission set would create a second, conflicting permission source.
- **Anything requiring an Admin Key** — tribe apps are Bearer-REST-only; there are no server-to-server member-data calls. Member data refreshes only at user login.
- `/api/admin/*`, `/api/resource/*`, `/api/internal/*`, `/api/adhoc/*`, `/api/debug/*` — platform internals.
- Other apps' `/api/external/*` domain endpoints (SMS, OTP, offerings, attendance, …) — integrate only if your product owns that domain and HQ says so.
- Anything marked Deprecated in the spec (`v1_0/app_users/{id}`, `v1_0/zion_members/{newNo}/private_info`, `MeDto.status`, `cost`).
