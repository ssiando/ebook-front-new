# Mandatory Privacy & Security Review (built-in gate)

This review is part of this skill, not an optional add-on. Run it **before delivering any feature that displays, stores, logs, exports, or downloads member data**, and again **before the first production deploy**. The reviewer role can be a separate agent or a separate pass by the builder — but the checklist below must be walked item by item against the actual code, not from memory of what the code "should" do.

**Verdicts per item:** `PASS` / `FINDING (blocking)` / `FINDING (advisory)` / `N/A (state why)`.
**Delivery rule:** zero blocking findings. Advisory findings ship with an owner and a date.

## A. Exposure (개인정보 노출)

| # | Check | Why it matters |
|---|-------|----------------|
| A1 | Every API response returns only the fields its screen needs — no `SELECT *`-style serialization of user rows | Over-response is the most common leak: the UI hides a field but the JSON still carries it |
| A2 | Member data never appears in URLs/query strings (search by 고유번호 uses POST or a request body) | URLs land in access logs, browser history, and proxies |
| A3 | Application logs contain no `name`+`newNo` pairs, no org+duty dumps, no member-list payloads; the access_token never appears in any log | Logs outlive the request and are widely readable; audit tables are the sanctioned who-did-what record |
| A4 | Error messages and 4xx/5xx bodies leak no member data, stack traces, SQL, or internal identifiers | Errors are shown to the wrong audience by definition |
| A5 | List screens show the minimum identity set (name, 소속, 직책, 고유번호 where operationally needed); no field the viewer's role doesn't need | Every extra column is standing exposure to every viewer of that screen |
| A6 | No developer terminology in end-user UI: no permission codes, enum values, internal IDs, or the word "ZAuth" | Non-developer UX rule; also reduces what an attacker learns from screenshots |
| A7 | Browser storage holds only the access_token (no cached member lists / permission dumps in localStorage) | Client storage is readable by any script that gets in |

## B. Management (개인정보 관리)

| # | Check | Why it matters |
|---|-------|----------------|
| B1 | Collected fields = exactly `NAME, NEW_NO, ORGANIZATION_PATH, ORGANIZATION_WITH_DUTY`; any extra property request has recorded HQ approval | Data minimization is the ceiling rule of this edition |
| B2 | A written retention rule exists per stored artifact (user rows, sessions, audit rows) and a purge actually runs (job or startup task) | "We keep it forever by accident" is a PIPA finding, not a default |
| B3 | Sessions store the token **hash**, never the raw token; expired sessions are purged | A session-table dump must not be a token dump |
| B4 | Access to member-data admin screens/APIs requires a specific permission, and reads of bulk member data are audit-logged (who, when, what scope) | Religious-affiliation data is special-category — access accountability is required, not optional |
| B5 | Every 고유번호 permission grant/revoke has an audit row; the bootstrap `SUPER_ADMIN` 고유번호 is a real intended operator, not a leftover test value; `SUPER_ADMIN` assignments are minimal and justified | The permission table is the SSOT — unaudited changes there are invisible privilege escalation, and a stray master grant is total compromise |
| B6 | Member data snapshots (name/org/duty in the local user table) are refreshed at login and not manually edited | Locally edited copies drift from the registry and become a shadow member database |

## C. Download / Export (다운로드·내보내기)

| # | Check | Why it matters |
|---|-------|----------------|
| C1 | Every export/download of member data is gated by a dedicated `*_EXPORT`/`*_DOWNLOAD` permission code — never bundled into a generic VIEW/MANAGE | Exports are the exfiltration path; they must be individually grantable and revocable |
| C2 | Each export is audit-logged: actor, timestamp, filter/scope, row count | A leak investigation starts from this table; without it there is nothing to investigate |
| C3 | Exports respect the caller's data scope (own church/tribe filter applied server-side, not by the UI) | A scope filter only in the frontend is no filter |
| C4 | Export content is the on-screen minimum set — exports never widen fields beyond what the source screen shows | "The CSV has extra columns" is a classic silent leak |
| C5 | No scheduled/unattended bulk exports of member data; no export endpoints callable without a user session | Unattended exports have no accountable actor |
| C6 | Exported files carry no misleading permanence (temp files cleaned up server-side; no member-data files committed to the repo or left in shared storage) | The file outlives the permission that created it |

## D. Fine-grained Security Risks (보안 리스크)

| # | Check | Why it matters |
|---|-------|----------------|
| D1 | `state` is random, stored, and verified on callback; mismatch = hard reject | CSRF on the OAuth callback = account linking attacks |
| D2 | No self-issued JWT anywhere; no `JWT_SECRET` in config; the ZAuth access_token is the only session credential | Hard rule of this edition — a local token means an unauditable parallel auth path |
| D3 | Session revalidation against `GET /api/auth/v1_0/validate` runs at the configured interval and **fails closed** (network error = 401) | A revoked Zion account must not keep a live session here |
| D4 | Every API route declares a required permission; routes without one are consciously public and listed as such | An undeclared route is an unauthenticated route waiting to be found |
| D5 | Object-level checks on every ID-taking endpoint (IDOR): the caller's scope is verified against the *fetched* object, not the request parameter | Sequential IDs + missing object checks = full data walk |
| D6 | All queries parameterized; no string-built SQL; user input validated at the boundary | Injection anywhere near member data is a breach |
| D7 | Permission resolution is fail-closed (unknown 고유번호 / lookup error / empty → empty set); `SUPER_ADMIN` actions still audit-log | Fail-open RBAC fails exactly when the data is most interesting |
| D8 | CORS restricted to the configured origins; cookies (if any) are Secure+HttpOnly+SameSite; HTTPS enforced end to end | Token theft vectors |
| D9 | `client_id` and env secrets are not committed; `.env.example` carries placeholders only | Repo history is forever |
| D10 | Dependencies with known critical CVEs resolved before deploy | The auth stack is only as strong as its weakest wheel |
| D11 | The `client_id` is unique to this system — not a key reused from another app/site/tribe | Reuse breaks per-system attribution and forces fleet-wide rotation on any single leak (HQ master testing is the only exception) |

## E. Access boundary & repository (접근 경계·저장소)

The trigger for requiring login is **internal information**, a broader category than personal data. Internal information = anything not intended for the public: member data, external-contact lists, org/operational intelligence, strategy, non-public notices. A system may hold no personal data yet still be internal (e.g. an internal dashboard of aggregated stats) — it still needs login.

| # | Check | Why it matters |
|---|-------|----------------|
| E1 | If the system exposes ANY internal information, it sits behind Zion Login (real server-side auth). Personal data is not the threshold — internal information is | The common mistake is "no 개인정보 → no login". Internal info that isn't personal data still must not be public |
| E2 | If the system holds truly ZERO internal information (purely public content), login is correctly absent — don't gate public pages for no reason | Over-gating public content is friction with no security value; the rule is scoped to internal info |
| E3 | Authentication is enforced **server-side**. A client-side password/overlay/localStorage flag is NOT a boundary — it ships the data before it checks | Client gates are theater: the payload already reached the browser (see the scj_news review) |
| E4 | The data payload is delivered only *after* a server-side auth check — never inlined into a page or returned by an unauthenticated endpoint | "Password prompt over already-loaded data" is the canonical failure |
| E5 | The Git repository (GitHub/GitLab) is **private**. Verified at first push and re-verified here | A public repo is itself an internal-information disclosure — endpoints, data shapes, structure, and history leak regardless of externalized secrets |
| E6 | No live endpoint URLs, deployment IDs, or credentials committed to the repo; `.env.example` holds placeholders only | Even in a private repo, minimize what a single access grant exposes |

## Report format

Write the report next to the feature's spec or PR description:

```markdown
## Privacy & Security Review — {feature} ({date})
Reviewer: {who} · Scope: {files/endpoints/screens}

| Item | Verdict | Evidence / location | Fix |
|------|---------|---------------------|-----|
| A1   | PASS    | events.py:serialize_event returns 4 fields | — |
| C2   | FINDING (blocking) | export_members has no audit write | add audit row before stream |
...

Blocking findings: {n} → all fixed at {commit} / delivery blocked
Advisory findings: {n} → owner + due date listed above
```

Re-run only the affected sections when a follow-up change is small; re-run the full checklist for anything touching auth, sessions, permissions, or exports.

## Production key request (총회 정보통신부 전산개발과)

The production `client_id` request to HQ is written **only after** this review completes with zero blocking findings. The five items below are all mandatory; the request is the review's output, not a separate formality. Send it in Korean (the operational language of the recipient).

> **Integrated edition note:** the canonical request template for this guide is in `05_production_key_request.md` — it extends this original with the automated-scan evidence (report_id, code fingerprint, file-manifest fingerprint, FAIL 0 · NEEDINPUT 0). Use the 05 template; the version below is preserved as the original skill's form, updated to the five review areas.

```markdown
# 시온로그인 프로덕션 키 신청 — {시스템명} ({지파})

## 1. 기능
{시스템이 하는 일 요약. 회원 데이터를 다루는 화면/API 목록 —
 조회 항목은 이름·소속·직책·고유번호로 제한됨을 명시}

## 2. 사용부서
{운영 주체 부서, 실제 사용 부서/직책 범위, 예상 사용자 규모}

## 3. 개인정보처리시 우려할 점
{정직하게 기술: 예) 명단 화면의 상시 노출 범위, 다운로드 기능 유무,
 각 우려에 대한 완화 조치(권한 코드, 감사 로그, 스코프 필터)를 짝지어 기술}

## 4. 보안점검결과 (요약)
- 점검일 / 점검자: {date} / {who}
- 체크리스트: zion-login 스킬 내장 5개 영역(노출·관리·다운로드·보안리스크·접근경계) 전 항목
- 자동 점검(tools/security_scan.py): report_id {report_id} · FAIL 0건 · NEEDINPUT 0건 ·
  코드 지문(SHA-256) {fingerprint} · 파일목록 지문(SHA-256) {manifest_hash}
- 결과: blocking {0}건 (전건 조치 완료), advisory {n}건 (조치 계획 첨부)
- 상세 리포트 위치: {repo path / 문서 링크}

## 5. 프로덕션 운영 가능 여부
{가능 / 불가} — {근거 한두 문장. "가능"일 때만 본 신청을 발송한다}
```

If item 5 cannot honestly say 가능, the request does not get sent — fix, re-review, then send.
