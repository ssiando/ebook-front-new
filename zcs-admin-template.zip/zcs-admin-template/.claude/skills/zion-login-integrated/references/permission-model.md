# Local Permission Model (고유번호 기반 로컬 권한)

The downstream permission canon. Zion Login provides *who the user is* (name, affiliation, duties); *what they may do* is decided by a local table keyed on **고유번호 (newNo)**. The one exception is the master role: **SUPER_ADMIN is detected via ZAuth user-authorities (the `DO_EVERYTHING` authority)** and needs no local row. That single check is the only use of user-authorities — ordinary permissions never come from ZAuth.

## Why 고유번호, not duty

An earlier design mapped permissions to duty IDs. **It is deliberately dropped downstream**: tribe (지파) duties are numerous and complex, department-conditioned, and unstable enough that maintaining a correct duty→permission matrix is more burden than value for a single tribe site. So the downstream edition resolves permissions **directly by 고유번호**: a super-admin decides "이 사람(고유번호)에게 이 권한" and that is the whole model. Duty (직책) is still fetched from Zion Login, but only for **display** (member directory / profile) — never as a permission input.

## 1. Principles

- **고유번호 is the key.** Every ordinary permission is a row tying a 고유번호 to a permission code. There is no duty rule, no org rule — just the assignment table.
- **SUPER_ADMIN is the master, detected via ZAuth.** SUPER_ADMIN is the reserved local master role that **wraps ZAuth's global master authority `DO_EVERYTHING`**. At login the app calls **user-authorities once**; if `roleBased` (global or app) contains `DO_EVERYTHING`, the user is SUPER_ADMIN — all access, bypassing per-permission checks, **with no DB row**. This is the single, exclusive use of user-authorities. A local `SUPER_ADMIN` grant row is an optional offline fallback.
- **The table is the SSOT.** No external console to sync with — whatever the table says IS the permission system. That is why the management page must itself be permission-gated and every change audited.
- **Fail-closed.** Unknown 고유번호, resolution error, empty assignment → empty permission set. Never default-allow.
- **Permission ≠ scope.** A permission code says *what* may be done. *Whose data* it applies to is derived separately from `organizationPaths` (tribe/church) and applied as a query filter on every data route.

## 2. Schema (stack-neutral SQL — adapt types to your stack)

```sql
-- Permission catalog: the definition table. Seeded by migration, served to the guide page.
CREATE TABLE permissions (
  code        TEXT PRIMARY KEY,   -- UPPER_SNAKE, e.g. EVENT_MANAGE. Internal only — never rendered to end users
  label       TEXT NOT NULL,      -- user-facing name (ko)
  description TEXT NOT NULL,      -- user-facing plain-language description (ko)
  menus       TEXT,               -- accessible menus, display metadata
  data_scope  TEXT                -- ALL | TRIBE | CHURCH | DEPARTMENT — documentation of the intended scope axis
);

-- The model: permissions assigned directly to a 고유번호. SUPER_ADMIN lives here too (code='SUPER_ADMIN').
CREATE TABLE user_permissions (
  id              BIGINT PRIMARY KEY,
  new_no          TEXT NOT NULL,      -- grantee 고유번호
  permission_code TEXT NOT NULL REFERENCES permissions(code),
  reason          TEXT,               -- optional note ("교육부 담당자" 등)
  granted_by      TEXT NOT NULL,      -- granter 고유번호
  granted_at      TIMESTAMPTZ NOT NULL,
  revoked_by      TEXT,
  revoked_at      TIMESTAMPTZ,        -- soft revoke — history preserved
  UNIQUE (new_no, permission_code, revoked_at)
);
CREATE INDEX ix_user_permissions_new_no ON user_permissions (new_no) WHERE revoked_at IS NULL;

-- Audit: every assign/revoke.
CREATE TABLE permission_audit (
  id         BIGINT PRIMARY KEY,
  action     TEXT NOT NULL,           -- GRANT | REVOKE
  new_no     TEXT NOT NULL,           -- target 고유번호
  permission TEXT NOT NULL,
  actor      TEXT NOT NULL,           -- actor 고유번호
  reason     TEXT,
  at         TIMESTAMPTZ NOT NULL
);
```

No `duty_permissions` table exists in this edition — that is intentional.

## 3. Resolution Algorithm (at login, stored into the session)

```
# SUPER_ADMIN comes from ZAuth authorities (no DB row); local grant is a fallback.
is_super = DO_EVERYTHING in user-authorities.roleBased(global ∪ app)   # fail-closed: error → False
          OR "SUPER_ADMIN" in local user_permissions(new_no)           # optional offline fallback

if is_super:
    effective = ALL          # master bypass — every permission check passes, no code enumeration needed
else:
    rows = user_permissions where new_no == user.new_no and revoked_at IS NULL
    effective = { r.permission_code for r in rows }   # exactly the assigned codes; empty on error (fail-closed)

scope = derive tribe/church ids from organizationPaths   # applied on data routes regardless of effective
```

- ZAuth returns the master authority as **`DO_EVERYTHING`** (role `super-admin`, id `*:ROLE:DO_EVERYTHING`) — it never returns the name `SUPER_ADMIN`, so match on `DO_EVERYTHING`. `SUPER_ADMIN` is our local role name wrapping it.

- Resolution happens **once at login** (the callback) and is stored in the session row. Assignment changes take effect on the user's next login; for urgent revocation, delete the user's sessions (force re-login).
- `SUPER_ADMIN` bypasses individual permission checks but **never bypasses the audit log** and never silently widens data scope — master actions are still recorded, and if a master action crosses org scope that is logged too.
- Every API route declares its required permission explicitly. A route with no declared permission is a review finding, not a convenience. `SUPER_ADMIN` satisfies any declared permission.

## 4. Bootstrap (mostly solved by DO_EVERYTHING)

The first-run problem — an empty `user_permissions` table means nobody can open the management page — is normally **solved for free**: whoever holds `DO_EVERYTHING` in the member registry logs in, ZAuth authorities returns it, and they are SUPER_ADMIN on day one with no seeding. They then assign permissions (and delegate `PERMISSION_ADMIN`) to other 고유번호s.

**Offline fallback (optional).** If a deployment can't reach user-authorities, or nobody holds `DO_EVERYTHING`, seed one local master row: `user_permissions(new_no = <operator 고유번호>, permission_code = 'SUPER_ADMIN', reason = 'bootstrap', granted_by = 'system')` (idempotent upsert; from a `BOOTSTRAP_SUPER_ADMIN_NEWNO` setup value). The privacy/security review checks that a lingering bootstrap row is a real intended operator, not a leftover test value.

## 5. The Two Mandatory Pages

### ① Permission guide (권한 안내) — any authenticated user
- Full catalog rendered from the DB: **label + description** (never the UPPER_SNAKE code), what it allows, accessible menus, data scope in plain words.
- "My permissions" section: what the current user holds, in user language ("관리자가 부여한 권한"). A super-admin sees a "전체 관리자(모든 권한)" indicator. Never mention ZAuth or console names.
- Locked features show *why* in user language (which permission, how it is obtained) — not an error code.

### ② Permission management (권한 관리) — `SUPER_ADMIN` (or delegated `PERMISSION_ADMIN`) only
- Search a member by **고유번호** → confirm identity (name, affiliation shown) → select one or more permission codes by **label** → optional note → grant. The 고유번호 is shown in full and labeled '고유번호' (it is the working key here).
- Active assignments list (grantee 고유번호, name, permission label, granter, date) + revoke (soft) button.
- Grant/revoke **audit history** table (who, when, to whom, which permission).
- Assigning `SUPER_ADMIN` to another 고유번호 requires an explicit confirm step (it grants total access) and is prominently flagged in the audit view.
- This page is the most sensitive surface in the system — gate it with `SUPER_ADMIN`/`PERMISSION_ADMIN`, audit every action, and cover it explicitly in the privacy/security review.

## 6. Catalog Design Guidance

- Code naming: `{DOMAIN}_{ACTION}[_{SCOPE}]` UPPER_SNAKE. Granularity sweet spot: `VIEW` / `MANAGE` (create+update+delete bundled) / `OPERATE` / `EXPORT`. One code per HTTP method is over-engineering.
- **Sensitive actions get their own codes** — anything that exports or bulk-reads member data (`*_EXPORT`, `*_DOWNLOAD`) is always a separate code, because these are the exfiltration paths the review gate scrutinizes.
- Reserved codes: `SUPER_ADMIN` (local master role — wraps ZAuth `DO_EVERYTHING`; never reuse for another meaning), `PERMISSION_ADMIN` (may open page ②; delegates permission management without full master access). `DO_EVERYTHING` is the ZAuth authority name checked at login — it is not a code you register locally.
- The spec's permission table (code, label, description, features, menus, scope) is the design-time artifact that becomes the seed migration.
