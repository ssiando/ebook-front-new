---
name: zion-login-integrated
description: "Integrated canon + security guide (pre-development through deployment) for attaching Zion Login (시온로그인) to tribe (12지파) services. Merges the in-house vibe-coding security guide (G1~G24 · VC1~VC16) into the Zion Login skill; on any conflict the Zion Login standard always wins. OAuth2 login (single client_id, no client_secret), sessions use only the ZAuth-issued access_token (self-issued JWT/JWT_SECRET forbidden), member data capped at 이름·소속·직책 + 고유번호 (4 fields), permissions are local 고유번호-based RBAC (SUPER_ADMIN = DO_EVERYTHING), any internal information (incl. personal data) mandates Zion Login (only fully public content is exempt), repo must be private, and the pre-deploy integrated security verification (run tools/security_scan.py → HQ-reportable report) is mandatory. MUST be used for: 시온로그인/Zion 계정 로그인/ZAuth/OAuth2/로그인·인증·세션, 회원데이터, 권한/RBAC/직책 권한, 알파키·프로덕션키 신청, 배포전 보안점검. Never invent a new auth flow or permission model."
---

# Zion Login + Legacy Security Guide — Integrated Skill (downstream edition)

This skill is the norm for the **entire journey (pre-development → deployment)** of a tribe vibe coder attaching Zion Login. The hard rules and master principles below **always apply**; stage-by-stage detail lives in this folder's numbered files. **On any conflict, the Zion Login standard wins.**

**Language policy:** these guide files are English (AI-facing). **All user-facing output is Korean** — conversation, reports, HQ request drafts, UI copy. Blocks marked `[바이브코더 안내]` and fenced Korean templates are canonical strings: reproduce them in Korean exactly as written.

## Always-on hard rules (non-negotiable — details in `01_zion_login_canon.md`)

1. **Credential = one `client_id`.** No `client_secret`, no Admin Key, no server-to-server calls. Keys are issued by HQ (not bundled), one per system (no reuse).
2. **No self-issued JWTs.** The only session token is the Zion-issued `access_token`. The presence of `JWT_SECRET` is a violation. Session rows store only `SHA-256(access_token)`; revalidate periodically via `validate` (fail-closed).
3. **Member-data ceiling = 이름·소속·직책 + 고유번호.** Exactly `NAME, NEW_NO, ORGANIZATION_PATH, ORGANIZATION_WITH_DUTY`. Anything more requires HQ approval.
4. **Permissions resolve by 고유번호 (newNo).** The local `고유번호 → permission code` table is the SSOT. Duty (직책) is display-only, never a permission input.
5. **SUPER_ADMIN = ZAuth `DO_EVERYTHING`.** user-authorities is used ONLY for this master detection; fail-closed; master actions are still audited.
6. **The privacy/security review is a blocking gate.** Before deploying any member-data feature, the integrated checklist of `04_predeploy_verification.md` (VC1~VC16 + A~E) must pass.
7. **Anything internal goes behind Zion Login.** The trigger is **internal information** (incl. personal data — member data, contact lists, org/operational info, strategy, everything not meant for the public). Personal data or a non-identifiable sensitive aggregate alike: internal ⇒ login required; only fully public content is exempt. A client-side password gate is not authentication (server-side enforcement). *(Confirmed policy: `01b_common_security_conflicts.md` §A2 policy P-1 — consistent with the Zion canon and HQ §E.)*
8. **The repository is always private.** GitHub/GitLab repos of Zion Login / internal-information systems stay private.

## The three master principles

1. **Conflicts → Zion Login wins** — wherever the security guide (G/VC) and the Zion canon collide, the Zion standard rules (conflict-resolution table: `01b_common_security_conflicts.md`).
2. **Internal information (incl. personal data) ⇒ behind login** — even non-identifiable sensitive aggregates if internal; only fully public content is exempt; when in doubt treat as internal and add login (§A2 policy P-1).
3. **Hiding on the client is not security** — access control, permission checks, and scoping are enforced server-side.

## The 6-stage flow (read each stage's file as you go)

`[AI directive]` When this skill loads, follow **`00_START_HERE.md` (§1.5·§1.6)** for environment routing, stage loading, and the **autonomous progression protocol**. That is: **you drive the flow** — self-determine the current stage; apply the canon and rules; write and retroactively fix code; run the stage-4 scanner; auto-fix findings; generate the report; draft the HQ request texts — all **automatically**. The user is asked to do only the **"exactly three things"** (① request the alpha key ② run the automated check — on Claude Code/Codex you run it for them ③ request the production key). At the end of every stage tell the user "the one thing you do now", and never skip a stage.

| Stage | File to read | Core |
|---|---|---|
| 0. Routing · start | `00_START_HERE.md` | 3-lane environment routing (Claude Code/Codex/other AIs), start behavior |
| 1. Pre-dev (canon injection) | `01_zion_login_canon.md`, `01b_common_security_conflicts.md` | hard rules · core flow · sessions · permissions + G1~G24 merge + conflict-resolution table |
| 2. Spec · alpha key | `02_spec_and_alpha_key.md` | spec → user requests the alpha key from HQ directly |
| 3. Build · alpha test | `03_build_and_alpha_test.md` | implement on alpha- endpoints; test login/permissions/scope |
| 4. Pre-deploy verification | `04_predeploy_verification.md` (+ run `tools/security_scan.py`) | VC1~VC16 + A~E integrated judgment → **automated scan + HQ-reportable report** |
| 5. Production key | `05_production_key_request.md` | report attached → 5-item request to HQ |
| 6. Deployment · operations | `06_deploy_and_operations.md` | production switch, hosting-type deployment, key revocation |

## Automated security scanner (run in stage 4)

`[AI directive]` In stage 4, **if you have file access (Claude Code·Codex), run `tools/security_scan.py` directly** to auto-judge the machine-verifiable items, and graft its output (`security_scan_report.md`/`.json`, code fingerprint included) into the `04_predeploy_verification.md` report. Items the scanner cannot see (permissions, audit, IDOR, …) are judged by the AI per the 04 file. Execution/interpretation protocol: `04_predeploy_verification.md` §2b.

## Start behavior

- **Claude Code:** print nothing; proceed quietly (load `00` · `01` first). If what to build is unclear, quietly confirm, then proceed.
- **Other environments (direct paste):** follow the start-behavior protocol in `00_START_HERE.md`.

## Install

Copy this whole folder into the project's skill directory:

```bash
cp -r zion-login-integrated {your-project}/.claude/skills/zion-login-integrated
```

From then on, any Zion Login / login·auth / member-data / permission work in that project's Claude Code sessions auto-loads this skill. Explicit invocation: `/zion-login-integrated`. (Codex: register this folder's path in `AGENTS.md`. Other conversational AIs: start by pasting `00_START_HERE.md`.)

## References (originals preserved)

- `references/api-catalog.md` — Zion API schemas + do-not-call list
- `references/permission-model.md` — 고유번호 RBAC canon
- `references/privacy-security-review.md` — A~E review checklist original
- `references/bot-addon-optional.md` — only when a bot component exists
