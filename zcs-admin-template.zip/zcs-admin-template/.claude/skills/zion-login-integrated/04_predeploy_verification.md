# 04 Pre-Deploy Integrated Security Verification

> Verification basis: pre-deploy verification v2.0 + the Zion Login built-in review gate (A–E), integrated.
> This file is the **mandatory pre-deploy gate** of the "Zion Login + legacy security guide" integrated set.
> On any conflict, **the Zion Login rule always wins** (master principle). Detailed adjudication: §2 and §7 below.

## When to read this file

Read this after the alpha test of `03_build_and_alpha_test.md` finishes, **immediately before deployment**, and **immediately before** `05_production_key_request.md` (the production key request). Before deploying finished code or requesting a production key from 총회 (HQ), this gate must be passed. If any change touched auth, sessions, permissions, exports, or member data, re-verify **from the beginning** with this file.

## What this file contains

- The integrated pre-deploy checklist — common web hygiene **VC1–VC16** + the Zion member-data review gate **A (exposure) · B (management) · C (download) · D (security risk) · E (access boundary)**, merged into **one list** (§3).
- **[⚠ Conflict resolution]** for where the two axes examine the same thing — the Zion criterion is adopted; duplicates are judged once (§2, and per area in §3).
- **Verdict and fix rules** (V0-1–V0-9, unified with the Zion verdict words) — the AI fixes findings itself (§2).
- **A paste-ready security inspection report template** — table + blocking/advisory tallies + the **production-readiness verdict**. This report is the input to `05_production_key_request.md` (§5).
- The gist of the 11-item conflict-resolution table (Zion first) (§7).

---

## 1. Preface — what this gate is

`[AI directive]`
- The deliverable of this verification is **one security inspection report** (§5 template). Without the report, neither deployment nor the production key request proceeds.
- Review scope: the entire code to be deployed + dependency files (`requirements.txt`/`package.json`, etc.) + `.env.example` + `.gitignore` + deployment configuration.
- Review premise: the builder is not a code expert. Minimize jargon, and **the AI must fix every finding itself** (§2 V0-9).
- **Pre-emptive block — a real `.env` (V0-8, before every other rule).** If the input shows signs of a `.env` holding real tokens/keys (a filename `.env*`, non-code `KEY=value` lines with long tokens or a `digits:alphanumerics` pattern, or the user saying "my `.env`"), stop before reading, quoting, or judging anything and output only:
  ```
  ⚠ .env(실제 토큰·비밀키가 든 파일)가 입력에 포함된 것 같습니다. 검증에 필요하지 않으며 올리면 노출됩니다.
  - .env는 올리지 마세요. .env.example(자리표시자만)만 있으면 됩니다.
  - 이미 올리셨다면 토큰·키를 즉시 재발급하세요.
  - 비밀값을 지우고 코드와 .env.example만 다시 붙여넣어 주세요.
  ```
  Tools that run directly in the directory (e.g. Claude Code) **only enumerate `.env` and never open its contents** — confirm only that it exists and whether `.gitignore` covers it. Even after this block, VC1/VC2 judgment proceeds normally.

`[바이브코더 안내]`
- 지금 할 일은 하나: 배포하려는 **코드 전체와 설정 파일들을 AI에게 주는 것**이다. AI가 52개 항목을 하나씩 판정하고, 문제가 있으면 직접 고친 뒤 **보고서 1부**를 만들어 준다.
- **진짜 `.env`(실제 키가 든 파일)는 절대 붙여넣지 않는다.** `.env.example`(자리표시자만)이면 충분하다. 실수로 올렸다면 즉시 그 키를 재발급하라.
- 검증이 끝나면 AI가 만들어 준 보고서를 그대로 `05_production_key_request.md` (프로덕션 키 신청 파일) 단계로 가져간다. 보고서가 "배포 불가"면 AI가 고친 뒤 다시 검증한다.

---

## 2. Verdict Principles (VC and Zion review verdict words unified)

`[AI directive]` Unify the verdict words of the two sources onto the single axis below. Use the unified verdict word in the report, citing the original ID (VC, A–E) in the evidence.

| Unified verdict | Pre-deploy verification (VC) | Zion review (A–E) | Meaning |
|---|---|---|---|
| **적합** — pass | 적합 | `PASS` | **Every** relevant path meets the criterion (V0-7). |
| **부적합(차단·blocking)** — blocking finding | 부적합(치명) | `FINDING (blocking)` | Blocks deployment/delivery. No deploy until blocking count reaches 0. |
| **부적합(권고·advisory)** — advisory finding | 부적합(비치명) | `FINDING (advisory)` | Deploy is possible, but assign an owner and a deadline. |
| **해당없음** — N/A | 해당없음 | `N/A (reason)` | The feature does not exist in this code. Always state the reason. |
| **추가확인필요** — needs-input | 추가 확인 필요 (VC14) | — | Verdict deferred pending an external lookup (§6 C11 procedure). |

**Core verdict rules (V0-1–V0-9, consistent with the Zion review rules):**
- **V0-1.** Judge each item with exactly one of the verdict words above. No vague wording.
- **V0-2.** Every verdict cites **a short quotation of the relevant code as evidence**. If there is no code to quote, state "해당 코드 없음" (no such code).
- **V0-3.** When unsure, do not mark pass/`PASS` — rule toward the **safe side (finding)**.
- **V0-4.** Never assume a feature exists when it is not in the code. Judge **only from visible code** (the actual code, not a memory of "code usually does this").
- **V0-5.** If a quotation would contain sensitive values in the code — tokens, `client_id`, `access_token`, `newNo`, real names — mask the value as `[REDACTED]` and cite "sensitive value exposed in code" as finding evidence.
- **V0-6. Definition of critical/blocking.** Any of the following is **blocking**, and the overall verdict becomes "배포 불가" (no deploy).
  - The six critical pre-deploy items: a finding on any of **VC1·VC4·VC5·VC6·VC7·VC8**.
  - A **VC2-(d)** finding (a real `.env` leak, or a formerly-public repo indication) → no deploy until tokens are reissued.
  - **VC16** with **out-of-scope rows or sensitive columns included in the response payload** (overlaps VC5) → critical.
  - Any **`FINDING (blocking)`** among Zion review A–E (see the "default severity" column in each §3 area).
- **V0-7.** If only some paths of an item are protected and the rest are open, judge it a **finding** (pass only when every relevant path complies).
- **V0-8.** Apply the real-`.env` pre-emptive block (§1 above) **first of all**.
- **V0-9. The fixer is the AI — it fixes findings directly.** Do not stop at "fix this here, like this".
  - **With file-write access (e.g. Claude Code):** **edit the code directly**. Keep variable/function names, change only what is needed, and reflect any new secret in `.env.example` and `.gitignore` too. Leave **one line per fix stating what changed and why**, and **collect each fix's "verify with your own eyes" item, then distill them into the §5 report's 「배포 전 직접 해볼 체크(최대 5개)」 section, delivered once** (do not exhaust the user with itemized lists). **Priority for the 5 slots: ① checks tied to blocking fixes → ② permission/scope (authorization, data range) → ③ the rest** — fill in this order so permission-bypass checks never fall outside the 5 (`00_START_HERE.md` §1.5).
  - **Without write access (pure chat):** output the corrected code as **complete units (function/file level, not fragments)** so pasting alone suffices. Never instruct "edit line N".
  - For out-of-code configuration — RLS, Firebase rules, GAS server-side verification, fail-closed functions, mass assignment triggers — provide **complete, paste-ready SQL/rules/verification code**, leaving the user a single step: "paste into the dashboard/console".

`[⚠ Conflict resolution]` **When VC and A–E examine the same target, judge by the Zion criterion and list the duplicate only once in the report.** Representative overlaps: auth/session (VC5·VC6 ⟷ E1–E4·D2·D3), permissions (VC5 ⟷ D4·D5·D7), audit (VC gap ⟷ B4·B5·C2·D7), personal-data ceiling (VC11·VC16 ⟷ A1–A7·B1·C1–C6). Judge by the Zion item (A–E), marking the corresponding VC as "judged jointly under the Zion item". Details in the §7 conflict-resolution table.

---

## 2b. Running the Automated Security Scanner (machine verification + the HQ submission report)

`[AI directive]` Before judging all of §3 by eye, **let the automated scanner judge the machine-checkable items first**. This turns the gate from "self-declaration" into **reproducible evidence**. The vibe coder runs the scanner directly and submits **only the result (the report)** to 총회; the report's **code fingerprint and file-manifest fingerprint (SHA-256)** are its tamper-evidence seals. (총회 inspects using this report alone; when needed it requests the repo only as a sample audit and re-runs at the same commit to confirm the fingerprints match.)

### How to run (by execution environment)
- **Claude Code / Codex (can run files/commands):** the AI **runs it directly**.
  ```
  python tools/security_scan.py --root <프로젝트 루트>
  # 정적 배포면:    --deploy-url https://<배포주소>
  # Supabase 쓰면:  --supabase-url https://xxx.supabase.co --supabase-key <ANON_KEY> --supabase-table <표>
  ```
  The scanner is `tools/security_scan.py` in this skill folder (standard library only — no installation). Copy it into the project or invoke by absolute path. Exit code 1 = FAIL present.
- **Other chat-only AIs (cannot run commands):** the AI **outputs the full contents** of `tools/security_scan.py` for the user to save into the project, then guides the user to run the command above in a terminal and **paste back** the resulting `security_scan_report.md`. Feed that result into the §3 verdicts.

### What the scanner judges (machine verification) vs what it cannot (AI verdict)
- **Machine-verified (automatic, with evidence and fingerprints):** repo visibility (VC3/E5) · `/.git/config` exposure · `.env` in `.gitignore` and `.env.example` placeholders (VC2) · hardcoded secrets (VC1) · `JWT_SECRET` (D2) · the `/oauth/` path · `v3_0/me` · the 4-field member-data ceiling (B1) · `service_role` client exposure (G3) · raw XSS sinks (VC8, WARN) · string-built SQL (VC7, WARN) · live anon-key unauthorized-read probe (VC4, when arguments are provided) · dependency vulnerabilities (VC14).
- **AI-judged (outside scanner scope):** server-side authorization and mass assignment (VC5) · IDOR object checks (D5) · fail-closed permission resolution (D7) · audit logs (B4·B5·C2·D7) · state CSRF · actual behavior of session revalidation (D1·D3) · server-side enforcement of the data scope (C3) · internal-information login triggers (E1–E4), etc. **A scanner WARN/SKIP is not a pass — the AI must make the final judgment from the code.**

### Grafting the results into the 04 verdicts and report
`[AI directive]`
- Adopt each scanner **FAIL** as finding evidence for the matching §3 item and fix it directly (V0-9). Criticality follows §2 V0-6.
- A scanner **NEEDINPUT (추가확인필요)** means a value needed for live probing of a managed backend etc. was missing, so no verdict was possible — **never wave it through as a pass.** Following the guidance in the evidence column, the AI **explains to the vibe coder concretely where to get what, receives the value, then judges**. Examples: Supabase → dashboard → Project Settings → API — get the **Project URL and anon public key** plus the **table name** to check, and re-run with `--supabase-url/--supabase-key/--supabase-table`; Firebase → get the **contents of the Rules tab** from the console and judge whether the rules are locked. **While any NEEDINPUT remains, deployment and step 05 are forbidden.**
- Scanner **WARN/SKIP** items get their final verdict from the AI in §3 (not seen by the scanner ≠ pass).
- Carry the scan output's (`security_scan_report.md`/`.json`) **tallies, code fingerprint, file-manifest fingerprint, and report_id** verbatim into the §5 report section 「0. 자동 점검 결과」. This report is a self-contained artifact that **the vibe coder runs personally and submits only the result to 총회**; the two fingerprints (code, file manifest) are the tamper-evidence seals.
- After fixing code, **re-run the scanner** to produce a fresh report with **FAIL 0 · NEEDINPUT 0** (fingerprints refreshed). Attach that report to the final report.

---

## 3. Integrated checklist (52 items · 44 merged rows — merged rows judged once)

`[AI directive]` Judge **every item in all 8 areas below, exhaustively**. Column meanings in each table:
- **Source ID** — pre-deploy verification `VC*` or Zion review `A/B/C/D/E`. Merged items list both IDs and are judged under the Zion item as the representative.
- **Check (pass criterion)** — this state is required for 적합/`PASS`.
- **Default severity** — `blocking` (a finding blocks) / `advisory` / `deferrable`. The actual verdict applies V0-3·V0-7, ruling toward the safe side.
- **Notes** — live-probe instructions, Zion precedence, original rationale (why).

### Area 1 — Repository, secrets, source exposure

| Source ID | Check (pass criterion) | Default severity | Notes |
|---|---|---|---|
| **VC1** [G1·G2·G3] | Tokens, passwords, keys, `client_id`, internal IPs are not hardcoded — loaded from `.env`/environment variables (`os.getenv`, `process.env`, a config loader). Secrets never travel in URL query strings (`?key=`, `?secret=`) — headers only. No service_role/master key in the browser, static files, or any client code. | **blocking** | A real token string embedded in code = finding (`[REDACTED]`). Not committing `client_id` is the same verdict as Zion **D9** (merged). |
| **VC2** [G1·G4] | (a) `.gitignore` includes `.env`, (b) a separate `.env.example` is provided, (c) `.env.example` holds no real tokens (placeholders only), (d) `.env` was never committed/pushed and the repo was never public. | **blocking** | A (d) violation (leak indication) → **reissue tokens + no deploy**. If anything is missing, state which. Not git-managed → (d) is N/A. Merged with Zion **D9·E6**. |
| **VC3** [G5·G6] ⟷ Zion **E5** | Do not trust "the settings say Private" — **live-probe whether the source is actually reachable unauthenticated (without login)**. The git repo must be **private** (E5). | **blocking** | **Live probe (perform when possible):** normalize the git remote URL to HTTPS (SSH `git@host:owner/repo` → `https://host/owner/repo`, strip `.git`), then check the status code with an unauthenticated `curl` — **200 = public (finding)**, **404 = private/absent (pass)**, **403·429 = rate-limited, verdict deferred**. For static deployments also check `/.git/config` exposure (200 = full source leak = critical) and source maps. **No conflict (§7 #8): Zion principle + the guide's live probe (stronger) adopted.** If confirmed public, treat every committed secret as leaked (VC2) → reissue, and enumerate actual leaks with `gitleaks`/`trufflehog`. |
| **VC15** [G22] ⟷ Zion **E6** | No organization names, real names, internal terminology, religious terminology, internal IPs, deployment hosts, project refs, or live endpoint URLs in the code. | **advisory** | On discovery: (1) the AI externalizes the value into `.env`/config and gitignores it, (2) if it cannot be externalized, keep it but notify "this will be exposed if the code is published/shared". **A VC15 violation is not by itself a no-deploy reason (not critical).** E6 also minimizes exposure inside a private repo. |

### Area 2 — Auth, session, access boundary (Zion-first core)

`[⚠ Conflict resolution]` This entire area is **governed by the Zion Login hard rules**. Any design that newly introduces local password auth or self-issued JWTs is a finding (§7 #1·#3).

| Source ID | Check (pass criterion) | Default severity | Notes |
|---|---|---|---|
| **E1** | **Any system handling internal information (member data, personal data, contact networks, org/operations information, strategy — everything not meant for the public)** sits behind Zion Login (real server-side auth). Whether personal data or non-identifying internal aggregates — if it is internal information, login is **mandatory**. | **blocking** | §A2 policy P-1 (matches Zion hard rule 7/E1): the trigger is **internal information**. Handling internal information with no login, or with a client-side gate only, is a finding. §7 #3. **P-3 exception (small write-only public form):** login absence passes ONLY if every P-3 condition (`01b_common_security_conflicts.md` §A2) is verified in code — no read/search/manage/export path anywhere, forward-and-purge in place; judge it, don't assume it. |
| **E2** | If internal information is **truly zero** (pure public content), the absence of login is correct — do not gate public pages without reason. | advisory | Over-gating is security-free friction. The rule is scoped to internal information only. Matches 총회 §E (no rejection risk). |
| **E3** ⟷ **VC5** (partial) · R0-6 | Authentication is **enforced server-side**. Client-side passwords, overlays, and localStorage flags are not a boundary — the data has already shipped before the check runs. | **blocking** | Hiding on the client is not security (theater). §7 #3. |
| **E4** | Data payloads are delivered **only after the server-side auth check** — never inlined into pages or returned by unauthenticated endpoints. | **blocking** | The classic failure: "a password prompt on top of already-loaded data". |
| **D2** ⟷ **VC6** (critical) | **No self-issued JWT anywhere**, no `JWT_SECRET` in configuration, and the Zion `access_token` is the only session credential. | **blocking** | Zion hard rule. `[⚠ Conflict resolution]` §7 #1: guide G12 (password hashing)/generic self-managed login vs Zion → **Zion**. **Never build new local password auth.** VC6 (password handling) is reinterpreted in this context: pass requires no local password comparison, no plaintext, no hardcoded default password. If a separate non-Zion secret exists (webhook secret, etc.), apply the server-side hashing rule (bcrypt/PBKDF2) to that secret only. |
| **D1** | `state` is random, stored, and verified at the callback. Mismatch = hard reject. | **blocking** | OAuth callback CSRF = an account-linking attack. **A guide gap filled by Zion — must be judged.** |
| **D3** | Session revalidation runs against `GET /api/auth/v1_0/validate` at the configured interval (`SESSION_REVALIDATE_SECONDS`, default 300s) and is **fail-closed** (network error = 401). | **blocking** | A revoked Zion 계정 must not keep a live session here. **A guide gap filled by Zion — must be judged.** Session model details: `01_zion_login_canon.md`. |

### Area 3 — DB access control, server authorization, IDOR, over-fetch

| Source ID | Check (pass criterion) | Default severity | Notes |
|---|---|---|---|
| **VC4** [G7·G8] | **Supabase:** RLS enabled on data tables + owner/role policies, no out-of-policy rows visible with the anon key, no `anon` full-access policy or migration. **Firebase:** rules are not `if true`/`.read:true` — locked with auth + owner/role conditions, and not a flat download-everything-then-filter-in-UI structure. **GAS/custom backend:** `doGet`/`doPost` verify identity server-side and never trust a client-supplied email; admin actions only from a verified role. | **blocking** | **Live probe (perform when possible):** query each table/node over REST with the public anon key, without login → if data returns (e.g. HTTP 200 + rows), the policy is open → finding, act immediately (read-only, mask values). `[⚠ Conflict resolution]` §7 #2: identity is **the 고유번호 from the Zion session**, not `auth.uid()`. If Supabase serves as the local DB, go through the backend (behind the session gate) instead of browser-direct. **The primary control for scope enforcement is the backend query filter** (`organizationPaths`); RLS (default-deny) is the **second line of defense** blocking non-`service_role` paths (`service_role` bypasses RLS, so RLS is never evaluated on `service_role` queries → scope must be enforced by query filters). |
| **VC5** [G9·G10·G11] ⟷ **D7** | Permission decisions happen **on the server** (client-sent role/isMaster distrusted; session/localStorage permission values re-verified; no localhost auto-admin backdoor). **Mass assignment blocked** (users cannot change their own role, affiliation, or approval status; triggers/policies/RPCs pinned; new sign-ups start as pending approval). **Fail-closed** (no `if(SECRET){check}` pattern that skips the check when the secret is unset — missing secret = 401). | **blocking** | `[⚠ Conflict resolution]` §7 #5: permissions are **고유번호 RBAC**, duty-based automatic permissions forbidden, `SUPER_ADMIN` = `DO_EVERYTHING`. Permission-model SSOT: `references/permission-model.md`. Judged merged with D7 (fail-closed permission resolution: unknown 고유번호/lookup error/empty result → empty permission set). |
| **D4** | Every API route **declares its required permission**. Routes without one are consciously public and cataloged as such. | **blocking** | An undeclared route = an unauthenticated route waiting to be discovered. |
| **D5** | Object-level checks (IDOR) on **every** endpoint that accepts an ID: validate the caller's scope against **the fetched object**, not the request parameter. | **blocking** | Sequential IDs + missing object check = a full data walk. **A guide gap filled by Zion — must be judged.** |
| **VC16** [G24] ⟷ Zion **A1** | Queries/APIs fetch and return only what is needed: (a) no `select *` and no columns in the response that the screen does not display (phone, email, address, internal memos, secret tokens), (b) no downloading all rows to filter/paginate on the frontend, (c) no aggregating by downloading everything and counting on the frontend. | **blocking** (if out-of-scope rows/sensitive columns are included) / advisory (mere traffic waste) | **The judging viewpoint is the actual response payload in F12/network tab, not the code** — invisible on screen but present in the payload is still exposure. Judge separately even when RLS (VC4) is correct. **Same target as A1 → judged once under Zion A1 (merged).** Fixes: explicit column selection + server-side filtering/pagination + per-screen/per-role DTOs + server-side aggregate queries. |

### Area 4 — Permission model, audit logs (guide gaps filled by Zion — every item must be judged)

| Source ID | Check (pass criterion) | Default severity | Notes |
|---|---|---|---|
| **B4** | Member-data admin screens/APIs require a **specific permission**, and **bulk member-data reads are audit-logged** (who, when, what scope). | **blocking** | Religious-affiliation data is special-category — access accountability is mandatory, not optional. §7 #6. |
| **B5** | Every 고유번호 permission grant/revoke has an **audit row**. The bootstrap `SUPER_ADMIN` 고유번호 is a real, intended operator (not a test leftover), and `SUPER_ADMIN` assignments are minimal and justified. | **blocking** | The permission table is the SSOT — an unaudited change is an invisible privilege escalation, and a stray master grant is a total breach. §7 #6. |
| **D7** | Permission resolution is fail-closed (unknown 고유번호/lookup error/empty result → empty set). `SUPER_ADMIN` actions are still audit-logged. | **blocking** | Judged merged with VC5 (Area 3). Fail-open RBAC breaks exactly when the data is most interesting. |
| **C1** | Every export/download of member data is gated by a **dedicated `*_EXPORT`/`*_DOWNLOAD` permission code** — not bundled into generic VIEW/MANAGE. | **blocking** | Exports are the leak path — they must be grantable and revocable individually. |
| **C2** | Each export is audit-logged: actor, time, filter/scope, row count. | **blocking** | A leak investigation starts at this table — without it there is nothing to investigate. §7 #6. |

### Area 5 — Member-data exposure and minimization

| Source ID | Check (pass criterion) | Default severity | Notes |
|---|---|---|---|
| **B1** [G17] ⟷ **VC11** | Collected fields = exactly `NAME, NEW_NO, ORGANIZATION_PATH, ORGANIZATION_WITH_DUTY`. Any additional property request has a **총회 approval record**. | **blocking** | `[⚠ Conflict resolution]` §7 #4: guide G17 (general minimal collection) vs Zion hard rule 3 (exactly 4) → **the Zion 4-field ceiling**. G17 is the generic form of this ceiling. VC11 (PII) is absorbed into the B1·A·C areas. **Scope caveat:** this ceiling/prohibition covers **member data fetched from Zion** — **non-member PII** newly collected apart from Zion (public newsletter emails, etc.) is not member data, so it is not subject to this ceiling (not a reason to refuse the request); judge it under G17–G19 + gated management, audit, retention/destruction (`01b_common_security_conflicts.md` §A2 P-1). |
| **A2** | Member data never appears in URLs/query strings (고유번호 search uses POST or the request body). | **blocking** | URLs persist in access logs, browser history, and proxies. **A guide gap filled by Zion — must be judged.** |
| **A3** ⟷ **VC12** | Application logs contain no `name`+`newNo` pairs, no org+직책 dumps, no member-list payloads. `access_token` appears in no log. | **blocking** | Logs outlive requests and are read widely; the audit table is the canonical who-did-what record. Merged with VC12. |
| **A4** ⟷ **VC12** | Error messages and 4xx/5xx bodies leak no member data, stack traces, SQL, or internal identifiers. | **blocking** | Errors are, by definition, shown to the wrong audience. |
| **A5** | List screens display only the minimal identity set (이름, 소속, 직책, and 고유번호 where operationally needed) — no fields unnecessary for the viewer's role. | advisory | One extra column is permanent exposure to every viewer of that screen. |
| **A6** | No developer terminology in end-user UI: permission codes, enum values, internal IDs, and the word **"ZAuth"** must not appear. | advisory | The non-developer UX rule + shrinks what screenshots can leak. Naming rules: `01_zion_login_canon.md`. |
| **A7** | Browser storage holds only the `access_token` (no cached member lists or permission dumps in localStorage). | **blocking** | Client storage is readable by any intruding script. |
| **B6** | The local user table's member-data snapshot (name/org/duty) is **refreshed at login** and never hand-edited. | advisory | A hand-edited copy drifts from the registry and becomes a shadow member DB. **A guide gap filled by Zion.** |
| **C3** | Exports respect the caller's data scope (own 교회/지파 filter applied **server-side**, not in the UI). | **blocking** | A frontend-only scope filter is not a filter. |
| **C4** | Export contents equal the screen's minimal set — no wider fields than the source screen shows. | **blocking** | "Extra columns in the CSV" is the classic silent leak. |
| **C5** | No scheduled/unattended bulk exports; no export endpoint callable without a user session. | **blocking** | An unattended export has no accountable actor. |
| **C6** | Exported files carry no misleading persistence (server-side cleanup of temp files; member-data files never committed to the repo or left in shared storage). | advisory | Files outlive the permission that created them. |

### Area 6 — Retention, destruction, session hashing (guide gaps filled by Zion — must be judged)

| Source ID | Check (pass criterion) | Default severity | Notes |
|---|---|---|---|
| **B2** | A **documented retention rule** exists per stored artifact (user rows, sessions, audit rows), and destruction actually runs (a job or a startup task). | advisory | "Kept forever by accident" is a PIPA citation, not a default. |
| **B3** | Sessions store only the **hash** of the token (never the raw token), and expired sessions are destroyed. | **blocking** | A session-table dump must not become a token dump. Session model: `01_zion_login_canon.md` (hash = `SHA-256(token)`). |

### Area 7 — Input/output safety (Zion weaknesses covered by the guide — every item must be judged)

| Source ID | Check (pass criterion) | Default severity | Notes |
|---|---|---|---|
| **VC7** [G13] ⟷ **D6** | External input is validated and parameterized. No SQL injection or command injection (`eval`/`exec`/`os.system`/user input into a shell). | **blocking** | Injection near member data is an immediate breach (D6). No string-built SQL. |
| **VC8** [G14] | User/external-origin values go through `textContent`/`escapeHtml`; no unescaped `innerHTML`/`dangerouslySetInnerHTML`. | **blocking** | **An item absent from the Zion review, covered by the guide.** One unescaped spot = finding; state the location. |
| **VC9** [G15] | Server-side fetches of user-specified URLs have a scheme/host allowlist, block private/link-local/loopback ranges, forbid redirects, and enforce timeouts and size caps; upstream status/errors are not reflected back. | advisory | **Zion weakness covered — must be judged.** SSRF. |
| **VC10** [G16] | Uploads and CSV/Excel have server-side format/size/row-count validation, and CSV exports have **formula-injection defense**. | advisory | **Zion weakness covered — must be judged.** |

### Area 8 — Transport and operational hygiene

| Source ID | Check (pass criterion) | Default severity | Notes |
|---|---|---|---|
| **D8** | CORS restricted to configured origins (`CORS_ORIGINS`); cookies (if any) `Secure`+`HttpOnly`+`SameSite`; HTTPS enforced end-to-end. | **blocking** | Token-theft vectors. **A guide gap filled by Zion — must be judged.** |
| **D11** ⟷ **VC1** (G1) | The `client_id` is unique to this system — not a key reused from another app/site/지파 (총회 master testing is the only exception). | **blocking** | `[⚠ Conflict resolution]` §7 #10: **keep** G1 (no hardcoding) + **add** D11 (per-system uniqueness, no reuse) — **both**. Reuse breaks per-system attribution and forces a full rotation on a single leak. |
| **VC12** [G19] | Error responses expose no stack traces, internal paths, or raw upstream bodies; logs hold no plaintext tokens/PII (masking). | **blocking** (if member data leaks) / advisory | Judged merged with A3·A4 (Area 5). |
| **VC13** [G21] | Limits exist against excessive requests, brute force, and abuse of paid APIs (LLM/TTS); no paid endpoint is open without auth. | advisory | **Zion weakness covered — must be judged.** Rate limiting. |
| **VC14** [G20] ⟷ Zion **D10** | Dependency vulnerabilities: known critical CVEs resolved before deployment. | **deferrable** | Requires an external vulnerability-DB lookup → low AI-only reliability. Follow the **§6 C11 procedure**; until results arrive, the verdict is **"추가확인필요 (needs-input, deferred)"**. An auth stack is only as strong as its weakest wheel (D10). |

> **Bot add-on (VB1–VB5) note:** Zion Login is web OAuth login, not a bot (§7 #11). Only when a **separate bot component exists** (Telegram/Discord bot, etc.), additionally judge all of VB1–VB5 in `references/bot-addon-optional.md` (payload gate, two-layer permissions, group behavior, deployment mode, non-injection cross-check). Do not apply them to the base web flow.

---

## 4. Verdict and Fix Execution Rules

`[AI directive]`
- Judge **all 52 items** of §3 (VC1–VC16 = 16 + review gate A1–A7·B1–B6·C1–C6·D1–D11·E1–E6 = 36) **exhaustively**, across the 44 merged rows (+ VB1–VB5 if a bot exists). Merged rows are judged once under the Zion item, citing the corresponding VC in the evidence.
- **The AI fixes findings directly (V0-9).** With file access, edit the code; without it, output complete function/file-level code. Provide RLS, Firebase rules, GAS verification, fail-closed functions, mass assignment triggers, and audit-log inserts as **paste-ready complete artifacts**, and reflect any new secret in `.env.example` and `.gitignore` too.
- **If 4 or more critical/blocking findings exist**, to avoid response truncation fix the critical ones first (VC1·VC4·VC5·VC6·VC7·VC8) + Zion blocking items, then instruct: "after these fixes, re-run this verification from the beginning and continue with the remaining items".
- **Re-verification triggers:** any change touching auth, sessions, permissions, exports, or the member-data scope re-runs **the whole checklist from the beginning**. Small follow-up changes re-run only the affected areas.

`[Check]` Verify the following right before the overall verdict (if anything was missed, go back, judge it, then produce the result).
- [ ] V0-8 applied first of all (real-`.env` upload/directory exposure checked up front).
- [ ] VC1–VC16 + A–E (A1–A7·B1–B6·C1–C6·D1–D11·E1–E6) judged exhaustively. VB1–VB5 added if a bot exists. VC14/C11 may be deferred.
- [ ] Output item 0 (verification-basis version line) produced.
- [ ] VC2-(d)·E5 checked — on leak/public indications: token reissue + no deploy.
- [ ] Every verdict has evidence (a code quotation or "해당 코드 없음").
- [ ] Every finding fixed by the AI per V0-9 (direct code edit or complete code output, names preserved).
- [ ] "배포 불가" on any critical (VC1·VC4·VC5·VC6·VC7·VC8) or Zion blocking finding.
- [ ] If VC14 is deferred, cap at "조건부 가능" + instructions to submit the dependency results.
- [ ] Sensitive values masked `[REDACTED]` (V0-5).

---

## 5. Paste-Ready Security Inspection Report Template

`[AI directive]` Generate the report exactly in the order and format below. This report is the input to `05_production_key_request.md`. Fill `{ }` with real values.

```markdown
# 보안점검 결과 보고서 — {시스템명} ({지파})
검증 기준: 배포전-검증 v2.0 + 시온로그인 리뷰게이트(A~E)
점검일 / 점검자: {date} / {who}
개발 시 사용 버전: {공통 vX.Y[ + 봇애드온 vX.Y] / 미확인}
검토 범위: {파일/엔드포인트/화면 목록}
리포트 저장 위치: {repo 경로 / 문서 링크}

## 0. 자동 점검 결과 (tools/security_scan.py — 기계검증)
- 스캔 report_id: {report_id} · 스캐너 버전: {ver}
- **코드 지문(SHA-256): {fingerprint}** · **파일목록 지문(SHA-256): {manifest_hash}** · git commit: {commit} · 스캔 파일 수: {n}
- 집계: PASS {n} · **FAIL {n}** · **NEEDINPUT {n}** · WARN {n} · SKIP {n}
- 첨부: `security_scan_report.md` / `security_scan_report.json`(스캔 파일 목록 포함)
- 주: 스캐너 FAIL은 아래 표에 부적합으로 반영·조치했고, NEEDINPUT은 값을 받아 재실행·판정했으며, WARN/SKIP은 AI가 코드로 최종 판정했다.
  이 리포트는 결과만 제출하는 자기완결 산출물이다 — 두 지문이 위변조 방지 표지이며, 총회는 필요 시 표본으로만 레포를 요청해 재현 확인한다.

## 1. 판정 결과 표 (전항목)
| 항목ID | 판정 | 근거(코드 인용 또는 "해당 코드 없음") | 조치 |
|--------|------|----------------------------------------|------|
| VC1    | 적합 | config.py: os.getenv 로드, 하드코딩 없음 | — |
| A2     | 부적합(차단) | search?newNo=... 쿼리스트링 사용 | POST 본문으로 변경(AI 수정 완료) |
| D3     | 부적합(차단) | validate 호출 없음, 세션 무기한 | 재검증 루프 추가(완성 코드 제공) |
| C2     | 부적합(차단) | export_members에 감사 write 없음 | 감사행 삽입 후 스트림 |
| VC14   | 추가확인필요 | requirements.txt 버전 미고정 | C11 절차로 의존성 스캔 후 갱신 |
| ...    | ...  | ...                                    | ... |

## 2. 집계
- blocking(차단) 부적합: {n}건  → 목록: {VC/A~E ID …}
- advisory(권고) 부적합: {n}건  → 목록 + 담당자/기한: {…}
- 추가확인필요(보류): {n}건  → {VC14 등}
- 해당없음: {n}건

## 3. 종합 판정 (정확히 하나)
{배포 불가 / 조건부 가능(최소 수정 필요) / 조건부 가능(의존성 교차 확인 필요) / 배포 가능}
- 판정 규칙: 치명(VC1·VC4·VC5·VC6·VC7·VC8) 또는 시온 blocking 하나라도 부적합 → "배포 불가".
  VC2-(d)/E5 유출·공개 정황 → 토큰 재발급 전 "배포 불가".
  그 외 부적합 있음(= blocking 0, advisory만 잔존) → "조건부 가능(최소 수정 필요)". ※이 판정도 프로덕션 운영 가능 조건을 만족한다 — advisory는 삭제할 필요 없이 §4대로 담당자·기한과 함께 05로 이월한다.
  VC14 보류 → 최대 "조건부 가능(의존성 교차 확인 필요)"까지. 확인 완료 후에만 상위 판정.
  부적합 없음 → "배포 가능".

## 4. 프로덕션 운영 가능 여부 (05 입력)
{가능 / 불가} — {근거 1~2문장}
- **"가능"의 조건: blocking(차단) 0건(전건 조치 완료) 그리고 VC14 보류·자동 스캐너 NEEDINPUT 없음(§2b).** 이때 종합 판정이 "배포 가능" 또는 "조건부 가능(최소 수정 필요)"이면 **가능**이다 — 남은 advisory(권고)는 없앨 필요 없이 담당자·기한(조치계획)과 함께 05로 이월한다. (프로덕션 진입 게이트는 **blocking·VC14·NEEDINPUT에만** 의존한다. advisory는 게이트를 막지 않는다.)
- "불가"의 조건: blocking이 하나라도 남았거나 VC14가 미해소(보류). 이 경우 05로 진행하지 않는다 — 고치고 재검증한다.

## 5. 📋 쉽게 풀어 쓴 점검 결과 (비전문가용, 부적합·보류만)
| 항목 | 무엇이 문제인가 | 안 고치면 |
|------|-----------------|-----------|
| A2   | 이름·고유번호가 주소창에 실려 나감 | 접속기록·브라우저 기록에 회원정보가 남음 |
| VC15 | 코드에 조직명/실명이 박혀 있음 | 배포는 가능하나 코드 공개·공유 시 이 이름이 노출됨 |
| VC14 | 라이브러리 취약점 점검이 아직 미완 | 문제 발견이 아니라 담당자가 한 단계 더 점검해야 하는 상태 |

## 5b. 배포 전 직접 해볼 체크 (비전문가용 · 최대 5개)
자동 수정이 제대로 됐는지 **당신이 직접 눈으로** 확인할 것들입니다(수정마다 쌓인 확인 항목 중 가장 중요한 것만 추림). 하나씩 해보세요.
1. {예: 권한 없는 계정으로 「전체 명단」 화면을 열어 '접근 거부'가 뜨는지}
2. {예: 다른 지파/교회 계정으로 로그인해 남의 소속 데이터가 안 보이는지}
3. {예: 로그아웃(시크릿) 창으로 소스 URL 접속 시 404가 뜨는지}
4. {…}
5. {…}
- 이상하면(막혀야 하는데 열림 등) AI에게 "여기서 이렇게 나와요"라고 알려주세요.

## 6. 사용자 액션 안내 (AI가 코드로 못 하는 것만 · 각 1단계)
- {예: 레포를 private으로 전환 — GitHub → Settings → Danger Zone → Change visibility → Private}
- {예: Supabase 대시보드에 아래 RLS SQL 붙여넣기}
- {예: 유출 정황 있으면 총회에 client_id 재발급 요청}

## 7. 결과 회신 안내
이 검증 결과(판정·수정 내역·기준 버전)를 담당자(총회 정보통신부 전산개발과)에게 그대로 전달하세요.

✅ 검증 자가 점검 완료 (배포전-검증 v2.0 · VC1~VC16 + 시온 A~E 전수 판정 확인[ + 봇 VB1~VB5])
```

---

## 6. C11 Integrated Procedure (VC14 dependency check)

`[AI directive]` Keep VC14 at "추가확인필요 (needs-input, deferred)" until results are in hand.
- **Step 1 — identify the stack:** identify directly from dependency files (`requirements.txt`/`pyproject` → Python, `package.json`/lock → Node·TS, `go.mod` → Go, `Cargo` → Rust, `composer` → PHP, `Gemfile` → Ruby, `pom`/`gradle` → Java). Without files, infer from imports, library names, and extensions. If version information is missing, state "stack known but no versions — precise checking impossible", ask for the dependency file or a platform scan, and defer.
- **Step 2 — static verdict:** check version pinning and the presence of lock files.
- **Step 3 — execution branch:** if a shell can be run directly, run the audit tool and update from the results. If not, provide the commands below and update from the pasted results. Either way, defer until results exist.
- **Audit tools:** (A) No installation — if the code is on GitHub/GitLab, enable Dependabot/Dependency Scanning (but first confirm, before pushing, that `.env` is in `.gitignore` and the repo is **private** — VC2·E5). (B) Terminal:
  ```bash
  pip install pip-audit && pip-audit -r requirements.txt   # Python
  npm audit / yarn audit / pnpm audit                       # Node·TS
  go install golang.org/x/vuln/cmd/govulncheck@latest && govulncheck ./...   # Go
  cargo install cargo-audit && cargo audit                  # Rust
  composer audit                                            # PHP
  gem install bundler-audit && bundle-audit check --update  # Ruby
  ```
- **Step 4 — hand-holding guidance (fallback):** if the user struggles, walk them through opening a terminal → pasting the command → handling errors, tailored to their OS. If both the terminal and GitHub are too hard, route to "run one check with a coding agent; if still stuck, send the code and this verification result to 정보통신부 for help" (no dead ends).
- **Step 5 — result follow-up:** when the user pastes results/alerts/errors, tabulate vulnerable packages, current/recommended versions, and severity; provide upgrade commands (`pip install "pkg>=x"`, `npm install pkg@x`, etc.) and the dependency-file edit (before/after of only the changed lines), with a one-line compatibility warning for major-version changes. Afterwards update VC14 to pass and, if needed, direct a full re-verification.

`[바이브코더 안내]` VC14가 "추가확인필요"로 나오면, 그것은 문제가 발견된 것이 아니라 **한 단계 더 점검이 필요한 상태**다. AI가 안내하는 명령 한 줄을 터미널에 붙여넣거나, 코드를 private 레포에 올려 자동 점검을 켜면 된다. 막히면 코드와 이 보고서를 정보통신부에 보내 도움받는다.

---

## 7. Conflict-Resolution Table (Zion Login first) — gist of the 11 items

`[⚠ Conflict resolution]` When the security guide and the Zion Login canon conflict, **Zion Login always wins.** Below is the gist of the points that this file's verification touches (full commentary: `01b_common_security_conflicts.md`).

| # | Issue | Security-guide position | Zion position | Resolution (Zion first) |
|---|------|-----------------|-----------|-----------------|
| 1 | Auth, self-issued tokens | G12 (password hashing)/generic self-managed login | Hard rule 2: self-issued JWT and `JWT_SECRET` forbidden; session token = the Zion `access_token` | **Zion.** Never build new local password auth. Identity and sessions come from the Zion `access_token`. G12 applies only to separate non-Zion secrets (webhook secrets, etc.). → Verified at: **VC6/D2**. |
| 2 | DB access control, identity source | G7 (`auth.uid()`/Firebase auth, browser→DB direct) | The backend fixes identity from the session; permissions = local 고유번호; scope = `organizationPaths` | **Zion.** Identity is the 고유번호 from the Zion session, not `auth.uid()`. Go through the backend instead of browser-direct. The **primary scope control is the backend query filter**; RLS (default-deny) is the **second line of defense** blocking non-`service_role` paths (`service_role` bypasses RLS). G24 (minimal response) and R0-6 (server-side enforcement) agree with Zion. → Verified at: **VC4/VC5**. |
| 3 | Login trigger | Personal-data/DB criterion | Hard rule 7/E1: internal-information criterion (broader than personal data) | **Zion (agrees with §A2 policy P-1).** Handling internal information (including personal data and non-identifying sensitive aggregates) **forces login**; only fully public content is exempt. Client-side gates not recognized (R0-6·E3). Matches 총회 §E. → Verified at: **E1–E4**. |
| 4 | Minimal member-data collection | G17 (minimal-collection principle) | Hard rule 3: exactly 4 fields; more requires 총회 approval | **Zion.** The 4-field ceiling applies. G17 is the generic form of this ceiling. → Verified at: **B1**. |
| 5 | Permission model | G9/G10 (server authorization, mass assignment — generic) | Hard rules 4/5: 고유번호 RBAC, 직책 display-only, `SUPER_ADMIN` = `DO_EVERYTHING` | **Zion.** Permissions by 고유번호; duty-based automatic permissions forbidden. The G9/G10 principles (server-side, self-escalation blocked, fail-closed) still apply on top of the Zion model. → Verified at: **VC5/D7**. |
| 6 | Audit logs (guide gap) | None | B4/B5/C2/D7 | **Zion adopted.** Auditing of bulk reads, permission grants/revokes, exports, and `SUPER_ADMIN` actions is mandatory. → Verified at: **Area 4**. |
| 7 | Bulk personal-data handling | G18 (user confirmation) | C1/C2 (dedicated permission + audit) | **Both (complementary).** Bulk exports need user confirmation + a dedicated permission + audit, all three. → Verified at: **C1–C5**. |
| 8 | Non-public source/private repo | G5/G6/VC3 | Hard rule 8/E5 | **No conflict.** Zion principle + the guide's live probe (VC3, stronger) adopted. → Verified at: **VC3/E5**. |
| 9 | Start behavior, user questions | R0-1/R0-2 (never ask about security, safe defaults, 3 exceptions) | Fixed flow; human touchpoints = alpha key, 총회 approval, production verdict | **The Zion flow's touchpoints are folded into the R0-2 exceptions.** Bot auth strength (B2) only when a bot is included. → This file is the **production-verdict** touchpoint. |
| 10 | Credentials | G1 (no hardcoding) | D11 (per-system unique key, no reuse) | **Both.** Keep G1 + add D11. → Verified at: **VC1/D11**. |
| 11 | Bot add-on (B1–B5) | — | Web OAuth login (not a bot) | Apply `references/bot-addon-optional.md` additionally **only when a separate bot component exists**. Not applied to the base web flow. → Verified at: **VB1–VB5 (conditional)**. |

---

## 8. Completion Criteria for This Stage

`[Check]`
- [ ] **Automated scanner (`tools/security_scan.py`) executed** (§2b) → every FAIL and NEEDINPUT resolved (NEEDINPUT: obtain the values and re-run) → re-run to obtain a **FAIL 0 · NEEDINPUT 0 report** (code fingerprint + file-manifest fingerprint), recorded in §5 「0. 자동 점검 결과」.
- [ ] Every §3 item (VC1–VC16 + A1–A7·B1–B6·C1–C6·D1–D11·E1–E6, plus VB1–VB5 if a bot exists) judged exhaustively (scanner WARN/SKIP also finally judged by the AI).
- [ ] Every finding fixed by the AI (direct code edit or complete code output).
- [ ] The §5 report generated (tallies + overall verdict + **production-readiness verdict** included).
- [ ] Blocking findings = 0 **and** "프로덕션 운영 가능 = 가능".
- [ ] **Review track re-checked** (§A2 policy P-2): if the spec claimed the lightweight track (경량 트랙), confirm every P-2 condition still holds against the finished code (no member-list surface, no export codes, no bulk PII, scale within limits); otherwise the request goes full track.

`[Next step]`
- All completion criteria met (blocking 0 + "프로덕션 운영 가능") → proceed to `05_production_key_request.md`. This report is its input.
- Any criterion unmet (a critical/blocking finding, VC14 deferred, "운영 불가") → **fix, then re-verify with this file from the beginning.** Do not move on to `05_production_key_request.md` before passing.
- Source references: the full Zion review gate A–E is `references/privacy-security-review.md`, the permission model is `references/permission-model.md`, and API schemas + the forbidden-call list are `references/api-catalog.md`.
