# 05 · Production Key Request

## When to read this file
Read this immediately after the security inspection report of `04_predeploy_verification.md` comes out with **blocking findings = 0 + the "프로덕션 운영 가능" (production-ready) verdict**. If you are still in the alpha (development) stage, or the report does not exist yet, do not open this file.

## What this file contains
- The **prerequisite gates** for entering this stage (failing them sends you back to `04_predeploy_verification.md`).
- The **paste-ready 5-item application template** for requesting the production `client_id` (operations key) from 총회 (HQ).
- The request is **not sent automatically** (the vibe coder sends it personally) — what, to whom, how.
- The rule: **if item ⑤ "프로덕션 운영 가능 여부" is not '가능', sending is forbidden**.
- The 04 report (including the automated scan results and the **code fingerprint + file-manifest fingerprint**) goes along as the **attachment for 총회 inspection** — the developer runs the scanner personally and submits **only the result** (no repo upload); 총회 inspects via the fingerprints.
- Reconfirmation that the key is **system-unique** (no reuse — review gate D11).

---

## 0. Prerequisite Gates — stop here if not passed

`[AI directive]`
This stage takes the **security inspection report** produced by `04_predeploy_verification.md` as its only input. Unless **both** conditions below are met, do not draft or send the application; instead direct the vibe coder back to `04_predeploy_verification.md` to fix the findings and re-verify.

| Gate | Pass condition | On failure |
|---|---|---|
| G-05-1 | The report shows **blocking (critical) findings = 0** (VC1·VC4·VC5·VC6·VC7·VC8 and every critical review-gate A–E item all resolved) | Return to `04_predeploy_verification.md`. Fix the findings, re-verify, then come back to this file |
| G-05-2 | The report ends with the **"프로덕션 운영 가능 여부 = 가능"** verdict | If the verdict is '불가', sending is forbidden. Fix the underlying items in `04_predeploy_verification.md` and re-judge |

`[⚠ Conflict resolution]`
The judging authority at production-key issuance time is **the human touchpoints fixed by the Zion Login flow** (alpha key, 총회 approval, production verdict) — conflict-resolution table #9. The legacy guide's R0-1/R0-2 principle ("never ask the human about security; use safe defaults") absorbs this production verdict as **the exception where a human must explicitly declare '가능'**. The AI never declares '가능' on the human's behalf.

---

## 1. This request is not automatic

`[바이브코더 안내]`
프로덕션 키(운영용 `client_id`)는 **당신이 직접 총회에 신청**해서 받습니다. 이 스킬이나 AI가 총회로 대신 보내주지 않습니다(알파키 때와 같습니다 — `02_spec_and_alpha_key.md` (기획안·알파키 신청 파일) 참고). AI는 아래 신청서 **초안만 만들어 드리고**, 실제 발송 버튼을 누르는 것은 사람입니다.

`[AI directive]`
The skill/AI **never auto-sends** the application to 총회. Fill in the template below as a **complete, ready-to-send draft** the vibe coder can copy verbatim, and accompany it with the instruction to "send it yourself". Whether and when to send remains the vibe coder's act.

---

## 2. To whom · what · how

`[바이브코더 안내]`

| 항목 | 내용 |
|---|---|
| **누구에게** | 총회 정보통신부 전산개발과 (알파키를 받았던 곳과 동일 창구) |
| **무엇을** | 프로덕션(운영)용 `client_id` 발급 요청 + 아래 5개 항목 신청서 |
| **어떻게** | 아래 템플릿을 복사 → `{ }` 안을 당신 서비스 내용으로 채움 → 총회 창구로 직접 발송 (접수 경로를 모르면 `02_spec_and_alpha_key.md`의 알파키 신청 창구 안내 참고) |
| **언제** | `04_predeploy_verification.md` (배포 전 검증 파일) 보고서가 blocking 0 + "운영 가능"으로 나온 **뒤에만** |

> 참고: 프로덕션 키 신청에 **redirect_uri 사전 등록은 필요 없습니다**(알파 때와 동일하게 키만 필요). 콜백 주소는 당신 `.env`의 `REDIRECT_URI`로 관리합니다.

---

## 3. The 5-Item Application Template (paste-ready)

`[바이브코더 안내]`
아래 블록 전체를 복사해서 `{ }` 부분만 당신 서비스에 맞게 채우세요. **다섯 항목 모두 필수**입니다 — 하나라도 비우면 안 됩니다. 언어는 **한국어**로 보냅니다(받는 부서의 업무 언어).

```markdown
# 시온로그인 프로덕션 키 신청 — {시스템명} ({지파})

## 1. 기능
{시스템이 하는 일 요약.
 회원 데이터를 다루는 화면/API 목록을 나열.
 조회 항목은 이름·소속·직책·고유번호 4개로 제한됨을 명시
 (수집 필드 = NAME, NEW_NO, ORGANIZATION_PATH, ORGANIZATION_WITH_DUTY 정확히 이 4개,
  그 밖의 항목은 요청하지 않으며 추가가 필요하면 총회 승인을 별도로 받음)}

## 2. 사용부서
{운영 주체 부서, 실제 사용 부서/직책 범위, 예상 사용자 규모}

## 3. 개인정보처리시 우려할 점
{정직하게 기술한다. 예) 명단 화면의 상시 노출 범위, 다운로드/내보내기 기능 유무.
 각 우려마다 완화 조치를 짝지어 기술:
  - 권한 코드: 회원데이터 화면/API·내보내기마다 전용 권한 코드로 접근 통제
  - 감사 로그: 대량 조회·권한 부여/회수·내보내기·SUPER_ADMIN 행위를 감사 기록
  - 스코프 필터: 소속(지파/교회) 범위를 서버측에서 강제(organizationPaths 기준)}

## 4. 보안점검결과 (요약)
- 점검일 / 점검자: {date} / {who}
- 체크리스트: 공통 웹 보안 점검(VC1~VC16) + 시온로그인 회원데이터 리뷰게이트
  (A 노출 · B 관리 · C 다운로드 · D 보안리스크 · E 접근경계) 전 항목
- 자동 점검(tools/security_scan.py): report_id {report_id} · FAIL 0건 · NEEDINPUT 0건 ·
  코드 지문(SHA-256) {fingerprint} · 파일목록 지문(SHA-256) {manifest_hash} · git commit {commit}
- 결과: blocking 0건 (전건 조치 완료), advisory {n}건 (조치 계획 첨부)
- 상세 리포트 위치: {repo 경로 / 문서 링크}
- 첨부: 04 보안점검 결과 보고서 전문(자동 점검 결과·판정표 포함) · security_scan_report.md / .json(스캔 파일 목록 포함)

## 5. 프로덕션 운영 가능 여부
{가능 / 불가} — {근거 한두 문장. "가능"일 때만 본 신청을 발송한다}

## (부기) 심사 트랙
{일반 트랙 / 경량 트랙 신청 — 경량이면 P-2 요건 충족 내역 명시:
 ① 회원데이터는 로그인·본인 표시 용도뿐(타 회원 조회·목록 없음) ② 내보내기/다운로드 없음
 ③ 대량 개인정보 처리 없음 ④ 사용부서 1개·예상 사용자 100명 이하 ⑤ 04 게이트 전체 통과.
 트랙 확정은 총회 판단에 따름}

## (부기) 총회 검증 안내
본 보고는 개발자가 스캐너를 **직접 실행**해 **결과(이 리포트)만 제출**하는 자기완결 산출물입니다.
레포 전체를 올릴 필요 없이 이 리포트로 검사하실 수 있습니다 — FAIL·NEEDINPUT이 0이고, 코드 지문·파일목록 지문이
본문과 일치하는지 확인하시면 됩니다. (선택적 표본 감사: 특정 시스템에 한해 레포 읽기 권한을 요청하시면,
같은 커밋에서 재실행해 두 지문 일치로 위변조 없음을 확인하실 수 있습니다.)
```

### Field-by-field writing guide
`[AI directive]` Apply the criteria below when filling each `{ }`. No vague wording ("적당히", "대략") — use values confirmed from the actual code and report.

| Item | What to fill in | Basis / linkage |
|---|---|---|
| ① 기능 (features) | List the **actual screens/APIs** that handle member data, and state that lookups are capped at the **4-field ceiling: 이름·소속·직책·고유번호** | Zion hard rule 3 (exactly 4 fields), conflict-resolution table #4 (the 4-field ceiling is the concrete form of G17 minimal collection) |
| ② 사용부서 (using departments) | Operating department + the actual range of using departments/직책 + expected user scale | Reuse the 사용부서/user-scale sections of the `02_spec_and_alpha_key.md` spec |
| ③ 개인정보 우려점 + 완화 (privacy concerns + mitigations) | Pair each concern (standing exposure surface of list screens, presence of download features) **1:1 with a mitigation**: permission codes / audit logs / scope filter | Review gate B4·B5·C1·C2·C3·D5·D7 (permissions, audit, server-side scope) |
| ④ 보안점검 요약 (security-check summary) | Inspection date/inspector, blocking **0**, advisory count + remediation plan, **report location**, **automated-scan report_id · code fingerprint · file-manifest fingerprint (SHA-256) · FAIL 0 · NEEDINPUT 0**, with the full report and `security_scan_report.*` attached | Reproduce and attach the `04_predeploy_verification.md` report (the header's '리포트 저장 위치' + the two fingerprints from 「0. 자동 점검 결과」) |
| ⑤ 운영 가능 여부 (production readiness) | **가능/불가** + one or two sentences of evidence | Gate G-05-2. Send only when '가능' |
| (부기) 심사 트랙 (review track) | Full or lightweight track; a lightweight claim lists how each P-2 condition is met, re-checked at 04 completion | `01b_common_security_conflicts.md` §A2 policy P-2; HQ makes the final call |

---

## 4. If ⑤ is not '가능', sending is forbidden

`[AI directive]`
If **item 5 cannot honestly say '가능', this application is not sent.** Instead, go back to `04_predeploy_verification.md`, fix the causal items, re-verify to obtain a fresh report, and only then return to this file. Rewriting a '불가' state as '가능' is forbidden.

`[Check]` Final pre-send confirmation — send only when **all** answers are yes.
- [ ] The `04_predeploy_verification.md` report shows blocking = **0**
- [ ] **Final automated-scanner report: FAIL = 0 · NEEDINPUT = 0** (every NEEDINPUT re-run after obtaining the values); ④ lists the report_id, code fingerprint, and file-manifest fingerprint, with the full report and `security_scan_report.*` attached
- [ ] Report verdict = **"프로덕션 운영 가능"**
- [ ] All 5 application items filled in (no empty item)
- [ ] ① lists the member-data screens/APIs and states the **4-field ceiling**
- [ ] ③ pairs every concern with a **mitigation (permission codes, audit logs, scope filter)**
- [ ] ⑤ = **가능** (with the evidence sentence)
- [ ] The review-track 부기 is filled in; a lightweight-track (경량 트랙) claim was re-verified against the P-2 conditions at `04_predeploy_verification.md` completion

---

## 5. The Key Is System-Unique — no reuse (reconfirmation)

`[AI directive]`
The production `client_id` to be issued is **exclusive to this system**. Never reuse a key from another app, site, or 지파 (review gate **D11**). Reuse breaks per-system accountability, and a single leak forces simultaneous revocation and reissue across every system using that key. (총회 master testing is the only exception.)

`[⚠ Conflict resolution]`
Credential management applies **both legacy guide G1 (no hardcoding) and Zion D11 (per-system uniqueness, no reuse)** — conflict-resolution table #10. That is: the production key is never hardcoded and lives only in a gitignored `.env` (G1), and at the same time it must be this system's own unique key (D11).

`[Check]`
- [ ] Confirm the requested key is a **fresh issuance exclusive to this system** (no copying a key from elsewhere)
- [ ] After issuance the key goes into `.env` only and is **never committed to code or the repository** (G1, D9)

---

## 6. After Receiving the Key

`[바이브코더 안내]`
총회에서 프로덕션 `client_id`를 받으면, 그 키를 코드에 넣고 알파 접두어를 떼는 **실제 배포 작업**으로 넘어갑니다. 그 절차(프로덕션 전환·호스팅 유형별 배포·배포 후 실측·운영/키 회수)는 다음 파일에 있습니다.

`[AI directive]`
Receiving the production key is not the end here — it is the **input** to the deployment stage. Reflecting the key in `.env`, removing the `alpha-` prefix from endpoints, and re-confirming the absence of `JWT_SECRET` all happen in `06_deploy_and_operations.md`. This file does not plant the key into code (request and receipt only).

---

`[Next step]`
Production `client_id` received → `06_deploy_and_operations.md`
(Blocking findings remaining, or a '불가' verdict → return to `04_predeploy_verification.md`, fix, and re-verify)
