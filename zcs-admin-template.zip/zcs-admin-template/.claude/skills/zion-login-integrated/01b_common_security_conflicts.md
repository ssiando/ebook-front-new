# 01b · Pre-development — Common Security Rules (G1–G24) + Conflict Resolution

> **Preamble — priority declaration**
> The **Zion canon in `01_zion_login_canon.md` takes absolute precedence.** The common security rules below (G1–G24, R0) apply **on top of** that canon.
> When a common security rule conflicts with the Zion canon, **always follow the Zion Login rule** (see the conflict-resolution table in this file). Never revert to the generic security-guide position.

---

## When to read this file
Immediately **before development starts** — right after `01_zion_login_canon.md` has been injected/accepted. This file fills the general web-security ground the Zion canon does not cover (secrets, hosting, DB access, input/output, personal data, operations) and pins the verdicts where the two overlap.

## What this file contains
- **R0 integration** — top-priority rules that stay in force on top of the Zion flow: R0-6 (server-side enforcement), R0-7 (weakest link), R0-8 (retroactive application), R0-1/R0-2 (ask-a-human exceptions → merged into the Zion flow's human-intervention points).
- **Common security rules G1–G24** — every item of the legacy pre-development common ruleset, intent preserved, aligned to the Zion context. One line per rule + one line of Zion context where relevant.
- **Conflict-resolution table (11 items)** — each entry reads "security-guide position / Zion position / resolution (Zion wins)". Conflicts are always resolved in Zion's favor.
- **One-line code self-check** — the check the AI performs every time it emits code.

---

## A. R0 integration — top-priority rules on top of the Zion flow

`[AI directive]` The R0 rules below rank above G1–G24. When G rules conflict with each other or with the situation, R0 decides. But when R0 conflicts with the Zion canon, Zion wins.

| ID | Rule | Application in the Zion flow |
|---|---|---|
| **R0-6** | **"Hiding things on the client/screen is not security."** Access control, permission checks, payment decisions, and data filtering MUST be enforced on the **server** (RLS/security rules, or server functions/RPC). A browser-JS `if (isAdmin)`, screen-side filters, a password prompt screen, or a hidden div are UI conveniences, not security boundaries. Never build "download all the data, then hide it on screen." | Matches Zion **E3 (access boundary)**. Identity and permission decisions are enforced by the backend using the Zion session's **고유번호 (newNo)**. A client-side password gate does not count as authentication. |
| **R0-7** | **"Weakest link" principle.** Among the screens/features/endpoints sharing one DB/project, if a single one is weak, the whole thing is breached. Once one place is secured, apply the same bar to **every path** that touches the same data. | Apply the same **permission check + data-scope (organizationPaths) filter** to every API/page that touches member data. Leave not a single path that bypasses the Zion session gate. |
| **R0-8** | **[Retroactive application]** If this directive is injected mid-development (code already exists), apply the rules **retroactively to the code written so far** — review and fix it before proceeding, not only to code yet to be written. | Same as the retroactive application declared in `00_START_HERE.md`. Retroactively apply the Zion canon (core flow, session model, permission model) and G1–G24 to the existing code, fix it, then continue. |
| **R0-3** | When unsure, do not improvise — choose the **safer** option. | When a Zion rule's interpretation is ambiguous, ground it in `01_zion_login_canon.md` and `references/` (permission-model, api-catalog); if still ambiguous, choose the fail-closed side. |
| **R0-4** | Do not add dangerous features (external command execution, exposing public endpoints, bulk export of personal data, etc.) until the user has **explicitly requested them and confirmed understanding**. | Bulk member-data export (Zion C1/C2) is not built until user confirmation + a dedicated permission + audit are all in place. |
| **R0-5** | Values the user must fill in (tokens, allowlists, etc.) are shown as **blanks/placeholders**. Settings that require judgment are decided by the AI. | Zion keys (`OAUTH2_CLIENT_ID`, etc.) and endpoint URLs go into `.env` as placeholders only; the vibe coder fills in the real keys. `.env.example` contains placeholders only. |

### R0-1 / R0-2 → merged into the Zion flow's human-intervention points

`[AI directive]`
- **R0-1.** For security choices, do not ask the user — the AI **implements the safest default directly**. Record what was decided and why in a single comment line above the code, nothing more.
- **R0-2.** The only exceptions where a human is **asked, in plain language**, are pinned below. Since the Zion flow has a fixed order, R0-2's exceptions are merged with the Zion flow's **human-intervention points**. Security choices outside this table are not asked about, per R0-1.

`[⚠ Conflict resolution]` The Zion flow is fixed (conflict-resolution table #9). Outside the points below, the AI proceeds silently with safe defaults.

| Human-intervention point | What is asked of / received from the human | In which file | Governing rules |
|---|---|---|---|
| Hosting/deployment type | Ask the deployment-target type (1–4) once, then configure per type | `06_deploy_and_operations.md` | R0-2 exception · G5 · Zion hard rule 8/E5 |
| Intent behind bulk personal-data processing | Whether bulk upload/export/external transfer is **actually needed** | (when that feature is built) | R0-2 exception · G18 · Zion C1/C2 |
| Alpha key request | Request the **development (alpha) key directly from HQ (총회 정보통신부 전산개발과)** | `02_spec_and_alpha_key.md` | Zion credentials (keys not bundled — HQ-issued) |
| HQ approval (field ceiling exceeded) | If member-data collection must exceed the **4-field ceiling**, obtain HQ (총회) approval | `02_spec_and_alpha_key.md` | Zion hard rule 3 |
| Production-operation verdict | The file-04 report's **"production readiness" verdict** → production key request | `04_predeploy_verification.md` → `05_production_key_request.md` | VC1–VC16 · A–E · Zion hard rules |
| (Only when a bot component exists) Bot entry-authentication strength | B2 authentication strength | `references/bot-addon-optional.md` | R0-2 exception · conflict-resolution table #11 |

---

## A2. Organizational Policy Registry

`[⚠ Organizational policy]` This section is the **single place that collects policy decisions made by the organization (총회 / in-house)**. When an adjustment relative to the Zion canon is needed, record it **here only**; other files reference this registry (never scatter policies across files — this protects the "Zion wins on conflict" principle from erosion). Read each policy as "Decision / Relationship to the Zion canon / Rationale / Where it applies".

### Policy P-1 — login trigger = internal information

- **Decision:** **If the system touches internal information at all, Zion Login is mandatory.** Internal information = everything not meant for the public (member data / personal data, external contact lists, org/operations information, strategy, non-public notices, etc.). **Whether it is personal data (고유번호 etc.) or non-identifying internal sensitive data (e.g. per-지파 donation totals — aggregates) — if it is internal, login is mandatory.** Only fully public content (public notices, marketing) needs no login. **When in doubt, treat it as internal** and put it behind login (under-classification is the more dangerous error).
- **Relationship to the Zion canon:** **In agreement** (hard rule 7 / E1 as-is — the trigger is the broader "internal information", not "personal data"). This is canon compliance, not an adjustment. It also matches the HQ production-key review (`references/privacy-security-review.md` §E), so there is **no §E rejection risk**.
- **Rationale:** Even data that identifies no individual, if it is organizational confidential material (sensitive aggregates, etc.), must sit behind login. A "personal data only" trigger misses such internal sensitive data — too narrow.
- **Where it applies:** Client-side password gates/overlays/`localStorage` flags are not recognized as authentication (R0-6, E3 — server-side enforcement). The classification table is item 7 of `02_spec_and_alpha_key.md`; pre-deployment verification is E1–E4 of `04_predeploy_verification.md`; conflict resolution is #3 in the table below.
- **[⚠ Public collection vs gated administration — common misunderstanding]** When personal data is collected **from general public visitors** (newsletter, contact, application forms, etc.), "Zion Login mandatory" does **not** mean *require the submitter to log in as a member* (that would defeat the form's purpose — over-gating, `04_predeploy_verification.md` E2). What must be gated is **not "who submits" but "who views, manages, and exports the collected data"**:
  - Put **the view/manage/export paths for the collected data** behind Zion Login + 고유번호 RBAC + audit, enforced **server-side** (E1, E3, E4, B4, C1, C2).
  - Leave **the public submission endpoint** login-free, but harden it with minimal collection (G17), input validation (G13), rate limiting (G21), and response/log masking (G19).
  - **Non-member PII is unrelated to the member-data model:** hard rule 3's "4-field ceiling / EMAIL etc. forbidden" governs **member data fetched from Zion**. PII newly collected independently of Zion (public newsletter emails, etc.) is not member data, so that ceiling/prohibition **does not apply to it (and is not a reason to refuse the request)**; instead, G17–G19 (general PII) plus gated administration, audit, and retention/destruction apply.

### Policy P-2 — lightweight review track (경량 트랙) for small, low-risk systems

*Status: added 2026-07-05 as a recommended policy; to be confirmed by HQ (총회 정보통신부 전산개발과) at its next review. Until then it changes only how the request is marked — HQ may still review at full depth.*

- **Decision:** A system that meets **ALL** of the eligibility conditions below may request its production key on the **lightweight review track**: HQ reviews only the 5-item request plus the automated scanner report (report_id, code fingerprint, file-manifest fingerprint, FAIL 0 · NEEDINPUT 0) and **waives the full verdict-table review**. Eligibility (all mandatory):
  1. **Member data used at most for login + showing the signed-in user their own identity** (no other members' data is listed, searched, stored, or displayed beyond the local user snapshot) — or no member data at all (the internal information is non-personal).
  2. **No export/download of any internal data** (no `*_EXPORT`/`*_DOWNLOAD` permission codes exist).
  3. **No bulk PII processing** (none of the G18 triggers: bulk upload/import, scraping, full-list export/transfer, third-party/LLM transmission).
  4. **Small scale:** one operating department (사용부서 1개) and expected total users ≤ 100.
  5. **The standard gate is still fully passed:** `04_predeploy_verification.md` run in full — blocking 0 and scanner FAIL·NEEDINPUT 0.
- **What does NOT change:** the developer-side flow is identical — all 6 stages, the full 52-item gate, the two mandatory pages, private repo, audit rules. The AI and the scanner do that work anyway; **only the depth of HQ's human review is reduced.** If any eligibility condition later breaks (a member list screen, an export, growth past the scale line), the next change goes through the **full track**.
- **Relationship to the Zion canon:** compatible — no hard rule is relaxed. The canon fixes *what must be true of the system*; P-2 only tiers *how deeply HQ re-verifies it*, leaning on the scanner's tamper-evident fingerprints.
- **Rationale:** with 12 tribes submitting, HQ review throughput is the realistic bottleneck. Small self-service tools with no member-data browsing and no exfiltration surface carry a fraction of the risk of a member-directory system; spending full review depth on them delays the reviews that matter.
- **Where it applies:** the AI determines eligibility at spec time (`02_spec_and_alpha_key.md`, spec item 8) and re-checks it at `04_predeploy_verification.md` completion; the production-key request marks the track (`05_production_key_request.md` template, 부기). HQ makes the final call — a lightweight-track request is a claim, not an entitlement.

### Policy P-3 — small public collection forms (소형 폼): write-only pattern, no Zion Login required

*Status: added 2026-07-05 as a recommended policy; to be confirmed by HQ at its next review. The pattern is strictly narrower than P-1's gated-administration clarifier (it removes the read surface entirely), so applying it early does not weaken P-1.*

- **Decision:** A small public form collecting **non-member PII** (문의·신청·뉴스레터 등) may be built **without Zion Login** if it follows the **write-only pattern** — the system exposes **no read path at all** for the collected data. ALL conditions mandatory:
  1. **Non-member PII only** — data comes from public visitors; no Zion member data (`/me` fields) is stored with it.
  2. **Minimal fields for the purpose** (name / one contact channel / free text level). **Never** PIPA-sensitive categories (건강, 종교적 신념, 사상, 성적지향 등) and never national-ID-grade identifiers.
  3. **Write-only:** the system has **no view/search/manage/statistics/export UI or API** for the collected data. There is nothing internal to expose, so the P-1 login trigger is not tripped.
  4. **Delivery + purge:** each submission is auto-forwarded to **one fixed, documented internal recipient** over an org-approved channel (사내 메일 등 — no unapproved third-party services), and/or stored server-side with **auto-purge ≤ 30 days** (a job or startup task that actually runs — B2). Longer retention requires a documented reason and forces full-track consideration.
  5. **PIPA notice on the form:** purpose · items · retention period · a contact for deletion requests (수집·이용 고지).
  6. **Endpoint hardening:** input validation (G13), rate limiting (G21), submitted PII never in app logs or error bodies (G19), HTTPS; the data store is gitignored and never committed (G1); **the repo is still private** (hard rule 8 — the system transiently holds internal information).
  7. **Volume guard:** if retained rows would exceed ~1,000, or any browsing/statistics/search need appears, **stop — switch to the full track** (gated administration per P-1: Zion Login + 고유번호 RBAC + audit on the management path).
- **Re-evaluation stays armed:** `00_START_HERE.md` §1.1 applies unchanged — the moment ANY read path is added, the P-1 trigger fires and the system promotes into the full Zion Login flow.
- **Relationship to the Zion canon:** compatible. P-1's clarifier already exempts the *submitter* from login and gates the *management path*; P-3 covers the degenerate case where the best management path is **no path**. Fewer surfaces than a gated admin screen — strictly less exposure.
- **Rationale:** forcing a full Zion Login backend + RBAC + audit stack onto a 5-field contact form makes the secure route so expensive that vibe coders route around it; a write-only pattern keeps the risk profile lower than the "proper" alternative while staying buildable in an afternoon.
- **Where it applies:** triage exception in `00_START_HERE.md` §1.1; classification note in `02_spec_and_alpha_key.md` item 7; verification via E1/E4 (a write-only system passes by *having no read surface*, verified — not assumed) plus G13/G19/G21/B2 in `04_predeploy_verification.md`. No key request is involved (no Zion Login), but running the scanner locally before deploy is still expected.

> If the organization later adjusts other canon rules, **add them to this registry only, as P-4, P-5, …** — the affected files must reference this registry instead of restating the rule.

---

## B. Common security rules G1–G24 (aligned to the Zion context)

`[AI directive]` The G rules below apply **in addition to** the Zion canon. Each rule preserves its original intent; where it touches Zion, the "Zion context" column aligns it in one line. Overlaps that need a detailed verdict link to this file's conflict-resolution table.

### B-1. Secrets & credentials (G1–G4)

| ID | Rule | Zion context |
|---|---|---|
| **G1** | Never write tokens, passwords, API keys, or internal IPs directly in code → load from `.env`/environment variables. Always ship `.env.example` (placeholders only). `.gitignore` must include `.env`, DB files (`*.db`, `*.sqlite*`), sessions, logs, roster/personal-data files, and the progress marker (`.pstate`, `00_START_HERE.md` §1.7). | Zion keys (`OAUTH2_CLIENT_ID`; the AUTH/TOKEN/USERINFO/VALIDATE/AUTHORITIES URLs; `REDIRECT_URI`, etc.) are likewise loaded from `.env` only. Having no `JWT_SECRET` is **normal**. Zion D11 (per-system unique key, no reuse) applies additionally (conflict-resolution #10). |
| **G2** | Never put secrets in URL query strings (`?key=`, `?secret=`, `?payload=`) → deliver via **HTTP headers only**. (Query strings persist in plaintext in access logs, Referer, history, and cron records.) | Never let the Zion `access_token` or `newNo` (고유번호) appear in URLs, logs, or raw error output (directly tied to Zion D audit / the token-logging ban). |
| **G3** | Keys that bypass RLS (`service_role`, master, admin, etc.) must **never** be placed in the browser, client, or static files. Server-only. Even if the backend runs as `service_role`, keep table **RLS on, default-deny** (second line of defense). | If Supabase is used as the local DB, go **through the backend (behind the Zion session gate)** instead of connecting the browser directly. The backend may run as `service_role`, but RLS stays on (conflict-resolution #2). |
| **G4** | If `.env` was ever committed/pushed, or the repo was ever public, treat it as **already leaked** → guide the user to re-issue tokens. (Making the repo private or gitignoring does not recall values from history.) | If a Zion key has ever been exposed, request **re-issuance/revocation from HQ (총회)** (see the key-revocation procedure in `06_deploy_and_operations.md`). |

### B-2. Hosting & repository — preventing source exposure (G5–G6)

| ID | Rule | Zion context |
|---|---|---|
| **G5** | Default to **hosting that does not expose the source**. At the point deployment becomes necessary, ask **once** for the deployment-target type (① internal server ② free static/serverless ③ GitHub ④ undecided) (R0-2 exception) and configure per type. Judge by **type** (static / serverless / container·self-hosted / managed backend), not by vendor name. | **No conflict** with Zion hard rule 8/E5 (source non-public). The type question and configuration are performed in `06_deploy_and_operations.md` (conflict-resolution #8). |
| **G6** | Ensure the source is not **publicly readable without authentication** (regardless of deployment target). On a git host, repo private by default (user's one step: Settings → Danger Zone → Change visibility → Private). After configuring, **open the source URL in a logged-out (incognito) window and confirm a 404**. | Adopt Zion E5 plus the guide's **live check (VC3 — stronger)**. Post-deployment live checks are performed in `04_predeploy_verification.md` and `06_deploy_and_operations.md`. |

### B-3. DB access control (G7–G8)

| ID | Rule | Zion context |
|---|---|---|
| **G7** | If the client accesses the DB **directly**, the entire access-control story rests on DB rules. **Supabase**: RLS enabled on every table + owner/role policies; sensitive reads/writes only via server-validated RPC; no `anon` full-access policy. **Firebase**: lock down with security rules (no `allow …: if true`; at minimum `auth != null` + owner/role). **GAS / self-hosted backends**: no unauthenticated `doGet`/`doPost`; server-side identity verification (ID-token signature, aud, exp). | **→ Zion wins (conflict-resolution #2).** Identity is the **Zion session's 고유번호**, not `auth.uid()`. If Supabase is the local DB, go **through the backend** instead of connecting the browser directly. **The primary control for scope enforcement is the backend application query filter** (keyed on `organizationPaths`). RLS (default-deny) is the **second line of defense** blocking **non-`service_role` paths** (direct `anon`/`authenticated` connections, etc.) — `service_role` bypasses RLS (BYPASSRLS), so RLS policies (including 고유번호-context policies) are **not evaluated** for backend queries running as `service_role`. To actually apply a "고유번호-context" RLS policy, run that query under a non-`service_role` role. Do not copy G7's `auth.uid()` examples as-is. |
| **G8** | Having the `anon`/public key in code is **normal in itself**. The premise is "RLS/rules are properly locked". Whenever writing code that uses a public key, **create the matching RLS/rules as a set** (either one alone is incomplete). | In Zion, the **primary scope control is the backend query filter**; keep RLS (default-deny) as the **second line of defense** blocking non-`service_role` paths (G3, conflict-resolution #2). |

### B-4. Minimal response — preventing over-fetching (G24)

| ID | Rule | Zion context |
|---|---|---|
| **G24** | **Minimal-response principle.** APIs/queries fetch only the data they need and return only what is needed (separate from RLS). No `select *` / all-columns; exclude sensitive columns not used on screen; **row filtering, sorting, pagination, search on the server**; split response DTOs per screen/role; aggregate via server-side aggregate queries. | Directly tied to Zion **R0-6** and the Zion **A (exposure) gate**. Member data stays within the **4-field ceiling** (`newNo`/`name`/`organizationPaths`/`organizationWithDuties`), sending only the fields each screen/role needs. "Download everything and hide it in the frontend" is forbidden (matches the minimal response of conflict-resolution #2). |

### B-5. Server-side authorization & privilege-escalation prevention (G9–G12)

| ID | Rule | Zion context |
|---|---|---|
| **G9** | Permission decisions are made **on the server** (R0-6). Never trust client-sent permission fields (`role`, `isMaster`, `isAdmin`, etc.). Permission values from session/localStorage are re-verified by the server on every request. Never leave dev backdoors (localhost auto-admin login, etc.) in production code. | **→ Zion wins (conflict-resolution #5).** Permissions are decided by **고유번호 RBAC** (Zion hard rules 4/5). 직책 is display-only; duty-based automatic permissions are forbidden. G9's server-side/re-verification principles apply unchanged on top of the Zion model. |
| **G10** | **Block mass assignment / self-escalation.** When a user edits their own record, lock `role`, permissions, 소속, and `status` server-side (trigger/policy/RPC) so they cannot change them. New applications always start as 'pending approval'. | In the 고유번호→permission-code local table, only **`SUPER_ADMIN` (= `DO_EVERYTHING`) or a delegated `PERMISSION_ADMIN`** may grant/revoke permissions. Grants and revocations require audit (Zion B5). |
| **G11** | **Fail-closed.** No fail-open "check only when the value is set". If a secret is unset, reject unconditionally (401). Compare in constant time (`timingSafeEqual`). | If Zion **session revalidation** (`validate`, default 300s) fails, reject the session fail-closed (consistent with the Zion hard rules / session model). |
| **G12** | Never store passwords in plaintext or compare them on the client. Compare server-side (RPC/function) with a hash (bcrypt/PBKDF2), returning only true/false. No client-side plaintext-comparison fallback on network failure. | **→ Zion wins (conflict-resolution #1).** **Never build new local password authentication.** Identity and sessions are the Zion `access_token` (Zion hard rule 2; `JWT_SECRET` forbidden). G12 applies only to **separate secrets outside Zion** (webhook secrets, etc.). |

### B-6. Input/output safety (G13–G16)

| ID | Rule | Zion context |
|---|---|---|
| **G13** | Validate/filter all external input (messages, filenames, command arguments, payloads, uploads). Parameterized queries against SQL injection; no shell/`eval`/`exec`/`os.system` against command injection. | Validate the inputs of member-data APIs the same way (R0-7: same bar on every path). |
| **G14** | **XSS.** Never put user-derived or externally derived values (names, free text, model output, sheet values) directly into `innerHTML` → `textContent`/`escapeHtml()`. No auto-escaping bypasses (`dangerouslySetInnerHTML`, etc.). CSP header where possible. | **A spot where the guide fills a gap the Zion canon leaves open.** Especially when rendering the member `name` and similar. Must be judged as **VC8** in `04_predeploy_verification.md`. |
| **G15** | **SSRF.** If the server fetches user-specified URLs: scheme/host allowlist; block private, link-local, and loopback ranges (`169.254.169.254`, `localhost`, `10.`, `192.168.`, `127.`); no redirects; timeout and response-size caps. Never reflect upstream status or raw error bodies. | A spot where the guide fills a Zion gap. Judged as **VC9** in `04_predeploy_verification.md`. |
| **G16** | Validate file uploads and CSV/Excel processing server-side (format, size, row count). Block **formula injection** in CSV export (escape cells starting with `=`, `+`, `-`, `@` by prefixing `'`). | Directly tied to member-roster export (Zion C1/C2). Judged as **VC10** in `04_predeploy_verification.md`. |

### B-7. Personal data (PII) (G17–G19)

| ID | Rule | Zion context |
|---|---|---|
| **G17** | **Minimal collection.** Collect only what is needed. For PIPA sensitive data (religion/beliefs, health, minors, sexual orientation, ideology, etc.), reconsider whether to collect at all; if unavoidable, run a separate explicit-consent procedure. | **→ Zion wins (conflict-resolution #4).** Member data has an **exact 4-field ceiling** (Zion hard rule 3); exceeding it requires HQ (총회) approval. Treat G17 as the **general form** of that ceiling. |
| **G18** | **[R0-2 exception — always ask]** For features that process personal data **in bulk at once** (bulk upload/import, scraping, full-roster export/transfer, transfer to external parties (third parties, LLMs, Google, etc.)), **ask the user's actual intent before writing code**. (Small-scale/routine cases — e.g. one person's own data — are not asked about.) | **→ Both (conflict-resolution #7, complementary).** Bulk export requires **user confirmation (G18) + a dedicated permission (Zion C1) + audit (Zion C2)** — all of them. |
| **G19** | Never expose personal data in HTTP responses, debug output, or logs. Mask emails, phone numbers, names, and secret URLs. Error responses carry only a simple notice — no stack traces, internal paths, or raw upstream bodies. | Consistent with Zion's **token/`newNo` logging ban**. Do not expose internal values of the Zion response envelope (`traceId`, etc.) verbatim in raw error output. |

### B-8. Operations & misc (G20–G23)

| ID | Rule | Zion context |
|---|---|---|
| **G20** | Use only maintained, stable library versions. Avoid deprecated/vulnerable stacks (e.g. the `request` family). Prefer lightweight dependencies; avoid inefficient queries (N+1). | Considering resource-constrained environments (self-hosted servers, NAS), keep the Zion integration code lightweight too. |
| **G21** | Apply **rate limiting**: excessive requests from the same user, brute force, and abuse of paid APIs (LLM/TTS, etc.). Never expose paid endpoints without authentication. | A spot where the guide fills a Zion gap. Judged as **VC13** in `04_predeploy_verification.md`. Also applies to the login/token-exchange endpoints. |
| **G22** | No org names, real names, internal jargon, religious terms, internal IPs, deployment hosts, or project identifiers in code comments, variable names, or messages (neutral naming). Externalize unavoidable values into `.env`/config. | Consistent with Zion's **user-facing naming rules**: never expose `'ZAuth'`; no codes/enums/internal IDs in the UI; `newNo` is always labeled **'고유번호'** for users. |
| **G23** | In the pre-deployment verification step, instruct the user **not to upload the real `.env` (actual tokens)** (`.env.example` only). Tools that run directly on the directory (Claude Code, etc.) must **not open and read `.env` contents** — check only that it exists and is in `.gitignore`. | Same for the Zion alpha/production keys. Real keys live only in the local `.env` (gitignored); the repository stays private (`06_deploy_and_operations.md`). |

---

## C. Conflict-resolution table (Zion Login wins) — all 11 items

`[⚠ Conflict resolution]` **Principle: when a common security rule and the Zion canon conflict, Zion Login always wins.** The 11 items below pin the verdicts at the overlap points. Read each as "security-guide position / Zion position / resolution (Zion wins)". (This table applies identically in `04_predeploy_verification.md`.)

### 1. Authentication & self-issued tokens

| Axis | Content |
|---|---|
| Security-guide position | G12 (password hashing) / generic local login |
| Zion position | Hard rule 2: self-issued JWT / `JWT_SECRET` forbidden; session token = Zion `access_token` |
| **Resolution** | **→ Zion.** **Never build new local password authentication.** Identity/session = the Zion `access_token`. Even if a local-looking login UI exists, the real session is Zion. **G12 applies only to separate secrets outside Zion (webhook secrets, etc.).** |

### 2. DB access control & identity source

| Axis | Content |
|---|---|
| Security-guide position | G7: Supabase `auth.uid()` / Firebase auth, browser→DB direct connection |
| Zion position | The backend fixes identity from the session; permissions = local 고유번호; scope = `organizationPaths` |
| **Resolution** | **→ Zion.** Identity is the **Zion session's 고유번호**, not `auth.uid()`. If Supabase is the local DB, go **through the backend (behind the session gate)** instead of connecting the browser directly. **The primary control for scope enforcement is the backend query filter** (`organizationPaths`); RLS (default-deny) is the **second line of defense** blocking non-`service_role` paths (direct `anon`/`authenticated` connections, etc.) — `service_role` bypasses RLS (BYPASSRLS), so RLS is **not evaluated** for `service_role` backend queries (therefore, in a `service_role` backend, scope MUST be enforced by query filters). To actually apply a "고유번호-context" RLS policy, run that query under a non-`service_role` role. Do not copy G7's `auth.uid` examples as-is. **G24 (minimal response) and R0-6 (server-side enforcement) agree with Zion and remain fully in force.** |

### 3. Login trigger

| Axis | Content |
|---|---|
| Security-guide position | Personal-data/DB-based trigger |
| Zion position | Hard rule 7/E1: **internal-information trigger** (broader than personal data) |
| **Resolution** | **→ Zion.** Anything handling internal information (including personal data, and including non-identifying sensitive aggregates) makes Zion Login **mandatory**; only fully public content is exempt. Client-side gates are not recognized (R0-6, E3). The organization's confirmed policy is §A2 Policy P-1 (internal-information trigger — matches the canon and HQ §E; no rejection risk). |

### 4. Member-data minimal collection

| Axis | Content |
|---|---|
| Security-guide position | G17: minimal-collection principle |
| Zion position | Hard rule 3: **exactly 4 fields**; exceeding requires HQ (총회) approval |
| **Resolution** | **→ Zion.** The **4-field ceiling** applies. Treat G17 as the general form of that ceiling. |

### 5. Permission model

| Axis | Content |
|---|---|
| Security-guide position | G9/G10: server-side authorization & mass assignment (generic) |
| Zion position | Hard rules 4/5: **고유번호 RBAC**; 직책 display-only; `SUPER_ADMIN` = `DO_EVERYTHING` |
| **Resolution** | **→ Zion.** Permissions are keyed on **고유번호**; duty-based automatic permissions are forbidden. The G9/G10 principles (server-side, self-escalation blocking, fail-closed) apply unchanged on top of the Zion model. |

### 6. Audit log (guide gap → Zion addition)

| Axis | Content |
|---|---|
| Security-guide position | None |
| Zion position | B4/B5/C2/D7 |
| **Resolution** | **→ Adopt Zion.** Bulk reads, permission grant/revoke, exports, and `SUPER_ADMIN` actions **require audit**. |

### 7. Bulk personal-data processing

| Axis | Content |
|---|---|
| Security-guide position | G18: user confirmation |
| Zion position | C1/C2: dedicated permission + audit |
| **Resolution** | **→ Both (complementary).** Bulk export requires **user confirmation + dedicated permission + audit** — all of them. |

### 8. Source non-public / private repo

| Axis | Content |
|---|---|
| Security-guide position | G5/G6/VC3 |
| Zion position | Hard rule 8/E5 |
| **Resolution** | **No conflict.** Zion principle + the guide's **live check (VC3, stronger)** adopted. |

### 9. Startup behavior & user questions

| Axis | Content |
|---|---|
| Security-guide position | R0-1/R0-2: don't ask about security, use safe defaults, 3 exceptions |
| Zion position | Fixed flow; human intervention = alpha key, HQ approval, production verdict |
| **Resolution** | **→ Merge the Zion flow's intervention points into the R0-2 exceptions.** (See the human-intervention table in §A of this file.) Bot authentication strength (B2) only when a bot is included. |

### 10. Credentials

| Axis | Content |
|---|---|
| Security-guide position | G1: no hardcoding |
| Zion position | D11: per-system unique key, no reuse |
| **Resolution** | **→ Both.** Keep G1 + add D11. |

### 11. Bot addon (B1–B5)

| Axis | Content |
|---|---|
| Security-guide position | Bot security gates B1–B5 |
| Zion position | Zion Login is web OAuth login (not a bot) |
| **Resolution** | **→ Only when a separate bot component exists**, additionally apply `references/bot-addon-optional.md`. Not applied to the base web flow (preserved only to prevent omission). |

---

## D. Code self-check — every time code is emitted (AI-only)

`[AI directive]` Immediately **before presenting code**, verify on your own that the Zion canon (core flow, session model, permission model) and G1–G24 below are reflected. Fix any omission or weakness **before** presenting. Perform this every single time code is emitted. Do not print the checklist itself — expose only the one-line completion notice.

`[Check]` Self-check items
- [ ] **Zion canon** — core flow (`/oauth/` path, `state`, no `client_secret`, 4-field userinfo, permissions from `DO_EVERYTHING` only), session model (hashed storage, fail-closed revalidation), permissions = 고유번호 RBAC
- [ ] **G1–G4** secrets — no hardcoding, no secrets in URLs, no `service_role` on the client, past-leak handling, no `JWT_SECRET`
- [ ] **G5–G6** hosting — type judgment, source non-public, private repo, no hardcoded values
- [ ] **G7–G8, G24** DB access control & minimal response — RLS/rules as a set, identity = Zion-session 고유번호, no `select *`, server-side filtering/pagination, per-role DTOs, sensitive columns excluded
- [ ] **G9–G12** server-side authorization, mass assignment, fail-closed — permissions keyed on 고유번호, no new local password auth
- [ ] **G13–G16** input validation, XSS, SSRF, CSV/files
- [ ] **G17–G19** personal data — 4-field ceiling, bulk-processing confirmation, response/log masking
- [ ] **G20–G23** dependencies, rate limiting, neutral naming (no `'ZAuth'` exposure), verification hygiene

`[AI directive]` On completion, append exactly one line together with the code:
> **✅ 보안 자가 점검 완료 (시온 캐논 + 개발전-공통 G1~G24)**

If anything was remediated, append `— 일부 항목 보완함`. When ambiguous, follow R0-3 and remediate toward the safer side.

---

## [Next step]
Move on to `02_spec_and_alpha_key.md`. There, write up the spec (design plan) and request the **alpha key** from HQ (총회).
