# 02 · Pre-development — Write the Spec (기획안) + Request the Alpha Key

## When to read this file
Read **immediately before** development starts, after the canon (`01_zion_login_canon.md`) and the common security rules (`01b_common_security_conflicts.md`) have already been ingested. This is the stage where you finalize the **design spec (기획안)** before writing any code, and use that spec as the basis for requesting the **alpha (development) key** from HQ (총회).

## What this file contains
- **[AI directive]** The 8 mandatory spec items (feature summary · member-data screen/API list · the four-property query ceiling · draft permission-code catalog · using department · expected user scale · login-required verdict (internal-information criterion, §A2 P-1) · review track (§A2 P-2)).
- A paste-ready **spec template (기획안 템플릿)**.
- **[바이브코더 안내]** Alpha key request — to whom, what, how. **The AI/skill never sends it automatically** (the user contacts HQ directly).
- A paste-ready **alpha key request message template**.
- After receiving the key: keep it in a local gitignored `.env`, placeholders only in `.env.example`, and **no redirect_uri pre-registration needed**.

## Decided in the previous stage (short reminder)
- **Query exactly 4 properties**: `NAME` (이름) · `NEW_NO` (고유번호) · `ORGANIZATION_PATH` (소속) · `ORGANIZATION_WITH_DUTY` (직책). Anything beyond these 4 requires HQ approval. (01 hard rule 3)
- **Login trigger (§A2 policy P-1):** **Zion Login is mandatory whenever internal information is handled** (including personal data, and including sensitive aggregates that identify no individual); only fully public content is exempt. (Identical to 01 hard rule 7 — consistent with HQ §E.)
- **The only key is `client_id`** — no `client_secret`, no `JWT_SECRET`. HQ issues the key; it is not bundled with the skill. (01 hard rules 1·2)

---

# Part A. Finalize the Spec (기획안)

## [AI directive] The spec comes before code

`[AI directive]`
1. Before generating any code, first complete a **spec with all 8 items below filled in**. If an item is empty, ask the user and fill it before proceeding. Never leave vague wording ("appropriately", "as you see fit").
2. The spec is the **input** to the later stages. The alpha key request message in this file (Part B), the verdicts in `04_predeploy_verification.md`, and the request form in `05_production_key_request.md` are all written from this spec.
3. The alpha key request message cannot be completed until the spec is finalized (the message includes the feature, using department, and member data touched).

### The 8 mandatory spec items

| # | Item | What to write | Basis |
|---|------|------------|------|
| 1 | **Feature summary** | One or two sentences on what the system does | — |
| 2 | **Member-data screen/API list** | Every screen and API endpoint that displays, stores, logs, or exports member data, without omission | Identifies the targets of review gates A–E |
| 3 | **Query properties (4-item ceiling)** | Only `NAME`·`NEW_NO`·`ORGANIZATION_PATH`·`ORGANIZATION_WITH_DUTY`. Anything more requires HQ approval, recorded in the spec | Hard rule 3 · review B1 |
| 4 | **Draft permission-code catalog** | A `code`·`label`·`description`·`scope` table (format below) | Permission model (`references/permission-model.md`) |
| 5 | **Using department** | The operating department + the actual scope of using departments/duties | Input to the alpha and production key requests |
| 6 | **Expected user scale** | Rough concurrent/total user counts | Input to scale and audit design |
| 7 | **Login-required verdict** | Does the system handle internal information → Zion Login required verdict (§A2 P-1 · verdict table below; small write-only public forms may qualify for the P-3 exception) | Hard rule 7 · review E1 |
| 8 | **Review track** | Full track / lightweight track (경량 트랙) per the §A2 P-2 eligibility conditions — state which conditions hold | §A2 policy P-2 |

## Item 3 — Query properties (4-item ceiling)

Send the request with the **singular** `ORGANIZATION_WITH_DUTY` and read the response from the **plural** `organizationWithDuties`. This asymmetry is the real spec — do not change it (01 "Frequently mistaken values").

| Request property (singular) | Response key | User-facing label | Purpose |
|---|---|---|---|
| `NAME` | `name` | 이름 | Display name |
| `NEW_NO` | `newNo` | **고유번호** | User primary key · the key permissions are granted to (always labeled '고유번호', never the field name) |
| `ORGANIZATION_PATH` | `organizationPaths` | 소속 | Affiliation display · **data scope** (tribe/church) input |
| `ORGANIZATION_WITH_DUTY` | `organizationWithDuties` | 직책 | Duty display only (filter `type == "DUTY"`). **Never used as a permission input** |

`[⚠ Conflict resolution]` (conflict-resolution table #4)
- Pre-existing common security rule **G17** (personal-data minimal-collection principle) vs Zion **hard rule 3** (exactly 4 fields, anything more requires HQ approval).
- **Verdict → Zion wins.** The ceiling is **exactly 4** — not "a few more since they look useful". `MOBILE`/`EMAIL`/`ADDRESS`/`BIRTHDAY`/`SEX`/`PICTURE` and the like are **forbidden** in this edition. If a feature truly needs one, get HQ approval first and record it in the spec. G17 is treated as the generic form of this 4-field ceiling.

## Item 4 — Draft permission-code catalog

Permission codes are **UPPER_SNAKE** codes with a user-facing `label` + `description`. Permissions are **granted directly to 고유번호 (newNo)**, and that local table is the single source of truth (SSOT). Duty is display-only, never a permission input. `SUPER_ADMIN` is the reserved master-admin code, auto-granted at login to `DO_EVERYTHING` holders, so it needs no local grant row. Details: `references/permission-model.md`.

**Meaning of the `scope` column:** permission (what can be done) and data scope (whose data — from `organizationPaths`) are separate axes. `scope` records the **data range** the code operates on: `전체` / `소속(지파·교회)` / `본인`.

Draft catalog format (example — fill in for the actual features):

| code | label | description | scope |
|------|-------|-------------|-------|
| `SUPER_ADMIN` | (예약) 최고관리자 | 모든 권한. `DO_EVERYTHING` 보유자에게 자동 부여, 로컬 부여 불요 | 전체 |
| `PERMISSION_ADMIN` | 권한 관리자 | 고유번호별 권한 부여/회수 및 감사 이력 | 소속(지파·교회) |
| `MEMBER_VIEW` | 명단 조회 | 회원 명단 화면 조회 | 소속(지파·교회) |
| `MEMBER_EXPORT` | 명단 내보내기 | 명단 CSV/다운로드 (조회 권한과 **별도** 코드) | 소속(지파·교회) |

`[AI directive]`
- If there is any export/download feature, split out a **dedicated `*_EXPORT`/`*_DOWNLOAD` code**. Do not fold it into a general `VIEW`/`MANAGE` (review C1).
- `SUPER_ADMIN` grants must be minimal and justified (review B5), and the bootstrap admin must be a real operator (no test leftovers).
- The catalog is a draft. The final schema, resolution algorithm, and the two mandatory pages (permission guide (권한 안내) / permission management (권한 관리)) follow `references/permission-model.md`.

## Item 7 — Login-required verdict (§A2 policy P-1)

`[AI directive]` The criterion for requiring login is **whether the system handles internal information** (§A2 policy P-1 — matches the Zion canon). Internal information = anything not meant for the public (member data/personal data, external contact lists, org/operational information, strategy, non-public notices, etc.). **If the system handles any internal information at all, Zion Login is mandatory**; only fully public content is exempt. One narrow exception: a **small public collection form** built strictly on the write-only pattern of §A2 policy P-3 (no read/manage/export path, forward-and-purge) needs no Zion Login — verify every P-3 condition before claiming it, and record the claim under item 7.

| What the system handles | Verdict | Login |
|---|---|---|
| Member data (이름·소속·직책·고유번호 etc.) | Internal information (personal data) | **Zion Login required** |
| Personally identifiable contacts/rosters | Internal information (personal data) | **Required** |
| Operational/strategic/non-public notices | Internal information | **Required** |
| Internal sensitive aggregates identifying no individual (e.g. per-tribe offering totals) | Internal information (not personal data) | **Required** |
| Small public collection form, write-only pattern (§A2 P-3, all conditions met) | Non-member PII, no read surface | Not required (P-3) — re-triage on any change |
| Only fully public content (public notices, public marketing) | Public | Not required |
| **When in doubt** | Treat as internal information | **Required** |

`[⚠ Conflict resolution]` (conflict-resolution table #3)
- Apply the *internal information* criterion of Zion **hard rule 7 · review E1** as-is (§A2 policy P-1). Whether it is personal data (고유번호 etc.) or internal sensitive information that identifies no individual (sensitive aggregates etc.), **internal information → login is mandatory**. This matches the HQ §E review, so there is **no rejection risk**.
- Client-side password gates/overlays/`localStorage` flags do not count as a boundary (review E3 — they check after the data has already reached the browser, so they are meaningless). Authentication is enforced **server-side**.

## Item 8 — Review track (§A2 policy P-2)

`[AI directive]` Determine the production-key **review track** now and record it in the spec (it is re-checked when `04_predeploy_verification.md` completes, and marked in the `05_production_key_request.md` request):

- **Lightweight track (경량 트랙)** — claimable only when ALL P-2 conditions hold: ① member data used at most for login + self-identity display (or none) ② no export/download features ③ no bulk PII processing ④ one using department and expected total users ≤ 100 ⑤ the full 04 gate will still be run and passed. Effect: HQ may review only the 5-item request + scanner report.
- **Full track** — everything else (any member-list screen, export, bulk processing, or larger scale).

HQ makes the final call; the track claim in the spec is an input, not an entitlement. If eligibility breaks later (a new list screen, an export, growth), the next change goes through the full track.

## Spec template (paste-ready)

```markdown
# 기획안 — {시스템명} ({N지파})

## 1. 기능 요약
{시스템이 하는 일 한두 문장}

## 2. 회원데이터 화면·API 목록
- 화면: {예) 회원 명단, 회원 상세, 권한 관리}
- API: {예) GET /members, GET /members/{newNo}, POST /permissions/grant}

## 3. 조회 항목 (4개 한정)
NAME(이름) · NEW_NO(고유번호) · ORGANIZATION_PATH(소속) · ORGANIZATION_WITH_DUTY(직책)
- 그 외 항목: 없음  (있다면: {항목} + 총회 승인 근거 {링크/일자})

## 4. 권한코드 초안 카탈로그
| code | label | description | scope |
|------|-------|-------------|-------|
| SUPER_ADMIN | (예약) 최고관리자 | 모든 권한(DO_EVERYTHING 자동) | 전체 |
| {CODE} | {label} | {description} | {전체/소속/본인} |

## 5. 사용부서
{운영 주체 부서} / {실제 사용 부서·직책 범위}

## 6. 예상 사용자 규모
{대략의 총/동시 사용자 수}

## 7. 로그인 필요 여부 (내부정보 기준 §A2 P-1)
{내부정보(회원데이터·개인정보·내부 민감 집계 등) 있음 → 시온로그인 필수 / 완전 공개만 → 불요
 / 소형 수집 폼(쓰기 전용, §A2 P-3 요건 전부 충족) → 불요(P-3)}  근거: {한 문장}

## 8. 심사 트랙 (§A2 P-2)
{일반 트랙 / 경량 트랙 — 경량이면 P-2 요건 ①~⑤ 충족 여부를 한 줄씩 명시}
```

`[Check]` Spec completion criteria
- [ ] All 8 items are filled in, with no blanks or vague wording.
- [ ] Exactly 4 query properties (any excess has a recorded HQ approval basis).
- [ ] The draft permission codes reserve `SUPER_ADMIN`, and any export feature has a separate `*_EXPORT` code.
- [ ] The login-required verdict (internal-information criterion, §A2 P-1) is stated explicitly (internal information → required / fully public only → not required / P-3 write-only form → not required, with every condition checked).
- [ ] The review track (item 8) is stated; a lightweight-track claim lists the P-2 conditions it satisfies.

---

# Part B. Request the Alpha (Development) Key

The alpha key is what lets you actually build and test the login flow against the `alpha-` endpoints (next file: `03_build_and_alpha_test.md`). **No key is bundled with the skill** — it is a credential controlled by HQ, issued only after you tell them what you are building and how you will use it. This applies to the alpha key too (the difference from production is the review bar, not whether you must ask).

## [바이브코더 안내] 누구에게 · 무엇을 · 어떻게

`[바이브코더 안내]`
- **누구에게:** **총회 정보통신부 전산개발과**.
- **무엇을:** "무엇을 만드는지, 이 키를 어떻게 쓸지"(시스템·부서·다루는 회원데이터)를 담은 짧은 신청 문구. 아래 템플릿을 복사해 빈칸만 채우면 된다.
- **어떻게:** 위 담당 부서에 **직접 연락**해서 보낸다. **접수 경로(이메일·사내 시스템 등)를 모르면**, 소속 지파 관리자나 총회 대표 창구에 「시온로그인 키 신청은 어디로 접수하나요?」라고 먼저 물어 창구를 확인한 뒤 아래 문구를 보낸다. 연락한 뒤 담당자가 알파 키를 전달한다.

> **자동 전송 아님(중요):** 이 스킬이나 AI는 총회로 신청을 **자동 전송하지 않는다.** 위 신청 문구는 바이브코더가 **직접** 총회 정보통신부 전산개발과에 보내야 한다. AI는 문구를 만들어 줄 뿐, 발송하지 않는다.

## Alpha key request message template (paste-ready — complete form)

```
받는 곳: 총회 정보통신부 전산개발과
제목: 시온로그인 알파(개발용) 키 신청 — {시스템명} ({N지파})

1. 시스템명 / 지파: {시스템명} / {N지파}
2. 기능 요약: {시스템이 하는 일 한두 문장}
3. 사용부서: {운영·사용 부서}
4. 다루는 회원데이터(4개 한정):
   이름(NAME) · 고유번호(NEW_NO) · 소속(ORGANIZATION_PATH) · 직책(ORGANIZATION_WITH_DUTY)
   ※ 그 외 항목 없음
5. 요청 취지(개발용/알파): alpha- 개발·테스트 환경에서 로그인·권한 흐름을
   구현·검증하기 위한 알파 키를 요청합니다. 프로덕션 키는 배포 전
   보안점검(리뷰게이트) 통과 후 별도로 신청하겠습니다.

회신 받을 연락처: {이름 / 연락 수단}
```

## No redirect_uri pre-registration is needed

`[AI directive]` · `[바이브코더 안내]`
- 시작에 필요한 것은 **키뿐**이다. **redirect_uri 사전등록은 요구되지 않는다.**
- 키를 받은 뒤에는 로컬 `redirect_uri`(요청 헤더 `X-Forwarded-Proto` + `Host`에서 자동 감지)로 개발을 시작한다. `OAUTH2_REDIRECT_URI`를 비워 두면 자동 감지된다.

## After receiving the key — `.env` is gitignored, `.env.example` holds placeholders only

`[AI directive]`
1. Put the received alpha `client_id` in the local **`.env` (gitignored)** only. Never in source, `.env.example`, or the distributed skill.
2. **Verify before committing** that `.gitignore` includes `.env`.
3. The `.env.example` committed to the repo holds **placeholders (empty values) only**. Never a real key.
4. **One `client_id` per system** — never reuse another app's/site's/tribe's key.

`.env.example` (committed — placeholders only):

```
# .env.example — 커밋 대상. 실제 키 금지, 자리표시자만.
OAUTH2_CLIENT_ID=            # 총회에서 발급받아 로컬 .env에만 입력
OAUTH2_AUTH_URL=
OAUTH2_TOKEN_URL=
OAUTH2_USERINFO_URL=
OAUTH2_VALIDATE_URL=
OAUTH2_AUTHORITIES_URL=
SESSION_REVALIDATE_SECONDS=300
CORS_ORIGINS=
# JWT_SECRET 없음 — 이 키가 존재하면 리뷰 지적 사항(로컬 토큰 발행 신호)
```

The concrete setup procedure for filling the local `.env` (gitignored) with the real alpha key and the `alpha-` endpoints is covered in **the next file**, `03_build_and_alpha_test.md` (not repeated here).

`[⚠ Conflict resolution]` (conflict-resolution table #10)
- Pre-existing **G1** (no hardcoded credentials) + Zion **D11** (one unique key per system, no reuse).
- **Verdict → apply both.** Keep the key out of source and `.env.example` (G1), and use only a key newly issued for this specific system (D11). Reuse defeats per-system attribution and revocation.

`[Check]` Alpha key stage completion criteria
- [ ] The request message was sent **directly** by the user to 총회 정보통신부 전산개발과 (not auto-sent by the AI).
- [ ] The alpha `client_id` was received and placed only in the local `.env` (gitignored).
- [ ] `.gitignore` includes `.env`, and `.env.example` holds placeholders only.
- [ ] `JWT_SECRET` exists nowhere. No redirect_uri was pre-registered (the key alone is used).

---

`[Next step]`
Once the alpha key is in hand, move to `03_build_and_alpha_test.md` to implement the core flow against the `alpha-` endpoints and test login, permissions, and scope. (When using another conversational AI: have the user upload/paste `03_build_and_alpha_test.md` (개발+알파테스트 파일) to start.)
