# 03 Build + Alpha Test

## When to read this file
Read this file from the moment the spec is finalized in `02_spec_and_alpha_key.md` and the **alpha key (`client_id`) has just been received from HQ (총회)**, through writing the actual code and confirming that login, permissions, and scopes work in the alpha (development) environment. The production key is not needed yet.

## What this file contains
- **[AI directive]** — implement the Zion Login core flow, session model, and permission model against the alpha endpoints (`alpha-` prefix), exactly as in `01_zion_login_canon.md`, `references/permission-model.md`, and `references/api-catalog.md`. Implement the two mandatory pages (permission guide (권한 안내) / permission management (권한 관리)). Keep retroactive application (R0-8) in force.
- **[바이브코더 안내]** — `.env` alpha setup example, running the app and clicking login, verifying the 4 displayed fields, SUPER_ADMIN auto-detection, the permission-grant test with fail-closed check, the data-scope filter check, and the local command-execution handle (per runtime).
- **[Check]** — alpha-stage completion criteria.

> **Premise (decided in 02):** the spec (features, member-data screens/APIs, the 4 lookup fields, draft permission codes, using department, internal-information status) is finalized, and the HQ-issued **alpha `client_id` is in hand.** If not, go back to `02_spec_and_alpha_key.md`. The alpha stage requires no `redirect_uri` pre-registration (with the key alone, develop against a local `redirect_uri`).

---

## [AI directive] — Implement Zion Login against the alpha environment

### A1. Environment is pinned to alpha (`alpha-` prefix)
Develop and test **only against the alpha hosts**. The endpoints are fixed values; **only the key (`client_id`) is a variable**. The production switch (dropping the prefix) happens at the deploy stage (`06_deploy_and_operations.md`) — never call production hosts during the alpha stage.

| Variable | Alpha value | Notes |
|---|---|---|
| `OAUTH2_CLIENT_ID` | (HQ-issued alpha key) | Never hardcode or commit. Local gitignored `.env` only |
| `OAUTH2_AUTH_URL` | `https://alpha-auth.ziongroup.net/oauth/authorize` | Path is `/oauth/` (NOT `/oauth2/`) |
| `OAUTH2_TOKEN_URL` | `https://alpha-auth.ziongroup.net/oauth/token` | Path is `/oauth/` |
| `OAUTH2_USERINFO_URL` | `https://alpha-api.ziongroup.net/api/auth/v3_0/me` | Use `v3_0` only; `v2_0/me` forbidden |
| `OAUTH2_VALIDATE_URL` | `https://alpha-api.ziongroup.net/api/auth/v1_0/validate` | Session revalidation |
| `OAUTH2_AUTHORITIES_URL` | `https://alpha-api.ziongroup.net/api/external/v1/user-authorities` | Used **only for the `DO_EVERYTHING` → SUPER_ADMIN check** |
| `OAUTH2_REDIRECT_URI` | (auto-detected from `X-Forwarded-Proto`+`Host` when unset) | Trust `X-Forwarded-Proto` behind a proxy |
| `SESSION_REVALIDATE_SECONDS` | default `300` | Maximum lifetime of a validation result |
| `CORS_ORIGINS` | first entry = the OAuth callback front-end origin | Comma-separated |

- **There is no `JWT_SECRET`.** Its presence in config is itself a review finding (someone is minting local tokens) — do not add it.
- There is no `client_secret`. The `client_id` itself is the ZAuth REST API Key.

### A2. Core flow (strict order — as in `01`)
Implement the core flow of `01_zion_login_canon.md` exactly. Summary:

1. Front-end "시온로그인" click → `{API_BASE}/auth/login`.
2. Backend `GET /auth/login` → generate `state` (32+ bytes random), store server-side → `302` → `{OAUTH2_AUTH_URL}?client_id&redirect_uri&response_type=code&state`.
3. Callback `GET /auth/callback?code&state` → **verify `state`** (reject on mismatch = CSRF) → `POST {OAUTH2_TOKEN_URL}` (`grant_type=authorization_code`, `client_id`, `redirect_uri`, `code`, **timeout=10**, no `client_secret`).
4. `GET {OAUTH2_USERINFO_URL}?properties=NAME,NEW_NO,ORGANIZATION_PATH,ORGANIZATION_WITH_DUTY` (Bearer) → unwrap `data.properties` (fallback `properties`).
5. Upsert the member (`newNo`, `name`, org-path snapshot, duties snapshot).
6. `GET {OAUTH2_AUTHORITIES_URL}` (Bearer) → SUPER_ADMIN if `roleBased` contains `DO_EVERYTHING`. **Use authorities for this check only.**
7. effective permissions = local 고유번호 grants `∪` (ALL if SUPER_ADMIN).
8. Create the session row: key = `SHA-256(access_token)`, value = identity + permissions + expiry.
9. `302` → `{FRONTEND_URL}/#/auth/callback?token={access_token}` → the front-end parses and stores the token, then attaches `Authorization: Bearer {token}` to every API call.

### A3. Session model (as in `01`)
- The session row stores **only the `SHA-256(access_token)` hash**. The raw token is never persisted server-side and never logged.
- Per request: Bearer → hash lookup → confirm existence and non-expiry → attach identity + permissions. No row → `401`.
- Periodic revalidation: at most every `SESSION_REVALIDATE_SECONDS` (default 300), `GET {OAUTH2_VALIDATE_URL}` (Bearer). `valid=false`, `success=false`, `401/403`, network errors — **every abnormal result invalidates the session (fail-closed)** and returns `401`.
- Expiry: the session's absolute lifetime follows the token's `exp`. **Unverified decoding** of the JWT payload to read `exp` is allowed for scheduling purposes only (trust comes only from the validate endpoint).
- Logout = delete the session row (remove the front-end token too). There is no separate local-token revocation concept.
- Permissions are **fixed at login** and stored in the session. 고유번호 permission changes take effect at the next login; for emergency revocation, delete that user's sessions (forced re-login).

### A4. Permission model (as in `references/permission-model.md`)
- The local **고유번호 (`newNo`) → permission-code** table is the **SSOT**. Duties (`organizationWithDuties`, filtered by `type=="DUTY"`) are **display-only**, never a permission input.
- **SUPER_ADMIN = a wrapper over ZAuth `DO_EVERYTHING`.** If user-authorities `roleBased` (global ∪ app) contains `DO_EVERYTHING`, the user is SUPER_ADMIN — **full access with no DB row**, bypassing individual permission checks. ZAuth returns `DO_EVERYTHING` and never returns the name `SUPER_ADMIN` → match on `DO_EVERYTHING`.
- A local `SUPER_ADMIN` grant row is an optional offline fallback (for bootstrap).
- **fail-closed:** unknown 고유번호, resolution errors, empty assignments → empty permission set; never default-allow.
- **Permission (what) ≠ scope (whose data).** Scope derives from `organizationPaths` (지파/교회) and is applied **as a query filter on every data route**.
- Every API route **declares its required permission explicitly**. An undeclared route is a review finding. SUPER_ADMIN satisfies any declared permission.
- SUPER_ADMIN **cannot bypass the audit log** — master actions are all recorded.

### A5. The two mandatory pages (non-negotiable)
| Page | Who can access | Implementation requirements |
|---|---|---|
| ① Permission guide (권한 안내/catalog) | Any authenticated user | Render the DB catalog as **label + description** (never expose UPPER_SNAKE codes). A "my permissions" section in the user's language. SUPER_ADMIN shows "전체 관리자(모든 권한)". Locked features explain the reason (which permission, how to obtain it) in the user's language. |
| ② Permission management (권한 관리) | `SUPER_ADMIN` or delegated `PERMISSION_ADMIN` only | Search a member by 고유번호 → confirm identity (이름·소속) → pick permission codes by label → (optional) reason → grant. Active-assignment list + soft revoke. **Grant/revoke audit trail** (who, when, to whom, which permission). Granting `SUPER_ADMIN` requires an explicit confirmation step and is highlighted in the audit. The most sensitive surface in the system — always permission-gated + fully audited. |

### A6. User-facing naming (applies even in the alpha UI)
- **Never expose 'ZAuth'.** The login button reads "시온로그인" (or the site's polished variant).
- No permission codes, internal IDs, enums, or schema field names in end-user UI. `newNo` is always labeled **'고유번호'**.
- Describe duty-derived permissions as "교적에 등록된 직책에 따라 자동 부여" (though in this edition duties are display-only, so actual permissions come from 고유번호 assignments).

### A7. Retroactive application (R0-8)
If this guide was injected **mid-development**, apply the rules above **retroactively to code already written and fix it** before proceeding. If canon violations already exist — self-issued JWT, `JWT_SECRET`, duty-based automatic permissions, client-side-only gates, requesting more than the 4 fields — remove or fix them first.

### A8. Frequently wrong values (the main causes of login failure — recheck `01`)
When login fails in alpha, it is usually one of the four below. Full canon: `01_zion_login_canon.md`.

| # | Rule | Common mistake |
|---|---|---|
| 1 | OAuth path is `/oauth/` | Typo `/oauth2/` because the env vars are named `OAUTH2_*` |
| 2 | Request property is **singular** `ORGANIZATION_WITH_DUTY` | Requesting the plural → Zion Login rejects it, login fails |
| 3 | Response JSON key is **plural** `organizationWithDuties` | Reading the singular → parse failure (send singular, read plural) |
| 4 | No `client_secret` | Putting a nonexistent secret in the token exchange → failure |

---

## [바이브코더 안내] — 알파 테스트 절차 (한 단계씩)

지금부터는 **당신(사람)이 직접** 확인하는 부분이다. AI가 코드를 만들면, 아래 순서대로 눈으로 확인한다. 막히면 그대로 AI에게 "여기서 이렇게 나와요"라고 말하면 된다.

### 손잡이: 로컬 명령을 실행해야 할 때
앱을 켜거나 빌드하는 등 **컴퓨터에서 명령을 직접 돌려야 할 때**가 있다. 실행 명령은 프로젝트마다 다르므로 AI가 알려주는 명령을 그대로 쓰면 된다. **명령을 실제로 실행하는 방법은 지금 쓰는 AI(실행 환경)에 따라 다르다** — 아래에서 자기 경우를 고른다.

| 지금 쓰는 AI | 명령 실행 방법 |
|---|---|
| **Claude Code** | 채팅창에 **맨 앞에 `!` 를 붙여** 입력한다. 예: `! npm run dev` |
| **Codex 등 코딩 에이전트** | 에이전트가 대신 실행한다. "앱을 실행해 줘"라고 말하면 된다. |
| **ChatGPT·Gemini·Cursor chat 등** (명령 실행 불가) | AI는 명령을 **알려만** 준다. 당신이 직접 컴퓨터의 **터미널**(Windows는 PowerShell, Mac은 터미널 앱)을 열어 AI가 준 명령을 붙여넣어 실행한다. |

예로 드는 명령: `npm run dev` / `python app.py` / `docker compose up`. 무슨 명령을 넣을지 모르면 "앱 실행 명령이 뭐예요?"라고 AI에게 물어본다.

### 1단계: `.env`에 알파 키·엔드포인트 넣기
프로젝트 루트에 `.env` 파일을 만들고 아래를 붙여넣은 뒤, **`OAUTH2_CLIENT_ID=` 뒤에 총회에서 받은 알파 키만 채운다.** 나머지 주소는 그대로 둔다. (Claude Code·Codex는 AI가 이 파일을 만들어 준다. ChatGPT·Gemini 등에서는 **당신이 직접** 프로젝트 폴더에 `.env` 파일을 만들어 붙여넣는다 — Windows 탐색기는 이름이 `.env`로 **끝나는**(앞이 비어 있는) 파일 생성을 거부할 수 있으니, 메모장에서 "다른 이름으로 저장 → 파일 형식: 모든 파일 → 이름 `.env`"로 저장하면 된다.)

```env
# ── 시온로그인 알파(개발/테스트) 설정 ──
OAUTH2_CLIENT_ID=            # ← 총회에서 받은 알파 키를 여기에. 하드코딩·커밋 금지
# alpha (development/testing)
OAUTH2_AUTH_URL=https://alpha-auth.ziongroup.net/oauth/authorize
OAUTH2_TOKEN_URL=https://alpha-auth.ziongroup.net/oauth/token
OAUTH2_USERINFO_URL=https://alpha-api.ziongroup.net/api/auth/v3_0/me
OAUTH2_VALIDATE_URL=https://alpha-api.ziongroup.net/api/auth/v1_0/validate
OAUTH2_AUTHORITIES_URL=https://alpha-api.ziongroup.net/api/external/v1/user-authorities
# production drops the alpha- prefix on both hosts
OAUTH2_REDIRECT_URI=        # 비워두면 요청 헤더로 자동감지
SESSION_REVALIDATE_SECONDS=300
CORS_ORIGINS=http://localhost:5173   # 첫 항목이 로그인 콜백 프론트 주소
```

- **주의:** 이 `.env`(실제 키가 든 파일)는 **절대 커밋하지 않는다.** `.env.example`에는 키 자리에 빈칸/자리표시자만 남긴다. (레포는 private로 유지 — `01b_common_security_conflicts.md` (개발 전 공통 보안·충돌해소 파일)·`04_predeploy_verification.md` (배포 전 검증 파일) 참조.)
- `JWT_SECRET` 같은 항목은 넣지 않는다. 있으면 지운다.

### 2단계: 앱 실행 → 로그인 → 4개 필드 확인
1. 위 「손잡이」의 자기 환경에 맞는 방법으로 앱을 실행한다. AI가 접속 주소(예: `http://localhost:5173`)를 알려준다.
2. 브라우저로 접속해 **"시온로그인"** 버튼을 클릭한다.
3. 시온로그인 화면에서 본인 계정으로 로그인한다.
4. 로그인 성공 후 화면(프로필/헤더/회원 정보 등)에 **아래 4가지가 표시되는지** 확인한다.

| 확인 항목 | 화면에 보여야 하는 것 |
|---|---|
| 이름 | 내 이름(name) |
| 소속 | 지파 → 교회 등 소속 경로(organizationPaths) |
| 직책 | 내 직책(organizationWithDuties, 표시용) |
| 고유번호 | 내 고유번호(`newNo`, 항상 '고유번호'로 표기) |

- 버튼·화면 어디에도 'ZAuth', 권한코드, 내부 ID 같은 개발자 용어가 보이면 안 된다. 보이면 AI에게 알려 고친다.

### 3단계: 최초 로그인자 = SUPER_ADMIN 자동 확인
- 회원 명부에서 **`DO_EVERYTHING` 권한을 가진 사람**(보통 담당 관리자)이 처음 로그인하면, **DB에 아무 설정을 하지 않아도 자동으로 전체 관리자(SUPER_ADMIN)** 가 되어야 한다.
- 확인법: 권한이 부여된 적 없는 빈 상태에서도 그 사람에게 「권한 관리」 페이지가 열리고, "전체 관리자(모든 권한)" 표시가 보이면 정상이다.
- 이 사람이 없거나 authorities를 못 부르는 특수 환경이면 오프라인 폴백(부트스트랩 행)을 쓴다 — 그때는 AI에게 "부트스트랩 관리자 고유번호를 넣어 달라"고 요청한다.

### 4단계: 「권한 관리」에서 권한 부여 테스트
1. 전체 관리자로 로그인한 상태에서 **「권한 관리」** 페이지를 연다.
2. **다른 사람의 고유번호로 검색** → 이름·소속이 맞는지 확인 → 권한을 이름(label)으로 골라 부여한다.
3. **감사 이력**에 "누가·언제·누구에게·어떤 권한"이 기록되는지 확인한다.
4. 그 사람이 다시 로그인하면(권한은 로그인 시 반영됨) 부여한 기능이 열리는지 확인한다.

### 5단계: 권한 없는 사용자가 막히는지(fail-closed) 확인
- 아무 권한도 없는 계정으로 로그인해 **보호된 기능/페이지에 접근**을 시도한다.
- **막혀야 정상이다**(권한 없음 = 접근 거부). 권한이 없는데 열리면 안 된다.
- 특히 **「권한 관리」 페이지**는 일반 사용자에게 절대 열리면 안 된다(SUPER_ADMIN 또는 PERMISSION_ADMIN만).
- "권한이 없어 열리는" 경우가 하나라도 있으면 심각한 문제이므로 AI에게 즉시 알린다.

### 6단계: 데이터 스코프(지파/교회) 필터 확인
- 서로 **다른 지파/교회 소속** 계정 둘로 각각 로그인해 회원 목록 등 데이터 화면을 본다.
- 각자 **자기 소속 범위의 데이터만** 보여야 한다. A 지파 사용자가 B 지파 데이터를 보면 안 된다.
- 권한이 있어도 스코프 밖 데이터는 걸러져야 한다(권한과 스코프는 별개 축).

> **계정이 하나뿐이라면(혼자 개발 중):** 5·6단계는 여러 계정이 있어야 실측된다(무권한 계정·타지파 계정 필요). 혼자라면 (a) 다른 지파/교회 동료 1~2명에게 잠깐 로그인 협조를 받거나, (b) 총회 정보통신부 전산개발과에 **테스트용 계정**을 요청한다. 계정을 못 구하면 이 두 항목은 코드상(권한검사·스코프 필터가 걸려 있는지)만 확인한 뒤 「미검증」으로 남기고, **배포 전 `04_predeploy_verification.md` 단계에서 반드시 실계정으로 재확인**하도록 AI에게 알린다.

---

## [⚠ Conflict resolution] Where Zion-first applies during alpha development
- Even if you want your own login/password or a self-issued JWT, **the only session token is the Zion access_token** (Zion wins on conflict). Even with a custom login UI, the actual session is Zion's.
- Identity is **the 고유번호 of the Zion session**, not Supabase/Firebase `auth.uid()`. Instead of browser→DB direct access, implement it via the backend (behind the session gate), and **enforce data scope as a backend query filter (`organizationPaths`)** (RLS is a second line of defense blocking non-`service_role` paths; `service_role` bypasses RLS, so RLS is not evaluated on `service_role` queries).
- Even with identity established, without **authorization (permission checks) + the scope filter** every member can read all data — always apply both axes.
- Full conflict-resolution table: `01b_common_security_conflicts.md`.

---

## [Check] Alpha-stage completion criteria
All of the below must **pass** before moving on. (Exception: **fail-closed and the scope filter** can only be measured for real with multiple real accounts — if accounts cannot be obtained, verify them in code only, mark them 「미검증」 (unverified), and re-verify with real accounts in `04_predeploy_verification.md` without fail.)

- [ ] **Login:** "시온로그인" → after success, the 4 fields 이름·소속·직책·고유번호 are displayed. No 'ZAuth' or developer terminology in the UI.
- [ ] **Session:** after login, APIs work with `Authorization: Bearer`; access is blocked after logout; a failed revalidation (validate) forces re-login (fail-closed).
- [ ] **SUPER_ADMIN auto:** a `DO_EVERYTHING` holder is recognized as full admin with no DB setup.
- [ ] **Granting:** in permission management (권한 관리), permissions can be granted/revoked by 고유번호 with the audit trail recorded.
- [ ] **fail-closed:** users without permission are blocked from protected features and from the 권한 관리 page.
- [ ] **Scope filter:** users of a different 지파/교회 cannot see data outside their own scope.
- [ ] **Two pages working:** ① permission guide (label/description, "my permissions", no codes exposed) ② permission management (search, grant, revoke, audit) both work.
- [ ] **Environment hygiene:** `.env` not committed, no `JWT_SECRET`, alpha endpoints (`alpha-` prefix) and `/oauth/` paths confirmed.

---

## [Next step]
Once every [Check] item passes, move on to the mandatory pre-deploy gate → `04_predeploy_verification.md`.
(If the permission/flow implementation gets stuck: canon in `01_zion_login_canon.md`, permission details in `references/permission-model.md`, API schemas in `references/api-catalog.md`.)
