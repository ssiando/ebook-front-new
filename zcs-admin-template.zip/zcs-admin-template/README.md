# ZCS Admin Template

A small, correct, **beginner-friendly admin starter** for the 신천지행정시스템 family.
It is meant to be set up and extended **with or without an AI assistant** — this README is
the source of truth for everyone. Read it fully before changing anything.

> **The single most important rule:** this app handles **성도 개인정보 (member personal
> data)** from the Zion platform. Privacy and security are not optional polish — they are
> the point. When in doubt, choose the safer option.

> Using an AI assistant (Claude Code, etc.)? See [`CLAUDE.md`](./CLAUDE.md) for a few
> assistant-specific working notes — but everything substantive lives **here**.

---

## 1. What this template is

It gives you a working spine so you can add your own admin screens without re-solving the
hard parts:

- **Zion 로그인** (sign in with a Zion account) — already wired, fail-closed. The session
  token **is** the Zion-issued access token (the app never mints its own); the server keeps
  only a SHA-256 hash of it and periodically revalidates it against Zion Login.
- A **local permission model** keyed by **고유번호** — already wired.
- The **ZCS (Zion Console System)** design system — already vendored; build every screen
  from it.
- A **위아원 (WeAreOne) QR** issuance example — already wired.
- One **worked feature (공지사항 / notices)** you copy to make new features.

**Stack:** Go (standard library, 2 small deps) + PostgreSQL backend · React 19 + Vite +
TypeScript frontend · docker-compose for local dev. UI is **Korean-only** (all text lives
in `frontend/src/locales/ko.json`, ready to extend to more languages later).

**This template is intentionally small.** Do not add frameworks, ORMs, state libraries, or
UI kits unless you truly need them. A beginner is better served by less.

**Distribution mark (never remove).** The footer of the app shell and the login screen
shows "총회 정보통신부 전산개발과 배포 · Template v1.0.0"
(`frontend/src/components/DistributionMark.tsx`). It is the HQ distribution attribution
and must stay visible in every fork — do not delete, hide, or restyle it away.

---

## 2. ⚠️ BEFORE ANYTHING WORKS: 총회 registration (manual, blocking)

Using Zion 로그인 + member data is **not self-service**. Someone must **contact the 총회
(HQ / 전산팀) by hand** and ask for the app to be registered. Until that is done, **real
login cannot succeed** — the app behaves "as if it does not exist".

You must obtain, from the 총회, exactly **one thing**:

1. **A `client_id`** — this is the **REST API Key**. → goes into `OAUTH2_CLIENT_ID`.
   **There is no `client_secret`.** Zion's login uses `client_id` alone. (If anyone tells
   you to "paste the client secret", that is a misunderstanding — there isn't one.)

That is the whole registration. In particular:

- **No callback-URL registration.** The app assembles its own `redirect_uri`
  automatically from the request (`X-Forwarded-Proto` + `Host`); nothing is registered in
  a console. `OAUTH2_REDIRECT_URI` stays as an optional explicit override.
- **No custom authority registration.** Super-admin is not a per-app authority anymore:
  whoever holds Zion's global master authority **`DO_EVERYTHING`** in the member registry
  is super-admin here on day one — no console work, no DB seeding. They log in and grant
  everyone else access locally (§4).

**This template does NOT need an Admin Key / Admin-API approval.** It only ever talks to
Zion during a user's own login (Bearer-REST-only). It never makes server-to-server calls.
(If you later add a feature that needs member data *without* that person logging in — e.g.
looking someone up by 고유번호 — that *does* require Admin-API approval + an Admin Key, a
separate request to the 총회.)

> In anything an end user reads, never write "ZAuth". The login button says **"시온로그인"**,
> account inquiries go to the **정보통신부** ("계정 문의는 정보통신부로 연락해 주세요."), and
> registration is "총회에 사용 등록을 요청해야 합니다". "ZAuth" is internal developer terminology.

---

## 3. Running it locally

Two modes, depending on whether 총회 registration is done.

### Mode A — try it immediately, before 총회 registration (dev bypass)

For exploring the UI locally without a real Zion account. This turns on a **local-only**
login panel that mints a session without Zion 로그인.

```bash
DEV_BYPASS_AUTH=true docker compose --profile frontend up -d --build
# open http://localhost:8081
```

- ⚠️ **`DEV_BYPASS_AUTH=true` is for your own machine ONLY.** It exposes
  `POST /api/auth/test-login`, which can mint a **super-admin without any password**.
  **Never** run with this flag on a server reachable from the internet. The default is
  `false` precisely so this can't happen by accident.

### Mode B — the real flow, after 총회 registration

```bash
# 1. Create backend/.env from the example and fill in the real values:
cp backend/.env.example backend/.env
#    set OAUTH2_CLIENT_ID (the REST API Key from 총회),
#        QR_SECRET    (openssl rand -base64 48),
#        QR_SCAN_BASE_URL and the prod CORS_ORIGINS.
#    OAUTH2_REDIRECT_URI is optional — leave empty to auto-detect from the request.
# 2. Start the stack (DEV_BYPASS_AUTH stays false):
docker compose --profile frontend up -d --build
```

- Backend-only (no UI): `docker compose up -d --build` → `http://localhost:8080`.
- Frontend dev server with hot reload: `cd frontend && npm install && npm run dev`.
- Database migrations run **automatically at startup** — there is no migrate command.
- Health check: `GET /api/health`.

Full environment-variable reference, secrets, and reverse-proxy requirements live in
`_workspace/03_infra_env.md`. **Read it before deploying** — together with
`_workspace/CHANGELOG-zion-login-retrofit.md`, which corrects the parts of the older
docs that predate the Zion Login retrofit. The only secret to generate is `QR_SECRET`
(`openssl rand -base64 48`). **There is no `JWT_SECRET`** — the app never signs its own
session token; the session token is the Zion-issued access token itself. Two session
envs matter here:

- `OAUTH2_VALIDATE_URL` — Zion's token-validation endpoint
  (`{API_URL}/api/auth/v1_0/validate`); sessions are periodically re-checked against it.
- `SESSION_REVALIDATE_SECONDS` (default `300`) — how old a validation result may get
  before the token is re-checked. Any non-valid answer ends the session (fail-closed).

---

## 4. The permission model (read this carefully — it is unusual)

This template **deliberately does NOT use** the standard Zion permission-catalog / RBAC
matrix. There is **no permission-list page**. Instead:

1. **Super-admin** = a person who holds Zion's canonical global master authority
   **`DO_EVERYTHING`** — checked once at login via the user-authorities API, looking only
   at `roleBased` permissions (global or app). The local super-admin role simply *wraps*
   that master authority; nothing app-specific is registered anywhere. This is the *only*
   thing the app ever reads from Zion authorities. The app never inspects job titles
   (직책) for permissions.
2. **Everyone else** gets access only if a super-admin (or a delegate) **adds their
   고유번호** on the **고유번호 접근 관리** page. That page is the *only* permission screen
   in the whole app.
3. A logged-in person who is neither super-admin nor granted sees the **권한 없음
   (noperm)** screen.
4. **Bootstrap:** whoever holds `DO_EVERYTHING` in the member registry is super-admin on
   day one — with an empty database and zero console work. They log in, then grant
   everyone else locally. (For local dev before 총회 registration, the
   `DEV_BYPASS_AUTH` test login still exists — §3 Mode A.)

**Rules to never break when extending this:**

- **Gate on the server, always.** Hiding a menu item is not security. Every protected
  endpoint must check access server-side (see `backend/internal/guard/`). The frontend
  gate (`access` block from `GET /api/auth/me`) is only for UX.
- **Fail closed.** If a permission check can't be evaluated, deny.
- Match `DO_EVERYTHING` **exactly** (case-sensitive), and only in `roleBased`
  permissions — ignore `orgBased` and every other authority name. An error from the
  authorities call means *not* super-admin, never a retry-as-super.
- A **delegate** (`can_manage_access`) may grant/revoke but must not be able to escalate
  themselves to super-admin.

---

## 5. ZCS — build every screen with it

ZCS (**Zion Console System**) is the design system. It is **plain CSS classes** — no
component library, no Tailwind. It is **vendored** into `frontend/zcs/` (a byte-identical
copy of the shared ZCS source).

- **Use ZCS classes for everything.** Buttons, tables, modals, forms, badges, the
  sidebar/topbar shell, the empty/no-permission states — they all exist already
  (`btn`, `tbl`, `modal`, `drawer`, `field`/`input`, `badge`, `noperm`, `emptystate`,
  `login`, …). Browse `frontend/zcs/design-system.html` for a live catalog, or look at the
  existing pages in `frontend/src/pages/` for real usage.
- **Never write raw hex colors or a second UI style.** If a color/spacing is needed, it is
  already a ZCS token (CSS variable). One cobalt accent only; the 12-tribe palette is for
  tribe identification (gems/chips), never as a general accent.
- **고유번호 is rendered in full**, fixed-width tabular, labeled **'고유번호'**. It is the
  public working key — showing it is fine and preferred over showing other personal data.
- **Do NOT edit `frontend/zcs/` (the vendored copy).** To refresh it from the shared
  source, run `npm run sync:zcs`. If you need a tweak ZCS lacks, add it to
  **`frontend/src/styles/zcs-a11y.css`** (the template's override layer) — never the
  vendored files. That file already adds accessibility fixes (focus rings, keyboard table
  rows, reduced-motion, mobile sidebar) and is the right place for small additions.

---

## 6. 위아원 (WeAreOne) QR

The admin **issues** an HMAC-signed QR; a 성도 then **scans it with the 위아원 app**.

- Issuance endpoint: `POST /api/qr/issue` → returns `{ scanUrl }`. The QR image is drawn
  **in the browser** from that URL (the backend ships no image library on purpose). See
  `frontend/src/pages/QrIssuePage` and `backend/internal/qr/`.
- The QR is signed with **this app's own `QR_SECRET`** (set it; `openssl rand -base64 48`).
  The template does **not** depend on any external QR signing service.
- **Security rules (already followed — keep them):** the signed token is **never logged**,
  the scan URL travels in the page, and the QR is meant to be **single-use / short-lived**.
  If you ever add a *consume/verify* endpoint (this template only issues), enforce:
  validate the HMAC, accept only within the time window, never log the token, strip it from
  the URL, set `Referrer-Policy: no-referrer`. (Reference: `edux` and `qr-attend` projects.)

---

## 7. Privacy & security — the non-negotiables (PIPA + GDPR)

This dataset is religious-membership data. Anyone copying this template inherits these
defaults; **do not weaken them**:

- **`고유번호` vs `주민번호`.** `고유번호` (newNo) is the *public working key* — shown in
  full, used to identify people. **`주민번호` (idNumber) is national-ID-grade — this app
  never touches, decrypts, displays, or logs it.** If a feature seems to need 주민번호,
  stop; the answer is almost always no.
- **Store the minimum.** Only `고유번호` is persisted (access grants + notice author). A
  person's name/tribe/church/직책 live only in their session, resolved fresh at login. The
  one exception is the notice **author-name snapshot** (so the feed shows a name instead of
  broadcasting the 고유번호) — a deliberate, documented trade-off. Don't add more persisted
  personal fields without a privacy reason.
- **Never put PII in logs or URLs.** No 고유번호, names, tokens, or request bodies in logs
  (the backend deliberately has no HTTP access log — don't add one in a proxy). 고유번호
  travels in request **bodies**, never in a URL or query string; address rows by their
  opaque id.
- **The access audit log** (who granted/revoked access) is **super-admin-only** to read and
  is retained for `AUDIT_RETENTION_DAYS` (default 365). Purge it on a schedule with
  `docker compose run --rm backend /app/server purge`. See `_workspace/03_infra_env.md` §7.
- **No real personal data in code, seeds, fixtures, screenshots, or docs.** Use obviously
  fake values like `00000000-00000`.
- **Secrets** (`QR_SECRET`, DB password) come from the environment / a secret store —
  never commit them. `.env` is git-ignored. The session token is the Zion-issued access
  token: the server stores **only its SHA-256 hash**, never the raw token, and never logs
  it.

---

## 8. How to add a new feature (copy the notices example)

The **공지사항 (notices)** feature is the worked example. To add, say, a "행사 (events)"
admin screen, copy its shape end-to-end:

**Backend** (`backend/internal/`):
1. Copy the `notices/` package to `events/` — it has the model, store queries, and HTTP
   handlers. Use **parameterized SQL only** (never string-concatenate input).
2. Add a numbered migration in `internal/store/migrations/` (e.g. `0002_events.sql`).
   **Never edit an already-applied migration** — always add a new file.
3. Register the routes in `cmd/server/main.go`, **wrapped in the same access guard** the
   notices routes use (`internal/guard/`). Decide: all access-holders, or super-admin only?
4. Update `_workspace/api_contracts.md` with the new endpoints (request/response shapes).
   Lists return `{ items: [...] }`; single objects are bare; mutations return `204`.

**Frontend** (`frontend/src/`):
5. Add types in `types/api.ts` matching the contract exactly (no `any`, no casts).
6. Add an API function in `services/`, a page in `pages/`, built **only from ZCS classes**
   (copy a notices page for the patterns: table, form modal, loading/empty/error states).
7. Add all Korean text as **keys in `locales/ko.json`** — never hardcode a string. Keep
   the copy natural; no developer words (no permission codes, enum names, internal ids) in
   anything the user sees.
8. Add the nav item in the shell, gated by the same access level as the backend route.

**Then verify:** `cd backend && go build ./... && go vet ./...` and
`cd frontend && npm run build` must both pass before you call it done.

---

## 9. Project map

```
backend/
  cmd/server/         entrypoint + route registration (+ `server purge` subcommand)
  internal/
    config/  zauth/   env config · Zion 로그인 (OAuth2) client
    session/ auth/    server sessions (ZAuth access token, hash-keyed, revalidated) · login/callback/me handlers
    guard/            server-side access checks (super-admin + local 고유번호 grants)
    access/           고유번호 grant/revoke + audit (the only permission feature)
    notices/          worked example feature — copy this
    qr/               위아원 QR issuance (HMAC sign)
    store/            DB + embedded SQL migrations
    httpx/ i18n/       JSON/error helpers · backend message catalog
frontend/
  src/
    components/       ZCS-based building blocks
    pages/            screens (notices, access management, QR, login, noperm)
    context/ hooks/   AuthContext, gating
    services/ types/  API client + contract types
    locales/ko.json   ALL user-facing text
    styles/zcs-a11y.css  the ONLY place to extend ZCS (override layer)
  zcs/                vendored ZCS (do not edit; refresh via `npm run sync:zcs`)
docker-compose.yml    local stack (db + backend; frontend behind --profile frontend)
_workspace/           design/spec/contract/review artifacts (read these for the "why")
```

The `_workspace/` folder holds the spec (`01_pm_spec.md`), design (`02_design_system.md`),
API contract (`api_contracts.md`), infra handoff (`03_infra_env.md`), and the security /
privacy / QA reviews (`04_review_report.md`, `05_qa_report.md`). When you ask "why is it
done this way?", the answer is usually in there.

---

## 10. Conventions

- **Keep changes scoped.** Don't touch shared/global things (the vendored ZCS, the auth
  spine) to satisfy a small feature request.
- **Match the surrounding code.** Same patterns, same file placement, minimal comments
  (only for a constraint the code can't express).
- **English** for code and docs; **Korean** for everything the end user reads.
- **Never call something done until the builds pass** and you've checked it against the
  §7 privacy/security rules. If a check fails, say so plainly.
