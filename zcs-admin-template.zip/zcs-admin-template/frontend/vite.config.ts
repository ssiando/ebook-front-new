import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// publicDir = the vendored ZCS folder. Vite serves it verbatim at the web root, so
// `/styles.css` (the ZCS entry) and `/zcs/*` (zcs.css, scj-logo.js, brand SVGs)
// resolve exactly the way ZCS's own scj-logo.js expects (document-root-relative
// `zcs/brand/...`). The files are copied as-is — never bundled or rewritten.
export default defineConfig({
  plugins: [react()],
  publicDir: "zcs",
  server: {
    port: 5173,
    // Dev proxy so the SPA can call same-origin `/api` (VITE_API_URL stays "").
    proxy: {
      "/api": {
        target: process.env.VITE_DEV_API_TARGET ?? "http://localhost:8080",
        changeOrigin: true,
      },
    },
  },
});
