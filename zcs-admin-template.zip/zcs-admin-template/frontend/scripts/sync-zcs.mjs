// Refresh the vendored ZCS copy (frontend/zcs/) from the shared ZCS source.
//
// ZCS is a plain-CSS design system that lives in its own repo/folder. We vendor a
// byte-identical copy into the template so the build is self-contained and the app
// never reaches outside frontend/. Run `npm run sync:zcs` to pull the latest ZCS.
//
// Mirrors the ZDS `sync:zds` pattern. The vendored files are kept UNMODIFIED — do
// not hand-edit anything under frontend/zcs/. Template-local fixes for ZCS gaps
// live in src/styles/zcs-a11y.css instead (see that file's header).
//
// Override the source location with ZCS_SRC=/path/to/zcs npm run sync:zcs

import { cp, rm, writeFile, stat } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const here = dirname(fileURLToPath(import.meta.url));
const DEST = resolve(here, "..", "zcs");
const SRC = process.env.ZCS_SRC ?? resolve(here, "..", "..", "..", "zcs");

// design-system.html is the ZCS reference page, not part of the runtime kit — skip it.
const SKIP = new Set(["design-system.html", ".git"]);

async function main() {
  try {
    await stat(SRC);
  } catch {
    console.error(`ZCS source not found: ${SRC}\nSet ZCS_SRC=/path/to/zcs and retry.`);
    process.exit(1);
  }

  await rm(DEST, { recursive: true, force: true });
  await cp(SRC, DEST, {
    recursive: true,
    filter: (src) => !SKIP.has(src.split("/").pop()),
  });

  await writeFile(
    resolve(DEST, "VENDORED.md"),
    [
      "# Vendored ZCS — generated, do not edit",
      "",
      `- Synced from: \`${SRC}\``,
      `- Synced at: ${new Date().toISOString()}`,
      "- Refresh with: `npm run sync:zcs`",
      "",
      "These files are a byte-identical copy of the ZCS source. Never hand-edit them.",
      "Template-local accessibility fixes for ZCS gaps (B1–B6) live in",
      "`src/styles/zcs-a11y.css`, loaded after ZCS — see that file's header.",
      "",
    ].join("\n"),
  );

  console.log(`ZCS vendored into ${DEST}`);
}

main();
