# ZCS — Zion Console System

The single design system for **신천지행정시스템** (Shincheonji Administration Platform). One unified system shared by every administrative module — Records, Theology, Outreach, and any future system. Built for high-volume record work: a compact, table- and bar-first UI.

> Replaces the retired arch-based ZDS. The 12-tribe palette is the only thing carried over.

## Use it

Link the single stylesheet entry, then build with the ZCS classes:

```html
<link rel="stylesheet" href="styles.css">
```

`styles.css` imports the Pretendard webfont (CDN) and `zcs/zcs.css` (all tokens + components). No build step, no React required — ZCS is a plain CSS class system.

## Files

| Path | What |
|---|---|
| `styles.css` | Single entry — link this. Imports font + `zcs/zcs.css`. |
| `zcs/zcs.css` | **Source of truth** — design tokens (CSS variables) + every component class. |
| `design-system.html` | **Reference** — live spec of every token and component (19 sections). Start here. |
| `zcs/scj-logo.js` | Brand-mark renderer — inlines the official signature/symbol into `.scj-sign` / `.scj-mark` hosts. |
| `zcs/brand/scj-signature.svg` | Official full-color horizontal signature artwork. |
| `zcs/_official/scj-mark-black.svg` | Official single-path 보좌 symbol (line-art) for the single-color variants. |

## Design tokens (`zcs/zcs.css` `:root`)

- **Surface / ink** — `--bg` `--surface` `--surface-2` `--ink` `--ink-2` `--ink-3` `--line` `--line-2`
- **Accent (cobalt, single)** — `--accent` `--accent-hover` `--accent-ink` `--accent-weak`
- **Status** — `--ok`/`--ok-bg` · `--warn`/`--warn-bg` · `--bad`/`--bad-bg` · `--neu`/`--neu-bg`
- **System** — `--radius` (6) · `--shadow` · `--shadow-overlay` · `--sans` (Pretendard) · `--mono`

The **12-tribe palette** is for tribe identification only (gems, chips, distribution bars) — never as a general accent.

## Components (CSS classes)

`btn` (`.primary`/`.sm`/`.ghost`/`.danger`) · `icon-btn` · `badge` (status) · `chip` · `gem` (`.s`/`.m`/`.l`) ·
`field` + `input` / `textarea` / `select` (incl. error/disabled) · `input-wrap` (lead/trail icon) · DateInput (`datepop`) ·
`ss` SearchSelect · `masked` MaskedValue · `check` (checkbox/radio) · `switch` toggle · `tabs`/`tab` ·
`alert` (inline banner) · `panel` · `stat-strip` · `bars` (horizontal) · `cols` (vertical) · `minibar` ·
`tbl` DataTable · `pager` Pagination · `dl` definition list · `modal` · `drawer` · `toast` · `spinner` ·
`emptystate` · `noperm` NoPermission · `pagetitle` · `filterbar` · `sidebar` / `topbar` shell · `login` (Zion Login QR auth).

See the reference page for live examples of each.

## Principles

1. **Compact density** — 13px body, 32px controls, 8px table rows. Surface data, not ornament.
2. **Tables & bars first** — sortable tables and horizontal bars over donuts/pies.
3. **Restrained color** — one cobalt accent; tribe colors for identification only.
4. **The member number is first-class** — 13-digit `00341130-00036` rendered fixed-width tabular, never wrapping.

## Platform model

Every administrative system composes the **same shell, tokens and components**. Menus and data differ per system; the design system does not.
