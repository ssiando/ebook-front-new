# Vendored ZCS — generated, do not edit

- Synced from: `/Users/mins/Workspace/zcs`
- Synced at: 2026-06-30T13:56:36.753Z
- Refresh with: `npm run sync:zcs`

These files are a byte-identical copy of the ZCS source. Never hand-edit them.
Template-local accessibility fixes for ZCS gaps (B1–B6) live in
`src/styles/zcs-a11y.css`, loaded after ZCS — see that file's header.
