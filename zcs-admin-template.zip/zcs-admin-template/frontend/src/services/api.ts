// API client. Attaches the Bearer app-token to every request; on any 401 the
// session is dead → drop the token and route to login (no retry). 403 surfaces as
// an ApiError the screens turn into the ZCS noperm state. See api_contracts.md.

const API_BASE_URL = import.meta.env.VITE_API_URL ?? "";
const TOKEN_KEY = "auth_token";
// Stash for the 401 reason so the login screen can show the right message.
const SESSION_END_KEY = "session_end_reason";

export type ErrorCode =
  | "UNAUTHORIZED"
  | "SESSION_REVOKED"
  | "SESSION_EXPIRED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "BAD_REQUEST"
  | "INTERNAL"
  | "NETWORK";

export class ApiError extends Error {
  code: ErrorCode;
  status: number;
  constructor(code: ErrorCode, message: string, status: number) {
    super(message);
    this.name = "ApiError";
    this.code = code;
    this.status = status;
  }
}

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken(): void {
  localStorage.removeItem(TOKEN_KEY);
}

export function takeSessionEndReason(): ErrorCode | null {
  const reason = sessionStorage.getItem(SESSION_END_KEY) as ErrorCode | null;
  sessionStorage.removeItem(SESSION_END_KEY);
  return reason;
}

async function parseError(res: Response): Promise<ApiError> {
  let code: ErrorCode = "INTERNAL";
  let message = "";
  try {
    const body = await res.json();
    if (body?.error?.code) code = body.error.code;
    if (body?.error?.message) message = body.error.message;
  } catch {
    // non-JSON error body — keep defaults
  }
  return new ApiError(code, message, res.status);
}

function handleDeadSession(err: ApiError): void {
  clearToken();
  sessionStorage.setItem(SESSION_END_KEY, err.code);
  if (!window.location.hash.startsWith("#/login")) {
    window.location.hash = "#/login";
  }
}

export async function fetchApi<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = getToken();
  let res: Response;
  try {
    res = await fetch(`${API_BASE_URL}${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...init.headers,
      },
    });
  } catch {
    throw new ApiError("NETWORK", "", 0);
  }

  if (res.status === 401) {
    const err = await parseError(res);
    handleDeadSession(err);
    throw err;
  }
  if (!res.ok) throw await parseError(res);

  if (res.status === 204) return undefined as T;
  const text = await res.text();
  return (text ? JSON.parse(text) : undefined) as T;
}

/** Start the Zion 로그인 flow — full-page redirect to the backend. */
export function startLogin(): void {
  window.location.href = `${API_BASE_URL}/api/auth/login`;
}
