import { ScjMark } from "./ScjMark";
import { NavTree } from "./NavTree";
import { LogoutButton } from "./LogoutButton";
import type { NavCtx, NavNode } from "../config/nav";
import { t } from "../i18n";

export function Sidebar({
  tree,
  ctx,
  open,
  onNavigate,
}: {
  tree: NavNode[];
  ctx: NavCtx;
  open: boolean;
  onNavigate: () => void;
}) {
  return (
    <aside className={`sidebar${open ? " is-open" : ""}`}>
      <div className="brand">
        <span className="brand-mark">
          <ScjMark />
        </span>
        <div>
          <div className="brand-name">{t("app.name")}</div>
          <div className="brand-sub">{t("app.brandSub")}</div>
        </div>
      </div>

      <nav className="nav" aria-label={t("shell.menu")}>
        <div className="nav-label">{t("shell.menu")}</div>
        <NavTree tree={tree} ctx={ctx} onNavigate={onNavigate} />
      </nav>

      {/* Footer is logout-only — identity (이름 + 역할) lives in the topbar (CR-02b). */}
      <div className="sidebar-foot">
        <LogoutButton />
      </div>
    </aside>
  );
}
