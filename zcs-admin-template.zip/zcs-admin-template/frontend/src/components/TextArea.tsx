import type { TextareaHTMLAttributes } from "react";

interface TextAreaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  invalid?: boolean;
  charCount?: { current: number; max: number };
}

export function TextArea({ invalid, charCount, className = "", id, ...rest }: TextAreaProps) {
  return (
    <>
      <textarea
        id={id}
        className={`textarea ${className}`.trim()}
        aria-invalid={invalid || undefined}
        aria-describedby={invalid && id ? `${id}-err` : undefined}
        {...rest}
      />
      {charCount && (
        <div className="char-count tnum">
          {charCount.current}/{charCount.max}
        </div>
      )}
    </>
  );
}
