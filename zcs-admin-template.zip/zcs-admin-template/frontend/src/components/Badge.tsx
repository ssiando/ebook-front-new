import type { ReactNode } from "react";

type Tone = "success" | "warning" | "danger" | "neutral" | "brand";

export function Badge({
  tone = "neutral",
  plain = false,
  children,
}: {
  tone?: Tone;
  plain?: boolean;
  children: ReactNode;
}) {
  return <span className={`badge ${tone}${plain ? " plain" : ""}`}>{children}</span>;
}
