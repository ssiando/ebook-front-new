import { IconMenu } from "./icons";
import { t } from "../i18n";

// Topbar control that opens the 내 정보 drawer (CR-02 #3). Replaces the old
// always-on 고유번호 chip + logout button.
export function HamburgerButton({ expanded, onClick }: { expanded: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      className="icon-btn"
      onClick={onClick}
      aria-label={t("myInfo.title")}
      aria-haspopup="dialog"
      aria-expanded={expanded}
    >
      <IconMenu width={18} height={18} />
    </button>
  );
}
