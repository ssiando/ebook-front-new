import { useEffect, useId, useRef, type ReactNode } from "react";
import { IconClose } from "./icons";
import { t } from "../i18n";

interface DrawerProps {
  open: boolean;
  title: string;
  sub?: string;
  onClose: () => void;
  children?: ReactNode;
  footer?: ReactNode;
}

export function Drawer({ open, title, sub, onClose, children, footer }: DrawerProps) {
  const restoreRef = useRef<HTMLElement | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const titleId = useId();

  useEffect(() => {
    if (!open) return;
    restoreRef.current = document.activeElement as HTMLElement | null;
    panelRef.current?.querySelector<HTMLElement>("button,a,input,textarea,select")?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey, true);
    return () => {
      document.removeEventListener("keydown", onKey, true);
      restoreRef.current?.focus?.();
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <>
      <div className="drawer-overlay" onMouseDown={onClose} />
      <div className="drawer" role="dialog" aria-modal="true" aria-labelledby={titleId} ref={panelRef}>
        <div className="drawer-head">
          <div>
            <div className="dt" id={titleId}>
              {title}
            </div>
            {sub && <div className="dsub">{sub}</div>}
          </div>
          <button type="button" className="dx" onClick={onClose} aria-label={t("common.close")}>
            <IconClose width={18} height={18} />
          </button>
        </div>
        <div className="drawer-body">{children}</div>
        {footer && <div className="drawer-foot">{footer}</div>}
      </div>
    </>
  );
}
