import { Spinner } from "./Spinner";
import { t } from "../i18n";

export function LoadBox({ label }: { label?: string }) {
  return (
    <div className="loadbox">
      <Spinner size="m" />
      <span>{label ?? t("common.loading")}</span>
    </div>
  );
}
