import { IconLogout } from "./icons";
import { useAuth } from "../context/AuthContext";
import { t } from "../i18n";

// Sidebar-footer logout (CR-02 #4). POST /api/auth/logout → login. Styled for the
// dark sidebar panel via .sidebar-logout (zcs-a11y.css).
export function LogoutButton() {
  const { logout } = useAuth();
  return (
    <button type="button" className="sidebar-logout" onClick={() => void logout()}>
      <IconLogout width={15} height={15} aria-hidden="true" />
      {t("shell.logout")}
    </button>
  );
}
