import { useEffect, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { IconChevron } from "./icons";
import type { NavCtx, NavNode } from "../config/nav";

// Recursive, config-driven sidebar nav (CR-02). Groups collapse/expand (persisted),
// auto-expand the active trail, and indent structurally via nested .nav-sub. No
// underlines — affordance is background + a left accent rail (see zcs-a11y.css B7).

function pathMatches(pathname: string, to: string): boolean {
  return pathname === to || pathname.startsWith(to + "/");
}

function hasActiveDescendant(node: NavNode, pathname: string): boolean {
  if (node.kind === "item") return pathMatches(pathname, node.to);
  return node.children.some((c) => hasActiveDescendant(c, pathname));
}

function visibleNodes(nodes: NavNode[], ctx: NavCtx): NavNode[] {
  return nodes.filter((n) => !n.visible || n.visible(ctx));
}

export function NavTree({ tree, ctx, onNavigate }: { tree: NavNode[]; ctx: NavCtx; onNavigate: () => void }) {
  const { pathname } = useLocation();
  return (
    <>
      {visibleNodes(tree, ctx).map((node) =>
        node.kind === "item" ? (
          <NavItem key={node.to} node={node} onNavigate={onNavigate} />
        ) : (
          <NavGroup key={node.label} node={node} ctx={ctx} pathname={pathname} onNavigate={onNavigate} />
        ),
      )}
    </>
  );
}

function NavItem({ node, onNavigate }: { node: Extract<NavNode, { kind: "item" }>; onNavigate: () => void }) {
  const Icon = node.icon;
  return (
    <NavLink
      to={node.to}
      end
      className={({ isActive }) => `nav-item${isActive ? " active" : ""}`}
      onClick={onNavigate}
    >
      {Icon && (
        <span className="ic" aria-hidden="true">
          <Icon width={15} height={15} />
        </span>
      )}
      {node.label}
    </NavLink>
  );
}

function NavGroup({
  node,
  ctx,
  pathname,
  onNavigate,
}: {
  node: Extract<NavNode, { kind: "group" }>;
  ctx: NavCtx;
  pathname: string;
  onNavigate: () => void;
}) {
  const Icon = node.icon;
  const activeTrail = node.children.some((c) => hasActiveDescendant(c, pathname));
  const storageKey = `nav.group.${node.label}`;

  const [open, setOpen] = useState<boolean>(() => {
    const saved = localStorage.getItem(storageKey);
    return saved !== null ? saved === "1" : activeTrail;
  });

  // Auto-expand when a descendant route becomes active.
  useEffect(() => {
    if (activeTrail) setOpen(true);
  }, [activeTrail]);

  const toggle = () => {
    setOpen((prev) => {
      const next = !prev;
      localStorage.setItem(storageKey, next ? "1" : "0");
      return next;
    });
  };

  return (
    <div className="nav-group">
      <button
        type="button"
        className={`nav-group-toggle${activeTrail ? " trail" : ""}`}
        aria-expanded={open}
        onClick={toggle}
      >
        {Icon && (
          <span className="ic" aria-hidden="true">
            <Icon width={15} height={15} />
          </span>
        )}
        <span className="nav-group-label">{node.label}</span>
        <span className={`nav-chev${open ? " open" : ""}`} aria-hidden="true">
          <IconChevron width={13} height={13} />
        </span>
      </button>
      {open && (
        <div className="nav-sub" role="group" aria-label={node.label}>
          {visibleNodes(node.children, ctx).map((child) =>
            child.kind === "item" ? (
              <NavItem key={child.to} node={child} onNavigate={onNavigate} />
            ) : (
              <NavGroup key={child.label} node={child} ctx={ctx} pathname={pathname} onNavigate={onNavigate} />
            ),
          )}
        </div>
      )}
    </div>
  );
}
