import { useState } from "react";
import QRCode from "qrcode";
import { Field } from "./Field";
import { TextField } from "./TextField";
import { Button } from "./Button";
import { Alert } from "./Alert";
import { Spinner } from "./Spinner";
import { IconLink, IconDownload, IconAlert } from "./icons";
import { issueQr } from "../hooks/qr";
import { useToast } from "./Toast";
import { t } from "../i18n";

type Status = "idle" | "loading" | "issued" | "error";

export function QrIssuePanel() {
  const toast = useToast();
  const [ref, setRef] = useState("");
  const [refErr, setRefErr] = useState<string | null>(null);
  const [status, setStatus] = useState<Status>("idle");
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  // Held only in memory for the copy/save actions of the current QR. Never logged.
  const [scanUrl, setScanUrl] = useState<string | null>(null);

  const generate = async () => {
    const trimmed = ref.trim();
    if (!trimmed) {
      setRefErr(t("qr.validateTarget"));
      return;
    }
    setRefErr(null);
    setStatus("loading");
    setQrDataUrl(null);
    try {
      const { scanUrl: url } = await issueQr(trimmed);
      const dataUrl = await QRCode.toDataURL(url, { width: 400, margin: 1 });
      setScanUrl(url);
      setQrDataUrl(dataUrl);
      setStatus("issued");
    } catch {
      setStatus("error");
    }
  };

  const saveImage = () => {
    if (!qrDataUrl) return;
    const a = document.createElement("a");
    a.href = qrDataUrl;
    a.download = `wao-qr-${ref.trim() || "code"}.png`;
    a.click();
  };

  const copyLink = async () => {
    if (!scanUrl) return;
    try {
      await navigator.clipboard.writeText(scanUrl);
      toast.success(t("qr.linkCopied"));
    } catch {
      toast.error(t("errors.generic"));
    }
  };

  return (
    <div className="panel">
      <div className="panel-head">
        <span className="panel-title">{t("qr.title")}</span>
      </div>
      <div className="panel-body">
        <div style={{ display: "flex", gap: 10, alignItems: "flex-end", flexWrap: "wrap" }}>
          <div style={{ flex: 1, minWidth: 220 }}>
            <Field label={t("qr.targetLabel")} htmlFor="qr-ref" required error={refErr ?? undefined}>
              <TextField
                id="qr-ref"
                value={ref}
                onChange={(e) => setRef(e.target.value)}
                placeholder={t("qr.targetPlaceholder")}
                invalid={Boolean(refErr)}
                autoComplete="off"
              />
            </Field>
          </div>
          <Button variant="primary" onClick={generate} loading={status === "loading"}>
            {t("qr.generate")}
          </Button>
        </div>

        <div style={{ marginTop: 18, display: "flex", gap: 18, flexWrap: "wrap", alignItems: "flex-start" }}>
          <div className="qr-card">
            {status === "loading" ? (
              <div className="qr-card-ph">
                <Spinner size="m" />
              </div>
            ) : qrDataUrl ? (
              <img src={qrDataUrl} alt={t("qr.title")} />
            ) : (
              <div className="qr-card-ph">{t("qr.idleHint")}</div>
            )}
            {status === "issued" && (
              <div className="qr-actions">
                <Button size="sm" leadingIcon={<IconDownload width={14} height={14} />} onClick={saveImage}>
                  {t("qr.saveImage")}
                </Button>
                <Button size="sm" leadingIcon={<IconLink width={14} height={14} />} onClick={copyLink}>
                  {t("qr.copyLink")}
                </Button>
              </div>
            )}
          </div>

          {status === "issued" && (
            <div style={{ flex: 1, minWidth: 240 }}>
              <Alert tone="warning">
                <b>{t("qr.caution.title")}</b>
                <ul style={{ margin: "6px 0 0", paddingLeft: 18, lineHeight: 1.7 }}>
                  <li>{t("qr.caution.line1")}</li>
                  <li>{t("qr.caution.line2")}</li>
                  <li>{t("qr.caution.line3")}</li>
                </ul>
              </Alert>
            </div>
          )}
        </div>

        {status === "error" && (
          <div style={{ marginTop: 16 }}>
            <Alert tone="danger" icon={<IconAlert />}>
              {t("qr.error")}{" "}
              <button className="btn sm" style={{ marginLeft: 8 }} onClick={generate}>
                {t("common.retry")}
              </button>
            </Alert>
          </div>
        )}
      </div>
    </div>
  );
}
