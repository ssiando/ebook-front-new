import type { ReactNode } from "react";

export function PageTitle({
  title,
  crumb,
  sub,
  count,
  actions,
}: {
  title: string;
  crumb?: ReactNode;
  sub?: string;
  count?: number;
  actions?: ReactNode;
}) {
  return (
    <div className="pagetitle">
      <div className="pt-main">
        {crumb && <div className="pt-crumb">{crumb}</div>}
        <h1 className="pt-title">
          {title}
          {count != null && (
            <span className="badge brand plain tnum">{count}</span>
          )}
        </h1>
        {sub && <div className="pt-sub">{sub}</div>}
      </div>
      {actions && <div className="pt-act">{actions}</div>}
    </div>
  );
}
