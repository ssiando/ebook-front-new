import { useMemo, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { Sidebar } from "./Sidebar";
import { Topbar } from "./Topbar";
import { MyInfoDrawer } from "./MyInfoDrawer";
import { DistributionMark } from "./DistributionMark";
import { buildNavTree, type NavCtx } from "../config/nav";
import { useAuth } from "../context/AuthContext";
import { t } from "../i18n";

// Route → page title + breadcrumb tail (QR kept for the unlinked reference route).
const ROUTE_META: Record<string, string> = {
  "/notices": "notices.title",
  "/access": "access.title",
  "/audit": "activity.title",
  "/sessions": "sessions.title",
  "/qr": "qr.title",
};

export function AppShell() {
  const { access } = useAuth();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [myInfoOpen, setMyInfoOpen] = useState(false);

  const ctx: NavCtx = {
    isSuper: access?.super ?? false,
    canManageAccess: access?.canManageAccess ?? false,
    hasAccess: access?.hasAccess ?? false,
  };
  const tree = useMemo(() => buildNavTree(), []);

  const titleKey = ROUTE_META[location.pathname];
  const title = titleKey ? t(titleKey) : t("app.name");
  const crumb = (
    <>
      {t("notices.crumbHome")} <b>›</b> <b>{title}</b>
    </>
  );

  return (
    <div className="app">
      <div
        className={`sidebar-backdrop${menuOpen ? " is-open" : ""}`}
        onClick={() => setMenuOpen(false)}
        aria-hidden="true"
      />
      <Sidebar tree={tree} ctx={ctx} open={menuOpen} onNavigate={() => setMenuOpen(false)} />
      <main className="main">
        <Topbar
          title={title}
          crumb={crumb}
          myInfoOpen={myInfoOpen}
          onOpenMyInfo={() => setMyInfoOpen(true)}
          onOpenMenu={() => setMenuOpen(true)}
        />
        <div className="content">
          <Outlet />
        </div>
        <DistributionMark />
      </main>
      <MyInfoDrawer open={myInfoOpen} onClose={() => setMyInfoOpen(false)} />
    </div>
  );
}
