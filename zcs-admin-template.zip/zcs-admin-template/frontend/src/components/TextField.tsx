import type { InputHTMLAttributes } from "react";

interface TextFieldProps extends InputHTMLAttributes<HTMLInputElement> {
  invalid?: boolean;
  mono?: boolean;
}

export function TextField({ invalid, mono, className = "", id, style, ...rest }: TextFieldProps) {
  return (
    <input
      id={id}
      className={`input ${mono ? "mono" : ""} ${className}`.trim()}
      style={{ width: "100%", ...style }}
      aria-invalid={invalid || undefined}
      aria-describedby={invalid && id ? `${id}-err` : undefined}
      {...rest}
    />
  );
}
