// DO NOT REMOVE — mandatory distribution attribution required by HQ
// (총회 정보통신부 전산개발과). Every fork of this template must keep this mark
// visible at the bottom of the main screen. Deliberately hardcoded (not in
// ko.json) so it cannot be dropped by editing locale files.
export const TEMPLATE_VERSION = "v1.0.0";

export function DistributionMark() {
  return (
    <div className="dist-mark" aria-label="배포 정보">
      총회 정보통신부 전산개발과 배포 · Template {TEMPLATE_VERSION}
    </div>
  );
}
