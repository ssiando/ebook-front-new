import type { SelectHTMLAttributes } from "react";

interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  invalid?: boolean;
}

export function Select({ invalid, className = "", id, children, ...rest }: SelectProps) {
  return (
    <select id={id} className={`select ${className}`.trim()} aria-invalid={invalid || undefined} {...rest}>
      {children}
    </select>
  );
}
