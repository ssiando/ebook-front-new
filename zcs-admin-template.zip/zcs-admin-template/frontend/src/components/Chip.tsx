import type { ReactNode } from "react";

export function Chip({ dotColor, children }: { dotColor?: string; children: ReactNode }) {
  return (
    <span className="chip">
      {dotColor && <span className="dot" style={{ background: dotColor }} />}
      {children}
    </span>
  );
}
