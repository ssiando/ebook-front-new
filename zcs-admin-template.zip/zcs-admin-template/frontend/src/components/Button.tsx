import type { ButtonHTMLAttributes, ReactNode } from "react";
import { Spinner } from "./Spinner";

type Variant = "default" | "primary" | "ghost" | "danger";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: "md" | "sm";
  leadingIcon?: ReactNode;
  loading?: boolean;
}

export function Button({
  variant = "default",
  size = "md",
  leadingIcon,
  loading = false,
  disabled,
  children,
  className = "",
  type = "button",
  ...rest
}: ButtonProps) {
  const variantClass = variant === "default" ? "" : variant;
  const sizeClass = size === "sm" ? "sm" : "";
  const cls = ["btn", variantClass, sizeClass, className].filter(Boolean).join(" ");
  return (
    <button type={type} className={cls} disabled={disabled || loading} {...rest}>
      {loading ? <Spinner size="s" /> : leadingIcon}
      {children}
    </button>
  );
}
