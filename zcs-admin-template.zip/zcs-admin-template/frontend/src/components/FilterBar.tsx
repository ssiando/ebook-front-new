import type { ReactNode } from "react";
import { IconSearch } from "./icons";

export function FilterBar({
  query,
  onQuery,
  placeholder,
  meta,
  children,
}: {
  query: string;
  onQuery: (v: string) => void;
  placeholder: string;
  meta?: ReactNode;
  children?: ReactNode;
}) {
  return (
    <div className="filterbar">
      <div className="filter-search grow">
        <IconSearch width={15} height={15} style={{ color: "var(--ink-3)", flex: "0 0 auto" }} />
        <input
          type="search"
          value={query}
          onChange={(e) => onQuery(e.target.value)}
          placeholder={placeholder}
          aria-label={placeholder}
          autoComplete="off"
        />
      </div>
      {children}
      {meta && <div className="filter-meta">{meta}</div>}
    </div>
  );
}
