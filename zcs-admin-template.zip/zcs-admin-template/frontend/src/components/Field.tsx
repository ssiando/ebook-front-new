import type { ReactNode } from "react";
import { IconAlert } from "./icons";

interface FieldProps {
  label: string;
  htmlFor?: string;
  required?: boolean;
  hint?: string;
  error?: string;
  children: ReactNode;
}

// Wraps a control with its label, hint and error. The error id is wired so the
// control can reference it via aria-describedby (see TextField/TextArea).
export function fieldErrorId(id: string | undefined): string | undefined {
  return id ? `${id}-err` : undefined;
}

export function Field({ label, htmlFor, required, hint, error, children }: FieldProps) {
  return (
    <div className={`field${error ? " error" : ""}`}>
      <label htmlFor={htmlFor}>
        {label}
        {required && (
          <span className="req" aria-hidden="true">
            *
          </span>
        )}
      </label>
      {children}
      {hint && !error && <div className="hint">{hint}</div>}
      {error && (
        <div className="err-msg" id={fieldErrorId(htmlFor)}>
          <IconAlert width={13} height={13} />
          {error}
        </div>
      )}
    </div>
  );
}
