import { useState } from "react";

// Masked-by-default value with reveal-on-click. Largely UNUSED in this template
// (고유번호 is a public working key shown in full; idNumber/주민번호 is never
// displayed). Kept so a fork adding a sensitive field (e.g. 연락처) has the correct
// masked + reveal-on-permission pattern ready.
export function MaskedValue({
  value,
  masked,
  revealLabel = "값 보기",
  hideLabel = "값 가리기",
}: {
  value: string;
  masked: string;
  revealLabel?: string;
  hideLabel?: string;
}) {
  const [shown, setShown] = useState(false);
  return (
    <span className="masked">
      <span className="mv">{shown ? value : masked}</span>
      <button
        type="button"
        className="mreveal"
        aria-label={shown ? hideLabel : revealLabel}
        aria-pressed={shown}
        title={shown ? hideLabel : revealLabel}
        onClick={() => setShown((s) => !s)}
      >
        {shown ? "○" : "●"}
      </button>
    </span>
  );
}
