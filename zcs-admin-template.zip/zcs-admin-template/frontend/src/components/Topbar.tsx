import type { ReactNode } from "react";
import { HamburgerButton } from "./HamburgerButton";
import { IconMenu } from "./icons";
import { useAuth } from "../context/AuthContext";
import { roleLabel } from "../lib/role";
import { t } from "../i18n";

// CR-02 #3: the old always-on 고유번호 chip + logout button are gone. The right
// cluster shows the current user's 이름 + 역할 ONCE (the only always-visible identity
// — the sidebar footer is logout-only) and a hamburger that opens the 내 정보 drawer.
// The left shell-hamburger toggles the off-canvas sidebar on narrow screens (B4).
export function Topbar({
  title,
  crumb,
  myInfoOpen,
  onOpenMyInfo,
  onOpenMenu,
}: {
  title: string;
  crumb?: ReactNode;
  myInfoOpen: boolean;
  onOpenMyInfo: () => void;
  onOpenMenu: () => void;
}) {
  const { user, access } = useAuth();

  return (
    <header className="topbar">
      <button type="button" className="icon-btn shell-hamburger" onClick={onOpenMenu} aria-label={t("shell.openMenu")}>
        <IconMenu width={18} height={18} />
      </button>

      <div>
        {crumb && <div className="crumb">{crumb}</div>}
        <div className="page-title">{title}</div>
      </div>

      <div className="topbar-spacer" />

      {user && access && (
        <>
          <span className="topbar-identity">
            <span className="ti-name">{user.name}</span>
            <span className="ti-role">{roleLabel(access)}</span>
          </span>
          <HamburgerButton expanded={myInfoOpen} onClick={onOpenMyInfo} />
        </>
      )}
    </header>
  );
}
