import { IconShield } from "./icons";
import { t } from "../i18n";

// ZCS noperm — the terminal state for a logged-in user without access (or a 403).
// Deliberately renders NO .np-code: a permission code is developer terminology
// (design B6 / house rule). Instead we show a plain-language hint with the user's
// own 고유번호 so they can request access for the right person.
export function NoPermission({ self }: { self?: { name: string; newNo: string } }) {
  return (
    <div className="noperm" role="region" aria-label={t("noperm.title")}>
      <div className="np-ic">
        <IconShield width={22} height={22} />
      </div>
      <div className="np-t">{t("noperm.title")}</div>
      <div className="np-d">
        {t("noperm.desc")}
        {self && (
          <>
            <br />
            {t("noperm.selfHint", { name: self.name, newNo: self.newNo })}
          </>
        )}
      </div>
    </div>
  );
}
