import type { ReactNode } from "react";

export interface DefItem {
  key: string;
  value: ReactNode;
}

export function DefinitionList({ items }: { items: DefItem[] }) {
  return (
    <dl className="dl">
      {items.map((item, i) => {
        const last = i === items.length - 1 ? " last" : "";
        return (
          <div style={{ display: "contents" }} key={item.key}>
            <dt className={`k${last}`}>{item.key}</dt>
            <dd className={`v${last}`}>{item.value}</dd>
          </div>
        );
      })}
    </dl>
  );
}
