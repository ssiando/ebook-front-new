import type { ReactNode } from "react";

// Input with a leading and/or trailing icon adornment (ZCS .input-wrap).
export function InputWrap({ lead, trail, children }: { lead?: ReactNode; trail?: ReactNode; children: ReactNode }) {
  const cls = ["input-wrap", lead ? "has-lead" : "", trail ? "has-trail" : ""].filter(Boolean).join(" ");
  return (
    <div className={cls}>
      {lead && <span className="lead">{lead}</span>}
      {children}
      {trail && <span className="trail">{trail}</span>}
    </div>
  );
}
