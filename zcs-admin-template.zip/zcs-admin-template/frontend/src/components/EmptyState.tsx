import type { ReactNode } from "react";
import { IconInbox } from "./icons";

export function EmptyState({
  icon,
  title,
  desc,
  action,
}: {
  icon?: ReactNode;
  title: string;
  desc?: string;
  action?: ReactNode;
}) {
  return (
    <div className="emptystate" role="region" aria-label={title}>
      <div className="es-ic">{icon ?? <IconInbox />}</div>
      <div className="es-t">{title}</div>
      {desc && <div className="es-d">{desc}</div>}
      {action && <div className="es-act">{action}</div>}
    </div>
  );
}
