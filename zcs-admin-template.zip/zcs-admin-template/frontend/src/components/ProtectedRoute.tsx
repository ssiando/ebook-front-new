import type { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { AppShell } from "./AppShell";
import { NoPermission } from "./NoPermission";
import { LoadBox } from "./LoadBox";

// Layout guard: requires a logged-in session, then renders the app shell.
// Server-side gating is the real defense (AC-5.3); these checks just keep
// unauthenticated users out of the chrome and route them to login.
export function AuthedLayout() {
  const { user, loading } = useAuth();
  if (loading)
    return (
      <div className="app-loading">
        <LoadBox />
      </div>
    );
  if (!user) return <Navigate to="/login" replace />;
  return <AppShell />;
}

type Need = "access" | "manage" | "super";

// Content gate: renders the page only when the session holds the required access,
// otherwise the ZCS noperm state (with the user's own 고유번호 to request access).
// A 403 from the API renders the same state inside each page (belt and suspenders).
export function Gate({ need, children }: { need: Need; children: ReactNode }) {
  const { user, access } = useAuth();
  const ok =
    need === "access"
      ? Boolean(access?.hasAccess)
      : need === "manage"
        ? Boolean(access?.super || access?.canManageAccess)
        : Boolean(access?.super);

  if (!ok) return <NoPermission self={user ? { name: user.name, newNo: user.newNo } : undefined} />;
  return <>{children}</>;
}
