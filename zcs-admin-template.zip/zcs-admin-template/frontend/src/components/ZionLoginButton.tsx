import { ScjMark } from "./ScjMark";
import { t } from "../i18n";

// The single credential entry point. No password / sign-up / reset / social UI —
// authentication is entirely the Zion platform's job. Never the word "ZAuth".
export function ZionLoginButton({ onClick, disabled }: { onClick: () => void; disabled?: boolean }) {
  return (
    <button type="button" className="btn-zion" onClick={onClick} disabled={disabled}>
      <ScjMark variant="neg" />
      {t("login.button")}
    </button>
  );
}
