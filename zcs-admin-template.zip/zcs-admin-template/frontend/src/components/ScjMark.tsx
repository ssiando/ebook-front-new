import { useEffect, useState } from "react";
import { getMarkSvg } from "../lib/scjMark";

// Host for the SCJ throne (보좌) symbol. We build the painted <svg> in React
// (lib/scjMark.ts) and set it ourselves, because the vendored scj-logo.js paints
// .scj-mark hosts via a MutationObserver — that imperative injection fights React
// and leaves the React-owned span empty. `variant` selects the single-color
// rendering (e.g. is-neg for white on dark); the mono fills use currentColor, which
// the is-* CSS class drives. Decorative by default (aria-hidden); pass `label` to
// expose it to assistive tech.
export function ScjMark({
  variant,
  label,
  className = "",
}: {
  variant?: "mono" | "dark" | "gold" | "silver" | "neg";
  label?: string;
  className?: string;
}) {
  const [html, setHtml] = useState("");
  const mono = variant != null;

  useEffect(() => {
    let alive = true;
    getMarkSvg(mono).then((svg) => {
      if (alive) setHtml(svg);
    });
    return () => {
      alive = false;
    };
  }, [mono]);

  const cls = ["scj-mark", variant ? `is-${variant}` : "", className].filter(Boolean).join(" ");

  // `html` is built only from static vendored SVG assets (lib/scjMark.ts), never
  // from user input — so this dangerouslySetInnerHTML carries no XSS exposure.
  return (
    <span
      className={cls}
      role={label ? "img" : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}
