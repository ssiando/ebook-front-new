export function Spinner({ size = "s" }: { size?: "s" | "m" | "l" }) {
  return <span className={`spinner ${size}`} role="status" aria-label="불러오는 중" />;
}
