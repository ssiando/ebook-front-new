import { tribeStyle } from "../lib/tribes";

// The ONLY tribe-colored element (ZCS rule). Renders the tribe's order number on
// its identification color. Returns null when the tribe is unknown/empty.
export function Gem({ tribe, size = "s" }: { tribe: string | null | undefined; size?: "s" | "m" | "l" }) {
  const style = tribeStyle(tribe);
  if (!style || style.order === 0) return null;
  return (
    <span
      className={`gem ${size}`}
      style={{ background: style.bg, color: style.fg }}
      aria-label={tribe ?? undefined}
      title={tribe ?? undefined}
    >
      {style.order}
    </span>
  );
}
