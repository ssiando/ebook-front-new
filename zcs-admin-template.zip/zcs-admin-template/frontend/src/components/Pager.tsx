import { IconChevronLeft, IconChevronRight } from "./icons";
import { t } from "../i18n";

export function Pager({
  page,
  pageSize,
  total,
  onPage,
}: {
  page: number;
  pageSize: number;
  total: number;
  onPage: (p: number) => void;
}) {
  const pageCount = Math.max(1, Math.ceil(total / pageSize));
  if (total === 0) return null;
  const from = (page - 1) * pageSize + 1;
  const to = Math.min(page * pageSize, total);

  const pages = Array.from({ length: pageCount }, (_, i) => i + 1);

  return (
    <div className="pager">
      <span className="info tnum">{t("common.pageRange", { from, to, total })}</span>
      {pageCount > 1 && (
        <div className="pages">
          <button
            className="pg"
            onClick={() => onPage(page - 1)}
            disabled={page <= 1}
            aria-label="이전 페이지"
          >
            <IconChevronLeft width={14} height={14} />
          </button>
          {pages.map((p) => (
            <button
              key={p}
              className={`pg${p === page ? " active" : ""}`}
              aria-current={p === page ? "page" : undefined}
              aria-label={`${p} 페이지`}
              onClick={() => onPage(p)}
            >
              {p}
            </button>
          ))}
          <button
            className="pg"
            onClick={() => onPage(page + 1)}
            disabled={page >= pageCount}
            aria-label="다음 페이지"
          >
            <IconChevronRight width={14} height={14} />
          </button>
        </div>
      )}
    </div>
  );
}
