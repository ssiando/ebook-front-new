import { useEffect, useState } from "react";
import { Drawer } from "./Drawer";
import { DefinitionList } from "./DefinitionList";
import { Gem } from "./Gem";
import { Alert } from "./Alert";
import { useAuth } from "../context/AuthContext";
import { roleLabel } from "../lib/role";
import { formatDateTime, relativePast, countdownLabel } from "../lib/format";
import { t } from "../i18n";

const DASH = "—";

// Read-only 내 정보 drawer (CR-02 #3). Own identity + live session info. No logout
// here (logout lives in the sidebar footer). No raw codes/ids, never 주민번호.
export function MyInfoDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { user, access, session } = useAuth();
  const [now, setNow] = useState(() => Date.now());

  // Tick the idle countdown once per second while the drawer is open.
  useEffect(() => {
    if (!open) return;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [open]);

  if (!user || !access) return null;

  const countdown = session ? countdownLabel(session.idleExpiresAt, now) : null;

  const identity = [
    { key: t("myInfo.name"), value: user.name },
    {
      key: t("common.newNoLabel"),
      value: (
        <span className="mono" aria-label={`${t("common.newNoLabel")} ${user.newNo}`}>
          {user.newNo}
        </span>
      ),
    },
    {
      key: t("myInfo.tribe"),
      value: user.tribe ? (
        <>
          <Gem tribe={user.tribe} size="s" />
          {user.tribe}
        </>
      ) : (
        DASH
      ),
    },
    { key: t("myInfo.church"), value: user.church || DASH },
    { key: t("myInfo.duty"), value: user.duty || DASH },
    { key: t("myInfo.role"), value: roleLabel(access) },
  ];

  const sessionItems = session
    ? [
        { key: t("myInfo.loginAt"), value: <span className="tnum">{formatDateTime(session.createdAt)}</span> },
        { key: t("myInfo.lastSeen"), value: <span className="tnum">{relativePast(session.lastSeenAt, now)}</span> },
        {
          key: t("myInfo.autoLogout"),
          value: <span className="tnum">{countdown?.text ?? DASH}</span>,
        },
      ]
    : [];

  return (
    <Drawer open={open} title={t("myInfo.title")} onClose={onClose}>
      <div className="overline" style={{ marginBottom: 8 }}>
        {t("myInfo.identity")}
      </div>
      <DefinitionList items={identity} />

      {session && (
        <>
          <div className="overline" style={{ margin: "20px 0 8px" }}>
            {t("myInfo.session")}
          </div>
          <DefinitionList items={sessionItems} />
          {countdown?.warn && (
            <div style={{ marginTop: 12 }}>
              <Alert tone="warning">{t("myInfo.autoLogoutWarn")}</Alert>
            </div>
          )}
        </>
      )}
    </Drawer>
  );
}
