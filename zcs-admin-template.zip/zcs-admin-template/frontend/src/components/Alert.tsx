import type { ReactNode } from "react";
import { IconAlert } from "./icons";

type Tone = "info" | "success" | "warning" | "danger";

export function Alert({ tone = "info", icon, children }: { tone?: Tone; icon?: ReactNode; children: ReactNode }) {
  return (
    <div className={`alert ${tone}`} role={tone === "danger" ? "alert" : undefined}>
      <span className="ai">{icon ?? <IconAlert />}</span>
      <div className="amsg">{children}</div>
    </div>
  );
}
