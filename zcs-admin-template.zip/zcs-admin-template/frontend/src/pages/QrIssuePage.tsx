import { PageTitle } from "../components/PageTitle";
import { QrIssuePanel } from "../components/QrIssuePanel";
import { t } from "../i18n";

export function QrIssuePage() {
  return (
    <>
      <PageTitle title={t("qr.title")} />
      <QrIssuePanel />
    </>
  );
}
