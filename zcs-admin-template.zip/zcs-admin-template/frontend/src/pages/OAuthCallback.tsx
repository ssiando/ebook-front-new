import { useEffect } from "react";
import { setToken } from "../services/api";
import { Spinner } from "../components/Spinner";
import { t } from "../i18n";

// The backend redirects here as `#/auth/callback?token=<appToken>` on success.
// We store the token and hard-reload into the app so AuthProvider loads /me fresh.
export function OAuthCallback() {
  useEffect(() => {
    const query = new URLSearchParams(window.location.hash.split("?")[1] ?? "");
    const token = query.get("token");
    if (token) {
      setToken(token);
      window.location.replace(`${window.location.pathname}#/`);
      window.location.reload();
    } else {
      window.location.replace(`${window.location.pathname}#/login?error=oauth_failed`);
    }
  }, []);

  return (
    <div className="app-loading">
      <div style={{ display: "flex", alignItems: "center", gap: 10, color: "var(--ink-2)" }}>
        <Spinner size="m" />
        {t("login.redirecting")}
      </div>
    </div>
  );
}
