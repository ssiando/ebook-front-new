import { useState } from "react";
import { Field } from "../components/Field";
import { TextField } from "../components/TextField";
import { Button } from "../components/Button";
import { fetchApi } from "../services/api";
import { t } from "../i18n";

// DEV-ONLY. Mints a real session via POST /api/auth/test-login (backend enables it
// when DEV_BYPASS_AUTH=true) so the template runs locally before 총회 registration.
// This whole panel is tree-shaken out of production builds (import.meta.env.DEV).
export function DevLoginPanel({ onLogin }: { onLogin: (token: string) => void }) {
  // Obviously-fake sample — never seed a realistic-looking 고유번호 (P-8) so it
  // can't be copied into docs/screenshots as if it were real.
  const [newNo, setNewNo] = useState("00000000-00000");
  const [name, setName] = useState("홍길동");
  const [asSuper, setAsSuper] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async () => {
    setBusy(true);
    setError(null);
    try {
      const res = await fetchApi<{ token: string }>("/api/auth/test-login", {
        method: "POST",
        body: JSON.stringify({ newNo, name, super: asSuper }),
      });
      onLogin(res.token);
    } catch {
      setError(t("login.devUnavailable"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      style={{
        marginTop: 18,
        paddingTop: 15,
        borderTop: "1px dashed var(--line-2)",
        display: "flex",
        flexDirection: "column",
        gap: 12,
      }}
    >
      <div>
        <div style={{ fontSize: 12, fontWeight: 700, color: "var(--ink-2)" }}>{t("login.devTitle")}</div>
        <div style={{ fontSize: 11, color: "var(--ink-2)", marginTop: 3, lineHeight: 1.5 }}>{t("login.devHint")}</div>
      </div>
      <Field label={t("login.devNewNo")} htmlFor="dev-newno">
        <TextField id="dev-newno" mono value={newNo} onChange={(e) => setNewNo(e.target.value)} autoComplete="off" />
      </Field>
      <Field label={t("login.devName")} htmlFor="dev-name">
        <TextField id="dev-name" value={name} onChange={(e) => setName(e.target.value)} autoComplete="off" />
      </Field>
      <label className={`check${asSuper ? " checked" : ""}`}>
        <input
          type="checkbox"
          checked={asSuper}
          onChange={(e) => setAsSuper(e.target.checked)}
          style={{ position: "absolute", opacity: 0 }}
        />
        <span className="box" aria-hidden="true">
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
            <path d="m5 12 5 5L20 6" />
          </svg>
        </span>
        {t("login.devSuper")}
      </label>
      {error && (
        <div className="err-msg" role="alert">
          {error}
        </div>
      )}
      <Button variant="primary" onClick={submit} loading={busy}>
        {t("login.devSubmit")}
      </Button>
    </div>
  );
}
