import { useState } from "react";
import { PageTitle } from "../components/PageTitle";
import { DataTable, type Column } from "../components/DataTable";
import { Pager } from "../components/Pager";
import { Badge } from "../components/Badge";
import { Alert } from "../components/Alert";
import { EmptyState } from "../components/EmptyState";
import { NoPermission } from "../components/NoPermission";
import { Field } from "../components/Field";
import { Select } from "../components/Select";
import { useActivity } from "../hooks/activity";
import { useAuth } from "../context/AuthContext";
import { actionLabel, actionTone, ACTION_ORDER } from "../lib/activity";
import type { ActivityEntry } from "../types/api";
import { formatDateTime } from "../lib/format";
import { t, tNode } from "../i18n";

const PAGE_SIZE = 50;

// Renders the audit target without ever showing a raw id/code in copy. Notice ids
// are plain ints (safe); 고유번호 is the audit's purpose (shown in full); session
// targets are opaque → shown generically (P-6).
function targetCell(e: ActivityEntry) {
  if (e.action === "GRANT" || e.action === "REVOKE") {
    return e.target ? (
      <span className="mono" aria-label={`${t("common.newNoLabel")} ${e.target}`}>
        {e.target}
      </span>
    ) : (
      "—"
    );
  }
  if (e.action === "NOTICE_CREATE" || e.action === "NOTICE_UPDATE" || e.action === "NOTICE_DELETE") {
    return e.target ? t("activity.targetNotice", { id: e.target }) : "—";
  }
  if (e.action === "SESSION_REVOKE") return t("activity.targetSession");
  return "—";
}

export function ActivityLogPage() {
  const { user } = useAuth();
  const [action, setAction] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [page, setPage] = useState(1);

  const { data, loading, error, reload } = useActivity({
    action,
    from,
    to,
    limit: PAGE_SIZE,
    offset: (page - 1) * PAGE_SIZE,
  });

  if (error?.code === "FORBIDDEN") {
    return <NoPermission self={user ? { name: user.name, newNo: user.newNo } : undefined} />;
  }

  const items = data?.items ?? [];
  const total = data?.total ?? 0;

  const resetTo1 = <T,>(setter: (v: T) => void) => (v: T) => {
    setter(v);
    setPage(1);
  };

  const columns: Column<ActivityEntry>[] = [
    { key: "createdAt", header: t("activity.col.createdAt"), render: (e) => <span className="tnum">{formatDateTime(e.createdAt)}</span> },
    {
      key: "actor",
      header: t("activity.col.actor"),
      render: (e) => (
        <span className="mono" aria-label={`${t("common.newNoLabel")} ${e.actorNo}`}>
          {e.actorNo}
        </span>
      ),
    },
    { key: "action", header: t("activity.col.action"), render: (e) => <Badge tone={actionTone(e.action)}>{actionLabel(e.action)}</Badge> },
    { key: "target", header: t("activity.col.target"), render: targetCell },
  ];

  return (
    <>
      <PageTitle title={t("activity.title")} sub={t("activity.desc")} />

      <div className="panel">
        <div className="filterbar">
          <Field label={t("activity.filter.action")} htmlFor="act-filter">
            <Select id="act-filter" value={action} onChange={(e) => resetTo1(setAction)(e.target.value)}>
              <option value="">{t("activity.filter.allActions")}</option>
              {ACTION_ORDER.map((a) => (
                <option key={a} value={a}>
                  {actionLabel(a)}
                </option>
              ))}
            </Select>
          </Field>
          <Field label={t("activity.filter.from")} htmlFor="act-from">
            <input id="act-from" type="date" className="input" value={from} max={to || undefined} onChange={(e) => resetTo1(setFrom)(e.target.value)} />
          </Field>
          <Field label={t("activity.filter.to")} htmlFor="act-to">
            <input id="act-to" type="date" className="input" value={to} min={from || undefined} onChange={(e) => resetTo1(setTo)(e.target.value)} />
          </Field>
          <div className="filter-meta">{tNode("common.countItems", "count", <b className="tnum">{total}</b>)}</div>
        </div>

        {error ? (
          <div style={{ padding: 16 }}>
            <Alert tone="danger">
              {t("activity.error")}{" "}
              <button className="btn sm" style={{ marginLeft: 8 }} onClick={reload}>
                {t("common.retry")}
              </button>
            </Alert>
          </div>
        ) : (
          <DataTable
            columns={columns}
            rows={items}
            rowKey={(e) => e.id}
            loading={loading}
            empty={<EmptyState title={t("activity.empty.title")} desc={t("activity.empty.desc")} />}
          />
        )}
        {!loading && !error && <Pager page={page} pageSize={PAGE_SIZE} total={total} onPage={setPage} />}
      </div>
    </>
  );
}
