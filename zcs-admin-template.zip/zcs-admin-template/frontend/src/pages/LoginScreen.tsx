import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ZionLoginButton } from "../components/ZionLoginButton";
import { ScjMark } from "../components/ScjMark";
import { DistributionMark } from "../components/DistributionMark";
import { Alert } from "../components/Alert";
import { startLogin, takeSessionEndReason, setToken, type ErrorCode } from "../services/api";
import { t } from "../i18n";
import { DevLoginPanel } from "./DevLoginPanel";

type Status = "idle" | "redirecting" | "error";

function reasonMessage(code: ErrorCode | null, queryError: string | null): string | null {
  if (code === "SESSION_EXPIRED") return t("session.expired");
  if (code === "SESSION_REVOKED") return t("session.revoked");
  if (queryError) return t("login.error");
  return null;
}

export function LoginScreen() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    const query = new URLSearchParams(window.location.hash.split("?")[1] ?? "");
    const msg = reasonMessage(takeSessionEndReason(), query.get("error"));
    if (msg) {
      setStatus("error");
      setMessage(msg);
    }
  }, []);

  const onLogin = () => {
    setStatus("redirecting");
    startLogin();
  };

  const onDevLogin = (token: string) => {
    setToken(token);
    navigate("/");
    // Reload so AuthProvider re-reads /me with the new token.
    window.location.reload();
  };

  return (
    <div className="login">
      <div className="login-brand">
        <div className="lb-top">
          {/* .brand-mark is a white badge — the neg (white) variant vanishes on it. */}
          <span className="brand-mark">
            <ScjMark />
          </span>
          <div>
            <div className="lb-tt-kr">{t("login.brandTitleKr")}</div>
            <div className="lb-tt-en">{t("login.brandTitleEn")}</div>
          </div>
        </div>
        <div className="lb-bg glow" />
        <div className="lb-bg mark">
          <ScjMark variant="neg" />
        </div>
        <div className="lb-foot">
          <div className="lb-dept">{t("app.name")}</div>
          <div className="lb-sys">
            <span>{t("app.systemLabel")}</span>
          </div>
        </div>
      </div>

      <div className="login-main">
        <div className="login-card">
          <span className="brand-mark" style={{ width: 40, height: 40 }}>
            <ScjMark />
          </span>
          <h1>{t("login.heading")}</h1>

          {status === "redirecting" ? (
            <div className="oauth-redirect">
              <div className="oauth-hop">
                <div className="oauth-node">
                  <ScjMark />
                </div>
                <div className="oauth-dots">
                  <i />
                  <i />
                  <i />
                </div>
                <div className="oauth-node dark">
                  <ScjMark variant="neg" />
                </div>
              </div>
              <div className="oauth-t">{t("login.redirecting")}</div>
              <div className="oauth-bar">
                <i />
              </div>
            </div>
          ) : (
            <>
              {status === "error" && message && (
                <div className="login-start" style={{ marginBottom: 0 }}>
                  <Alert tone="danger">{message}</Alert>
                </div>
              )}
              <div className="login-start">
                <ZionLoginButton onClick={onLogin} />
              </div>
              <div className="login-foot">{t("login.foot")}</div>
              {import.meta.env.DEV && <DevLoginPanel onLogin={onDevLogin} />}
            </>
          )}
        </div>
        <DistributionMark />
      </div>
    </div>
  );
}
