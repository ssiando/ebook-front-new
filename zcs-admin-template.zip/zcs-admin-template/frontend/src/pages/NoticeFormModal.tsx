import { useState } from "react";
import { Modal } from "../components/Modal";
import { Field } from "../components/Field";
import { TextField } from "../components/TextField";
import { TextArea } from "../components/TextArea";
import { Button } from "../components/Button";
import { IconInbox } from "../components/icons";
import { createNotice, updateNotice } from "../hooks/notices";
import type { Notice } from "../types/api";
import { useToast } from "../components/Toast";
import { t } from "../i18n";

const BODY_MAX = 2000;

export function NoticeFormModal({
  open,
  notice,
  onClose,
  onSaved,
}: {
  open: boolean;
  notice: Notice | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [title, setTitle] = useState(notice?.title ?? "");
  const [body, setBody] = useState(notice?.body ?? "");
  const [titleErr, setTitleErr] = useState<string | null>(null);
  const [bodyErr, setBodyErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const isEdit = Boolean(notice);

  const submit = async () => {
    const tErr = title.trim() ? null : t("notices.validate.titleRequired");
    const bErr = body.trim() ? null : t("notices.validate.bodyRequired");
    setTitleErr(tErr);
    setBodyErr(bErr);
    if (tErr || bErr) {
      document.getElementById(tErr ? "notice-title" : "notice-body")?.focus();
      return;
    }

    setBusy(true);
    try {
      if (notice) {
        await updateNotice(notice.id, { title: title.trim(), body: body.trim() });
        toast.success(t("notices.toast.updated"));
      } else {
        await createNotice({ title: title.trim(), body: body.trim() });
        toast.success(t("notices.toast.created"));
      }
      onSaved();
      onClose();
    } catch {
      toast.error(t("errors.generic"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      open={open}
      title={isEdit ? t("notices.edit") : t("notices.create")}
      icon={<IconInbox width={18} height={18} />}
      onClose={onClose}
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={busy}>
            {t("common.cancel")}
          </Button>
          <Button variant="primary" onClick={submit} loading={busy}>
            {t("common.save")}
          </Button>
        </>
      }
    >
      <div className="form-stack">
        <Field label={t("notices.field.title")} htmlFor="notice-title" required error={titleErr ?? undefined}>
          <TextField
            id="notice-title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={t("notices.placeholder.title")}
            invalid={Boolean(titleErr)}
            maxLength={200}
            autoComplete="off"
          />
        </Field>
        <Field label={t("notices.field.body")} htmlFor="notice-body" required error={bodyErr ?? undefined}>
          <TextArea
            id="notice-body"
            value={body}
            onChange={(e) => setBody(e.target.value.slice(0, BODY_MAX))}
            placeholder={t("notices.placeholder.body")}
            invalid={Boolean(bodyErr)}
            rows={6}
            charCount={{ current: body.length, max: BODY_MAX }}
          />
        </Field>
      </div>
    </Modal>
  );
}
