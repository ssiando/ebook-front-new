import { useEffect, useMemo, useState } from "react";
import { PageTitle } from "../components/PageTitle";
import { FilterBar } from "../components/FilterBar";
import { DataTable, type Column } from "../components/DataTable";
import { Pager } from "../components/Pager";
import { Button } from "../components/Button";
import { Badge } from "../components/Badge";
import { Alert } from "../components/Alert";
import { EmptyState } from "../components/EmptyState";
import { NoPermission } from "../components/NoPermission";
import { ConfirmModal } from "../components/ConfirmModal";
import { useList } from "../hooks/useList";
import { revokeSession } from "../hooks/sessions";
import { useToast } from "../components/Toast";
import { useAuth } from "../context/AuthContext";
import { clearToken } from "../services/api";
import type { SessionInfo } from "../types/api";
import { formatDateTime, relativePast, untilExpiry } from "../lib/format";
import { t, tNode } from "../i18n";

const PAGE_SIZE = 10;

export function SessionsPage() {
  const { user } = useAuth();
  const toast = useToast();
  const { items, loading, error, reload } = useList<SessionInfo>("/api/sessions");

  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [revoking, setRevoking] = useState<SessionInfo | null>(null);
  const [now, setNow] = useState(() => Date.now());

  // Keep the relative-time / idle columns fresh.
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 30_000);
    return () => window.clearInterval(id);
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return items;
    return items.filter((s) => s.newNo.toLowerCase().includes(q) || (s.name ?? "").toLowerCase().includes(q));
  }, [items, query]);

  const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  if (error?.code === "FORBIDDEN") {
    return <NoPermission self={user ? { name: user.name, newNo: user.newNo } : undefined} />;
  }

  const confirmRevoke = async () => {
    if (!revoking) return;
    const wasCurrent = revoking.isCurrent;
    try {
      await revokeSession(revoking.id);
      setRevoking(null);
      if (wasCurrent) {
        // Revoking your own session logs you out — drop the token and go to login.
        clearToken();
        window.location.hash = "#/login";
        return;
      }
      toast.success(t("sessions.toast.revoked"));
      reload();
    } catch {
      toast.error(t("errors.generic"));
    }
  };

  const columns: Column<SessionInfo>[] = [
    {
      key: "user",
      header: t("sessions.col.user"),
      render: (s) => (
        <span style={{ display: "inline-flex", gap: 8, alignItems: "center" }}>
          <span style={{ fontWeight: 600, color: "var(--ink)" }}>{s.name || t("sessions.unknownName")}</span>
          <span className="mono" style={{ color: "var(--ink-2)" }}>
            {s.newNo}
          </span>
        </span>
      ),
    },
    { key: "loginAt", header: t("sessions.col.loginAt"), render: (s) => <span className="tnum">{formatDateTime(s.loginAt)}</span> },
    { key: "lastSeen", header: t("sessions.col.lastSeen"), render: (s) => <span className="tnum">{relativePast(s.lastSeenAt, now)}</span> },
    {
      key: "idle",
      header: t("sessions.col.idle"),
      render: (s) => {
        const exp = untilExpiry(s.idleExpiresAt, now);
        return exp.imminent ? <Badge tone="warning">{exp.text}</Badge> : <span className="tnum">{exp.text}</span>;
      },
    },
    {
      key: "action",
      header: t("sessions.col.action"),
      render: (s) => (
        <span style={{ display: "inline-flex", gap: 8, alignItems: "center" }}>
          {s.isCurrent && <Badge tone="brand">{t("sessions.current")}</Badge>}
          <Button size="sm" variant="danger" onClick={() => setRevoking(s)}>
            {t("sessions.revoke")}
          </Button>
        </span>
      ),
    },
  ];

  return (
    <>
      <PageTitle title={t("sessions.title")} sub={t("sessions.desc")} />

      <div className="panel">
        <FilterBar
          query={query}
          onQuery={(v) => {
            setQuery(v);
            setPage(1);
          }}
          placeholder={t("sessions.searchPlaceholder")}
          meta={<span>{tNode("sessions.count", "count", <b className="tnum">{filtered.length}</b>)}</span>}
        />
        {error ? (
          <div style={{ padding: 16 }}>
            <Alert tone="danger">
              {t("sessions.error")}{" "}
              <button className="btn sm" style={{ marginLeft: 8 }} onClick={reload}>
                {t("common.retry")}
              </button>
            </Alert>
          </div>
        ) : (
          <DataTable
            columns={columns}
            rows={paged}
            rowKey={(s) => s.id}
            loading={loading}
            empty={<EmptyState title={t("sessions.empty.title")} desc={t("sessions.empty.desc")} />}
          />
        )}
        {!loading && !error && <Pager page={page} pageSize={PAGE_SIZE} total={filtered.length} onPage={setPage} />}
      </div>

      <ConfirmModal
        open={Boolean(revoking)}
        title={t("sessions.revokeModal.title")}
        message={revoking?.isCurrent ? t("sessions.revokeModal.descSelf") : t("sessions.revokeModal.desc")}
        confirmLabel={t("sessions.revoke")}
        onConfirm={confirmRevoke}
        onClose={() => setRevoking(null)}
      />
    </>
  );
}
