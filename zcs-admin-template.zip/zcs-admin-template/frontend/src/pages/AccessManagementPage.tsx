import { useMemo, useState } from "react";
import { PageTitle } from "../components/PageTitle";
import { FilterBar } from "../components/FilterBar";
import { DataTable, type Column } from "../components/DataTable";
import { Pager } from "../components/Pager";
import { Button } from "../components/Button";
import { Badge } from "../components/Badge";
import { Alert } from "../components/Alert";
import { EmptyState } from "../components/EmptyState";
import { NoPermission } from "../components/NoPermission";
import { ConfirmModal } from "../components/ConfirmModal";
import { IconPlus } from "../components/icons";
import { AccessAddModal } from "./AccessAddModal";
import { useList } from "../hooks/useList";
import { revokeGrant } from "../hooks/access";
import { useToast } from "../components/Toast";
import { useAuth } from "../context/AuthContext";
import type { Grant } from "../types/api";
import { formatDate } from "../lib/format";
import { t, tNode } from "../i18n";

const PAGE_SIZE = 10;

export function AccessManagementPage() {
  const { user, access } = useAuth();
  const toast = useToast();
  const { items, loading, error, reload } = useList<Grant>("/api/access/grants");

  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [addOpen, setAddOpen] = useState(false);
  const [revoking, setRevoking] = useState<Grant | null>(null);

  const isSuper = access?.super ?? false;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return items;
    return items.filter((g) => g.newNo.toLowerCase().includes(q) || (g.name ?? "").toLowerCase().includes(q));
  }, [items, query]);

  const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  if (error?.code === "FORBIDDEN") {
    return <NoPermission self={user ? { name: user.name, newNo: user.newNo } : undefined} />;
  }

  const confirmRevoke = async () => {
    if (!revoking) return;
    try {
      await revokeGrant(revoking.id);
      toast.success(t("access.toast.revoked"));
      setRevoking(null);
      reload();
    } catch {
      toast.error(t("errors.generic"));
    }
  };

  const roleCell = (g: Grant) => (
    <span style={{ display: "inline-flex", gap: 6, alignItems: "center" }}>
      <Badge tone="brand">{t("access.addModal.roleStaff")}</Badge>
      {g.canManageAccess && (
        <Badge tone="neutral" plain>
          {t("access.delegateBadge")}
        </Badge>
      )}
    </span>
  );

  const nameCell = (g: Grant) => {
    if (g.name) return <span style={{ fontWeight: 600, color: "var(--ink)" }}>{g.name}</span>;
    if (!g.confirmed) return <Badge tone="warning">{t("access.nameUnconfirmed")}</Badge>;
    return <Badge tone="neutral">{t("access.confirmed")}</Badge>;
  };

  const columns: Column<Grant>[] = [
    { key: "newNo", header: t("access.col.newNo"), render: (g) => <span className="mono">{g.newNo}</span> },
    { key: "name", header: t("access.col.name"), render: nameCell },
    { key: "role", header: t("access.col.role"), render: roleCell },
    {
      key: "grantedAt",
      header: t("access.col.grantedAt"),
      render: (g) => <span className="tnum">{formatDate(g.grantedAt)}</span>,
    },
    {
      key: "action",
      header: t("access.col.action"),
      render: (g) => (
        <Button size="sm" variant="ghost" onClick={() => setRevoking(g)}>
          {t("access.revoke")}
        </Button>
      ),
    },
  ];

  return (
    <>
      <PageTitle
        title={t("access.title")}
        sub={t("access.desc")}
        actions={
          <Button variant="primary" leadingIcon={<IconPlus width={14} height={14} />} onClick={() => setAddOpen(true)}>
            {t("access.add")}
          </Button>
        }
      />

      <div className="panel">
        <FilterBar
          query={query}
          onQuery={(v) => {
            setQuery(v);
            setPage(1);
          }}
          placeholder={t("access.searchPlaceholder")}
          meta={<span>{tNode("common.countPeople", "count", <b className="tnum">{filtered.length}</b>)}</span>}
        />
        {error ? (
          <div style={{ padding: 16 }}>
            <Alert tone="danger">
              {t("access.error")}{" "}
              <button className="btn sm" style={{ marginLeft: 8 }} onClick={reload}>
                {t("common.retry")}
              </button>
            </Alert>
          </div>
        ) : (
          <DataTable
            columns={columns}
            rows={paged}
            rowKey={(g) => g.id}
            loading={loading}
            empty={
              <EmptyState
                title={t("access.empty.title")}
                desc={t("access.empty.desc")}
                action={
                  <Button variant="primary" leadingIcon={<IconPlus width={14} height={14} />} onClick={() => setAddOpen(true)}>
                    {t("access.add")}
                  </Button>
                }
              />
            }
          />
        )}
        {!loading && !error && <Pager page={page} pageSize={PAGE_SIZE} total={filtered.length} onPage={setPage} />}
      </div>

      <AccessAddModal open={addOpen} canSetDelegate={isSuper} onClose={() => setAddOpen(false)} onSaved={reload} />

      <ConfirmModal
        open={Boolean(revoking)}
        title={t("access.revokeModal.title")}
        message={
          revoking?.name
            ? t("access.revokeModal.desc", { name: revoking.name })
            : t("access.revokeModal.descNoName", { newNo: revoking?.newNo ?? "" })
        }
        confirmLabel={t("access.revokeModal.confirm")}
        onConfirm={confirmRevoke}
        onClose={() => setRevoking(null)}
      />
    </>
  );
}
