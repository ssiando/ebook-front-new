import { Drawer } from "../components/Drawer";
import { DefinitionList } from "../components/DefinitionList";
import { Button } from "../components/Button";
import type { Notice } from "../types/api";
import { formatDateTime } from "../lib/format";
import { t } from "../i18n";

// Notice detail. Shows authorName ONLY — the contract returns no author 고유번호
// (privacy P-3: the author's number is never broadcast to staff).
export function NoticeDetail({
  notice,
  onClose,
  onEdit,
  onDelete,
}: {
  notice: Notice | null;
  onClose: () => void;
  onEdit: (notice: Notice) => void;
  onDelete: (notice: Notice) => void;
}) {
  return (
    <Drawer
      open={Boolean(notice)}
      title={notice?.title ?? ""}
      onClose={onClose}
      footer={
        notice && (
          <>
            <Button variant="danger" onClick={() => onDelete(notice)}>
              {t("notices.delete.confirm")}
            </Button>
            <Button variant="primary" onClick={() => onEdit(notice)}>
              {t("notices.edit")}
            </Button>
          </>
        )
      }
    >
      {notice && (
        <>
          <DefinitionList
            items={[
              { key: t("notices.detail.author"), value: notice.authorName },
              { key: t("notices.detail.createdAt"), value: formatDateTime(notice.createdAt) },
            ]}
          />
          <div style={{ marginTop: 16 }}>
            <div className="overline" style={{ marginBottom: 6 }}>
              {t("notices.detail.body")}
            </div>
            <div style={{ fontSize: 12.5, color: "var(--ink)", lineHeight: 1.7, whiteSpace: "pre-wrap" }}>
              {notice.body}
            </div>
          </div>
        </>
      )}
    </Drawer>
  );
}
