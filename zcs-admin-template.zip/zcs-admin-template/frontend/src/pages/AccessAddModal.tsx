import { useState } from "react";
import { Modal } from "../components/Modal";
import { Field } from "../components/Field";
import { TextField } from "../components/TextField";
import { Button } from "../components/Button";
import { IconUsers } from "../components/icons";
import { upsertGrant } from "../hooks/access";
import { useToast } from "../components/Toast";
import { t } from "../i18n";

const NEWNO_RE = /^\d{8}-\d{5}$/;

// `canSetDelegate` is true only for super-admins — the escalation rule says a
// delegate cannot mint new delegates (the backend also enforces this with 403).
export function AccessAddModal({
  open,
  canSetDelegate,
  onClose,
  onSaved,
}: {
  open: boolean;
  canSetDelegate: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const toast = useToast();
  const [newNo, setNewNo] = useState("");
  const [delegate, setDelegate] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!NEWNO_RE.test(newNo.trim())) {
      setErr(t("access.addModal.validateFormat"));
      document.getElementById("grant-newno")?.focus();
      return;
    }
    setErr(null);
    setBusy(true);
    try {
      await upsertGrant({ newNo: newNo.trim(), role: "STAFF", canManageAccess: delegate });
      toast.success(t("access.toast.granted"));
      onSaved();
      onClose();
    } catch {
      toast.error(t("errors.generic"));
    } finally {
      setBusy(false);
    }
  };

  const Radio = ({ checked, onChange, label }: { checked: boolean; onChange: () => void; label: string }) => (
    <label className={`check radio${checked ? " checked" : ""}`}>
      <input
        type="radio"
        name="access-role"
        checked={checked}
        onChange={onChange}
        style={{ position: "absolute", opacity: 0 }}
      />
      <span className="box" aria-hidden="true">
        <span className="rdot" />
      </span>
      {label}
    </label>
  );

  return (
    <Modal
      open={open}
      title={t("access.addModal.title")}
      icon={<IconUsers width={18} height={18} />}
      onClose={onClose}
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={busy}>
            {t("common.cancel")}
          </Button>
          <Button variant="primary" onClick={submit} loading={busy}>
            {t("access.addModal.submit")}
          </Button>
        </>
      }
    >
      <div className="form-stack">
        <Field
          label={t("access.addModal.newNoLabel")}
          htmlFor="grant-newno"
          required
          hint={t("access.addModal.newNoHint")}
          error={err ?? undefined}
        >
          <TextField
            id="grant-newno"
            mono
            value={newNo}
            onChange={(e) => setNewNo(e.target.value)}
            placeholder={t("access.addModal.newNoPlaceholder")}
            invalid={Boolean(err)}
            inputMode="numeric"
            autoComplete="off"
          />
        </Field>

        <div>
          <div style={{ fontSize: 11, fontWeight: 600, color: "var(--ink-2)", marginBottom: 8 }}>
            {t("access.addModal.roleLabel")}
          </div>
          <div className="radio-group">
            <Radio checked={!delegate} onChange={() => setDelegate(false)} label={t("access.addModal.roleStaff")} />
            {canSetDelegate && (
              <Radio checked={delegate} onChange={() => setDelegate(true)} label={t("access.addModal.roleDelegate")} />
            )}
          </div>
        </div>
      </div>
    </Modal>
  );
}
