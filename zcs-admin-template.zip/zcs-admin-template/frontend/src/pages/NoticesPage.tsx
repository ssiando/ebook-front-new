import { useMemo, useState } from "react";
import { PageTitle } from "../components/PageTitle";
import { FilterBar } from "../components/FilterBar";
import { DataTable, type Column } from "../components/DataTable";
import { Pager } from "../components/Pager";
import { Button } from "../components/Button";
import { Alert } from "../components/Alert";
import { EmptyState } from "../components/EmptyState";
import { NoPermission } from "../components/NoPermission";
import { ConfirmModal } from "../components/ConfirmModal";
import { IconPlus } from "../components/icons";
import { NoticeFormModal } from "./NoticeFormModal";
import { NoticeDetail } from "./NoticeDetail";
import { useList } from "../hooks/useList";
import { deleteNotice } from "../hooks/notices";
import { useToast } from "../components/Toast";
import { useAuth } from "../context/AuthContext";
import type { Notice } from "../types/api";
import { formatDate } from "../lib/format";
import { t, tNode } from "../i18n";

const PAGE_SIZE = 12;

export function NoticesPage() {
  const { user } = useAuth();
  const toast = useToast();
  const { items, loading, error, reload } = useList<Notice>("/api/notices");

  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [detail, setDetail] = useState<Notice | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Notice | null>(null);
  const [deleting, setDeleting] = useState<Notice | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q ? items.filter((n) => n.title.toLowerCase().includes(q)) : items;
  }, [items, query]);

  const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  if (error?.code === "FORBIDDEN") {
    return <NoPermission self={user ? { name: user.name, newNo: user.newNo } : undefined} />;
  }

  const openCreate = () => {
    setEditing(null);
    setFormOpen(true);
  };
  const openEdit = (notice: Notice) => {
    setDetail(null);
    setEditing(notice);
    setFormOpen(true);
  };
  const confirmDelete = async () => {
    if (!deleting) return;
    try {
      await deleteNotice(deleting.id);
      toast.success(t("notices.toast.deleted"));
      setDeleting(null);
      setDetail(null);
      reload();
    } catch {
      toast.error(t("errors.generic"));
    }
  };

  const columns: Column<Notice>[] = [
    {
      key: "title",
      header: t("notices.col.title"),
      render: (n) => <span style={{ fontWeight: 600, color: "var(--ink)" }}>{n.title}</span>,
    },
    { key: "author", header: t("notices.col.author"), render: (n) => n.authorName },
    {
      key: "createdAt",
      header: t("notices.col.createdAt"),
      render: (n) => <span className="tnum">{formatDate(n.createdAt)}</span>,
    },
  ];

  return (
    <>
      <PageTitle
        title={t("notices.title")}
        actions={
          <Button variant="primary" leadingIcon={<IconPlus width={14} height={14} />} onClick={openCreate}>
            {t("notices.create")}
          </Button>
        }
      />

      <div className="panel">
        <FilterBar
          query={query}
          onQuery={(v) => {
            setQuery(v);
            setPage(1);
          }}
          placeholder={t("notices.searchPlaceholder")}
          meta={<span>{tNode("common.countItems", "count", <b className="tnum">{filtered.length}</b>)}</span>}
        />

        {error ? (
          <div style={{ padding: 16 }}>
            <Alert tone="danger">
              {t("notices.error")}{" "}
              <button className="btn sm" style={{ marginLeft: 8 }} onClick={reload}>
                {t("common.retry")}
              </button>
            </Alert>
          </div>
        ) : (
          <DataTable
            columns={columns}
            rows={paged}
            rowKey={(n) => n.id}
            onRowClick={(n) => setDetail(n)}
            rowLabel={(n) => n.title}
            loading={loading}
            empty={
              <EmptyState
                title={t("notices.empty.title")}
                desc={t("notices.empty.desc")}
                action={
                  <Button variant="primary" leadingIcon={<IconPlus width={14} height={14} />} onClick={openCreate}>
                    {t("notices.create")}
                  </Button>
                }
              />
            }
          />
        )}

        {!loading && !error && <Pager page={page} pageSize={PAGE_SIZE} total={filtered.length} onPage={setPage} />}
      </div>

      <NoticeDetail notice={detail} onClose={() => setDetail(null)} onEdit={openEdit} onDelete={setDeleting} />

      {formOpen && (
        <NoticeFormModal
          open={formOpen}
          notice={editing}
          onClose={() => setFormOpen(false)}
          onSaved={reload}
        />
      )}

      <ConfirmModal
        open={Boolean(deleting)}
        title={t("notices.delete.title")}
        message={t("notices.delete.desc")}
        confirmLabel={t("notices.delete.confirm")}
        onConfirm={confirmDelete}
        onClose={() => setDeleting(null)}
      />
    </>
  );
}
