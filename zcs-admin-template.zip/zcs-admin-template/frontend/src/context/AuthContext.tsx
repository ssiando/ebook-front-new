import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { fetchApi, getToken, clearToken, startLogin } from "../services/api";
import type { MeResponse, MeUser, MeAccess, MeSession } from "../types/api";

interface AuthState {
  user: MeUser | null;
  access: MeAccess | null;
  session: MeSession | null;
  loading: boolean;
  login: () => void;
  logout: () => Promise<void>;
}

const defaultAccess: MeAccess = { super: false, hasAccess: false, canManageAccess: false };

const AuthContext = createContext<AuthState | null>(null);

// Minimum gap between activity-triggered heartbeats — doing things refreshes the
// known deadline quickly without spamming the server (every authed call already
// bumps the server clock; this just resyncs the client's view).
const ACTIVITY_HEARTBEAT_DEBOUNCE_MS = 12_000;

interface HeartbeatResponse {
  session: MeSession;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<MeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const heartbeatTimer = useRef<number | null>(null);
  const lastActivityBeat = useRef(0);

  useEffect(() => {
    if (!getToken()) {
      setLoading(false);
      return;
    }
    fetchApi<MeResponse>("/api/auth/me")
      .then(setMe)
      // A failed /me on boot is a dead/invalid token; the api client already
      // routed a 401 to login. Just drop local state.
      .catch(() => {
        clearToken();
        setMe(null);
      })
      .finally(() => setLoading(false));
  }, []);

  // Heartbeat keeps the session alive AND refreshes the client's known deadline:
  // the response carries the post-activity session block (advanced lastSeenAt /
  // idleExpiresAt), which we fold into state so the 내 정보 countdown resyncs. A 401
  // is handled centrally by the api client (drops token, routes to login).
  useEffect(() => {
    if (!me) return;

    const beat = () => {
      if (document.visibilityState !== "visible") return;
      fetchApi<HeartbeatResponse>("/api/sessions/heartbeat", { method: "POST" })
        .then((res) => {
          if (res?.session) {
            setMe((prev) => (prev ? { ...prev, session: res.session } : prev));
          }
        })
        .catch(() => {});
    };

    // Periodic keep-alive.
    const intervalMs = Math.max(15, me.heartbeatSeconds) * 1000;
    heartbeatTimer.current = window.setInterval(beat, intervalMs);

    // Real user activity → debounced heartbeat so the deadline resets promptly.
    const onActivity = () => {
      const now = Date.now();
      if (now - lastActivityBeat.current < ACTIVITY_HEARTBEAT_DEBOUNCE_MS) return;
      lastActivityBeat.current = now;
      beat();
    };
    window.addEventListener("pointerdown", onActivity, { passive: true });
    window.addEventListener("keydown", onActivity);

    return () => {
      if (heartbeatTimer.current) window.clearInterval(heartbeatTimer.current);
      window.removeEventListener("pointerdown", onActivity);
      window.removeEventListener("keydown", onActivity);
    };
  }, [me]);

  const logout = useCallback(async () => {
    try {
      await fetchApi<void>("/api/auth/logout", { method: "POST" });
    } catch {
      // Even if the call fails, drop local state and return to login.
    }
    clearToken();
    setMe(null);
    window.location.hash = "#/login";
  }, []);

  const value: AuthState = {
    user: me?.user ?? null,
    access: me?.access ?? (me ? defaultAccess : null),
    session: me?.session ?? null,
    loading,
    login: startLogin,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
