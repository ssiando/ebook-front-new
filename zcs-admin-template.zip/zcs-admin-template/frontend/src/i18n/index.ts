// Minimal i18n runtime (light path per the i18n skill).
//
// The app is Korean-only today, so we ship a single locale file (locales/ko.json)
// and a tiny t() resolver — no react-i18next (justified: one language, no ICU
// plurals, internal tool). Every user-facing string still goes through a key, so
// adding a language later is just: drop in locales/<lng>.json, pick by
// localStorage["language"], and fall back to ko. See _workspace/06_i18n_guide.md.

import { createElement, Fragment, type ReactNode } from "react";
import ko from "../locales/ko.json";

type Messages = { [key: string]: string | Messages };

const SOURCE_LNG = "ko";
const bundles: Record<string, Messages> = { ko };

function activeLng(): string {
  return localStorage.getItem("language") ?? SOURCE_LNG;
}

function resolve(bundle: Messages, key: string): string | undefined {
  let node: string | Messages | undefined = bundle;
  for (const part of key.split(".")) {
    if (node == null || typeof node === "string") return undefined;
    node = node[part];
  }
  return typeof node === "string" ? node : undefined;
}

function interpolate(template: string, vars?: Record<string, string | number>): string {
  if (!vars) return template;
  return template.replace(/\{(\w+)\}/g, (match, name) =>
    name in vars ? String(vars[name]) : match,
  );
}

/** Translate a dotted key (e.g. "notices.title"). Falls back to the source
 *  language, then to the key itself, so a missing key never crashes the UI. */
export function t(key: string, vars?: Record<string, string | number>): string {
  const lng = activeLng();
  const raw = resolve(bundles[lng] ?? {}, key) ?? resolve(bundles[SOURCE_LNG], key) ?? key;
  return interpolate(raw, vars);
}

/** Like t(), but a single {slot} is replaced by a React node (e.g. a bold count)
 *  instead of a string — keeps markup out of the locale file and avoids
 *  dangerouslySetInnerHTML. */
export function tNode(key: string, slot: string, node: ReactNode): ReactNode {
  const raw = resolve(bundles[activeLng()] ?? {}, key) ?? resolve(bundles[SOURCE_LNG], key) ?? key;
  const [before, after = ""] = raw.split(`{${slot}}`);
  return createElement(Fragment, null, before, node, after);
}
