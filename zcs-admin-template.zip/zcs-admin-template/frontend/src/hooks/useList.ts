import { useCallback, useEffect, useState } from "react";
import { fetchApi, ApiError } from "../services/api";
import type { ListResponse } from "../types/api";

interface ListState<T> {
  items: T[];
  loading: boolean;
  error: ApiError | null;
  reload: () => void;
}

// Fetches a { items: [...] } list endpoint. Unwraps to the array and exposes the
// loading/error/reload triplet every list screen needs. A 401 is handled by the
// api client; 403 surfaces here as error.code === "FORBIDDEN" for the noperm gate.
export function useList<T>(path: string): ListState<T> {
  const [items, setItems] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<ApiError | null>(null);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    fetchApi<ListResponse<T>>(path)
      .then((res) => setItems(res?.items ?? []))
      .catch((err: unknown) => {
        setItems([]);
        if (err instanceof ApiError) setError(err);
        else setError(new ApiError("INTERNAL", "", 0));
      })
      .finally(() => setLoading(false));
  }, [path]);

  useEffect(load, [load]);

  return { items, loading, error, reload: load };
}
