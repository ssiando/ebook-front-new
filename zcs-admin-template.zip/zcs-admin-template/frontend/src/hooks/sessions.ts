import { fetchApi } from "../services/api";

// Revoke (force-logout) a session by its opaque id (super-admin only). 고유번호
// never travels in the URL — only the opaque session id.
export const revokeSession = (id: string) =>
  fetchApi<void>(`/api/sessions/${id}`, { method: "DELETE" });
