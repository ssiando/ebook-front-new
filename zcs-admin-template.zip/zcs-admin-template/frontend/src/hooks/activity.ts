import { useCallback, useEffect, useState } from "react";
import { fetchApi, ApiError } from "../services/api";
import type { ActivityResponse } from "../types/api";

export interface ActivityQuery {
  action?: string; // single action code or "" for all
  from?: string; // ISO date YYYY-MM-DD
  to?: string;
  limit: number;
  offset: number;
}

interface ActivityState {
  data: ActivityResponse | null;
  loading: boolean;
  error: ApiError | null;
  reload: () => void;
}

function buildQuery(q: ActivityQuery): string {
  const p = new URLSearchParams();
  p.set("limit", String(q.limit));
  p.set("offset", String(q.offset));
  if (q.action) p.set("action", q.action);
  if (q.from) p.set("from", q.from);
  if (q.to) p.set("to", q.to);
  return p.toString();
}

// 활동 감사 로그 (super-admin only). Server-side filtering (action/date) +
// pagination (limit/offset) via /api/activity. 403 surfaces as error.FORBIDDEN.
export function useActivity(query: ActivityQuery): ActivityState {
  const [data, setData] = useState<ActivityResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<ApiError | null>(null);
  const qs = buildQuery(query);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    fetchApi<ActivityResponse>(`/api/activity?${qs}`)
      .then(setData)
      .catch((err: unknown) => {
        setData(null);
        setError(err instanceof ApiError ? err : new ApiError("INTERNAL", "", 0));
      })
      .finally(() => setLoading(false));
  }, [qs]);

  useEffect(load, [load]);

  return { data, loading, error, reload: load };
}
