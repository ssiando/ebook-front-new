import { fetchApi } from "../services/api";
import type { Notice } from "../types/api";

export interface NoticeInput {
  title: string;
  body: string;
}

export const createNotice = (input: NoticeInput) =>
  fetchApi<Notice>("/api/notices", { method: "POST", body: JSON.stringify(input) });

export const updateNotice = (id: number, input: NoticeInput) =>
  fetchApi<Notice>(`/api/notices/${id}`, { method: "PUT", body: JSON.stringify(input) });

export const deleteNotice = (id: number) =>
  fetchApi<void>(`/api/notices/${id}`, { method: "DELETE" });
