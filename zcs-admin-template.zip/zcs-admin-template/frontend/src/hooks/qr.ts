import { fetchApi } from "../services/api";
import type { QrIssueResponse } from "../types/api";

// Issuance only — the backend returns { scanUrl }; the QR image is rendered
// client-side. The signed token lives ONLY inside scanUrl: never log it.
export const issueQr = (ref: string) =>
  fetchApi<QrIssueResponse>("/api/qr/issue", { method: "POST", body: JSON.stringify({ ref }) });
