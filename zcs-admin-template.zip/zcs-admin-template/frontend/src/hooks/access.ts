import { fetchApi } from "../services/api";
import type { Grant } from "../types/api";

export interface GrantInput {
  newNo: string;
  role?: "STAFF";
  canManageAccess?: boolean;
}

// 고유번호 travels in the BODY only (privacy P-6). Create/update is idempotent by
// 고유번호; revoke addresses the row by its opaque id.
export const upsertGrant = (input: GrantInput) =>
  fetchApi<Grant>("/api/access/grants", { method: "PUT", body: JSON.stringify(input) });

export const revokeGrant = (id: string) =>
  fetchApi<void>(`/api/access/grants/${id}`, { method: "DELETE" });
