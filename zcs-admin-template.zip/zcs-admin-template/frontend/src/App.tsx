import { Routes, Route, Navigate } from "react-router-dom";
import { AuthedLayout, Gate } from "./components/ProtectedRoute";
import { LoginScreen } from "./pages/LoginScreen";
import { OAuthCallback } from "./pages/OAuthCallback";
import { NoticesPage } from "./pages/NoticesPage";
import { QrIssuePage } from "./pages/QrIssuePage";
import { AccessManagementPage } from "./pages/AccessManagementPage";
import { SessionsPage } from "./pages/SessionsPage";
import { ActivityLogPage } from "./pages/ActivityLogPage";

export function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginScreen />} />
      <Route path="/auth/callback" element={<OAuthCallback />} />

      <Route element={<AuthedLayout />}>
        <Route index element={<Navigate to="/notices" replace />} />
        <Route
          path="/notices"
          element={
            <Gate need="access">
              <NoticesPage />
            </Gate>
          }
        />
        <Route
          path="/qr"
          element={
            <Gate need="access">
              <QrIssuePage />
            </Gate>
          }
        />
        <Route
          path="/access"
          element={
            <Gate need="manage">
              <AccessManagementPage />
            </Gate>
          }
        />
        <Route
          path="/audit"
          element={
            <Gate need="super">
              <ActivityLogPage />
            </Gate>
          }
        />
        <Route
          path="/sessions"
          element={
            <Gate need="super">
              <SessionsPage />
            </Gate>
          }
        />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
