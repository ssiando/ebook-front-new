import { t } from "../i18n";
import type { MeAccess } from "../types/api";

// Plain-Korean role label from the access block (never a raw code). Used by the
// sidebar footer and the 내 정보 drawer so the label is identical everywhere.
export function roleLabel(access: MeAccess): string {
  if (access.super) return t("shell.role.super");
  if (access.canManageAccess) return t("shell.role.delegate");
  if (access.hasAccess) return t("shell.role.staff");
  return t("shell.role.none");
}
