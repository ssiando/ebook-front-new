// 12-tribe identification palette (the only multi-color set ZCS carries over).
// Used ONLY on the .gem identity element — never as a generic accent/brand color.
// The order number (1-12) doubles as a language-neutral identifier on the gem.
// Hex values are taken verbatim from the ZCS reference (design-system.html §03).

export interface TribeStyle {
  order: number;
  bg: string;
  fg: string;
}

// Keyed by the core Korean tribe name. The /me `tribe` field may arrive as
// "베드로지파" / "베드로" — we match on the contained name.
const TRIBES: Record<string, TribeStyle> = {
  요한: { order: 1, bg: "#009651", fg: "#191f28" },
  베드로: { order: 2, bg: "#00a0e9", fg: "#191f28" },
  부산야고보: { order: 3, bg: "#1d2088", fg: "#ffffff" },
  안드레: { order: 4, bg: "#59c3e1", fg: "#191f28" },
  다대오: { order: 5, bg: "#eb6120", fg: "#191f28" },
  빌립: { order: 6, bg: "#d7005b", fg: "#ffffff" },
  시몬: { order: 7, bg: "#fdd000", fg: "#191f28" },
  바돌로매: { order: 8, bg: "#86cab6", fg: "#191f28" },
  마태: { order: 9, bg: "#e39300", fg: "#191f28" },
  맛디아: { order: 10, bg: "#6fba2c", fg: "#191f28" },
  서울야고보: { order: 11, bg: "#005dac", fg: "#ffffff" },
  도마: { order: 12, bg: "#7f1084", fg: "#ffffff" },
};

const NEUTRAL: TribeStyle = { order: 0, bg: "#5f6b7a", fg: "#ffffff" };

/** Resolve a tribe display string to its gem style, or null when unknown/empty. */
export function tribeStyle(tribe: string | undefined | null): TribeStyle | null {
  if (!tribe) return null;
  // Longest key first so "부산야고보"/"서울야고보" win over "야고보".
  const keys = Object.keys(TRIBES).sort((a, b) => b.length - a.length);
  for (const key of keys) {
    if (tribe.includes(key)) return TRIBES[key];
  }
  return NEUTRAL;
}
