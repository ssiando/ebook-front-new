import type { ActivityAction } from "../types/api";

type BadgeTone = "neutral" | "brand" | "warning" | "danger";

// Maps raw audit action codes → plain-Korean label + badge tone. Raw codes
// (LOGIN, GRANT, …) are developer terminology and must NEVER reach the UI — always
// render through this map. `null` label means an unknown/future code (shown as a
// neutral fallback rather than the raw string).
const ACTION_LABELS: Record<ActivityAction, { label: string; tone: BadgeTone }> = {
  LOGIN: { label: "로그인", tone: "neutral" },
  LOGOUT: { label: "로그아웃", tone: "neutral" },
  NOTICE_CREATE: { label: "공지 작성", tone: "brand" },
  NOTICE_UPDATE: { label: "공지 수정", tone: "brand" },
  NOTICE_DELETE: { label: "공지 삭제", tone: "warning" },
  GRANT: { label: "권한 부여", tone: "brand" },
  REVOKE: { label: "권한 회수", tone: "warning" },
  SESSION_REVOKE: { label: "세션 강제 종료", tone: "danger" },
};

export const ACTION_ORDER: ActivityAction[] = [
  "LOGIN",
  "LOGOUT",
  "NOTICE_CREATE",
  "NOTICE_UPDATE",
  "NOTICE_DELETE",
  "GRANT",
  "REVOKE",
  "SESSION_REVOKE",
];

export function actionLabel(action: string): string {
  return ACTION_LABELS[action as ActivityAction]?.label ?? "기타 활동";
}

export function actionTone(action: string): BadgeTone {
  return ACTION_LABELS[action as ActivityAction]?.tone ?? "neutral";
}
