// React-safe SCJ brand-mark builder.
//
// The vendored ZCS ships zcs/scj-logo.js, which paints .scj-mark hosts by mutating
// the DOM via a MutationObserver. That imperative injection fights React — React
// owns the <span> and reconciliation leaves it empty, so the mark never appears.
// We instead build the painted <svg> ourselves (porting the paint/build logic from
// scj-logo.js) and let ScjMark set it via innerHTML on a span it controls. The
// vendored files are NOT edited; we just stop loading scj-logo.js (removed from
// index.html) so the two mechanisms don't conflict.

const SIGN_SRC = "/zcs/brand/scj-signature.svg"; // full-color horizontal signature
const SYM_SRC = "/zcs/_official/scj-mark-black.svg"; // official single-path throne symbol
const NS = "http://www.w3.org/2000/svg";

// signature class → official fill (from scj-logo.js COLORS map)
const COLORS: Record<string, string> = {
  "cls-1": "#fff", "cls-2": "#e1f4fd", "cls-3": "#25bce7", "cls-4": "#0089cf",
  "cls-5": "#fcb133", "cls-6": "#231f20", "cls-7": "#ed1c24", "cls-8": "#fff200",
  "cls-9": "#00a651", "cls-10": "#50b848", "cls-11": "#231f20", "cls-12": "#bb5d15",
  "cls-13": "#006bb6", "cls-14": "#25bce7",
};
// knock-out (white) fills, dropped in the derived mono fallback
const WHITE: Record<string, number> = { "cls-1": 1, "cls-2": 1 };

function shapesOf(svg: Element): NodeListOf<SVGElement> {
  return svg.querySelectorAll<SVGElement>("path,polygon,rect,circle,ellipse,line");
}

function paintColor(svg: Element): void {
  shapesOf(svg).forEach((s) => {
    const c = s.getAttribute("class");
    if (c && COLORS[c]) s.setAttribute("fill", COLORS[c]);
  });
}

function paintMono(svg: Element): void {
  shapesOf(svg).forEach((s) => s.setAttribute("fill", "currentColor"));
}

function paintMonoDerived(svg: Element): void {
  shapesOf(svg).forEach((s) => {
    const c = s.getAttribute("class");
    s.setAttribute("fill", c && WHITE[c] ? "none" : "currentColor");
  });
}

function finalize(svg: SVGElement): string {
  svg.removeAttribute("width");
  svg.removeAttribute("height");
  svg.removeAttribute("id");
  svg.setAttribute("preserveAspectRatio", "xMidYMid meet");
  // The host span carries role/aria-label (or aria-hidden) — keep the inner svg
  // out of the a11y tree to avoid duplicate announcements.
  svg.setAttribute("aria-hidden", "true");
  return svg.outerHTML;
}

interface MarkSet {
  color: string;
  mono: string;
}

let cache: Promise<MarkSet> | null = null;

async function build(): Promise<MarkSet> {
  const [signText, symText] = await Promise.all([
    fetch(SIGN_SRC).then((r) => r.text()),
    fetch(SYM_SRC)
      .then((r) => (r.ok ? r.text() : null))
      .catch(() => null),
  ]);

  const signDoc = new DOMParser().parseFromString(signText, "image/svg+xml").documentElement as unknown as SVGElement;

  // Color mark = the signature cropped to its left square (the throne symbol).
  const colorMark = signDoc.cloneNode(true) as SVGElement;
  colorMark.setAttribute("viewBox", "0 0 177.09 177.09");
  paintColor(colorMark);

  // Mono mark = the official single-path symbol painted with currentColor (so the
  // is-neg / is-mono CSS color flows through). Fall back to the derived signature.
  let monoMark: SVGElement;
  if (symText) {
    const symDoc = new DOMParser().parseFromString(symText, "image/svg+xml").documentElement;
    symDoc.querySelector("style")?.remove();
    monoMark = document.createElementNS(NS, "svg");
    monoMark.setAttribute("viewBox", "0 0 70.87 70.87");
    monoMark.innerHTML = symDoc.innerHTML;
    paintMono(monoMark);
  } else {
    monoMark = signDoc.cloneNode(true) as SVGElement;
    monoMark.setAttribute("viewBox", "0 0 177.09 177.09");
    paintMonoDerived(monoMark);
  }

  return { color: finalize(colorMark), mono: finalize(monoMark) };
}

/** Painted <svg> outerHTML for the throne mark. Both SVGs are fetched once. */
export async function getMarkSvg(mono: boolean): Promise<string> {
  if (!cache) cache = build();
  const set = await cache;
  return mono ? set.mono : set.color;
}
