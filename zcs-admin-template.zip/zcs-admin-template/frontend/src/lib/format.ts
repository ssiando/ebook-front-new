// Locale-aware date formatting. Backend timestamps are ISO 8601 UTC strings.
// Output is the console's fixed numeric style ("2026-06-28", "2026-06-28 14:20")
// so 고유번호-dense tables stay aligned; the locale drives the calendar/timezone.

const ACTIVE_LOCALE = "ko-KR";

const ymd = new Intl.DateTimeFormat(ACTIVE_LOCALE, {
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});

const hm = new Intl.DateTimeFormat(ACTIVE_LOCALE, {
  hour: "2-digit",
  minute: "2-digit",
  hour12: false,
});

function toDashedDate(d: Date): string {
  // Intl ko-KR yields "2026. 06. 28." — flatten to "2026-06-28".
  return ymd
    .formatToParts(d)
    .filter((p) => p.type === "year" || p.type === "month" || p.type === "day")
    .map((p) => p.value)
    .join("-");
}

export function formatDate(iso: string): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return toDashedDate(d);
}

export function formatDateTime(iso: string): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${toDashedDate(d)} ${hm.format(d)}`;
}

const MIN = 60_000;
const HOUR = 60 * MIN;
const DAY = 24 * HOUR;

/** Relative past time in Korean: "방금 전" / "N분 전" / "N시간 전" / "N일 전". */
export function relativePast(iso: string, now: number = Date.now()): string {
  if (!iso) return "";
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return iso;
  const diff = Math.max(0, now - t);
  if (diff < MIN) return "방금 전";
  if (diff < HOUR) return `${Math.floor(diff / MIN)}분 전`;
  if (diff < DAY) return `${Math.floor(diff / HOUR)}시간 전`;
  return `${Math.floor(diff / DAY)}일 전`;
}

/** Time-until-expiry label + an "임박"(imminent, <5분) flag, for idle countdowns. */
export function untilExpiry(iso: string, now: number = Date.now()): { text: string; imminent: boolean } {
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return { text: iso, imminent: false };
  const diff = t - now;
  if (diff <= 0) return { text: "만료됨", imminent: true };
  if (diff < 5 * MIN) return { text: "만료 임박", imminent: true };
  if (diff < HOUR) return { text: `${Math.ceil(diff / MIN)}분 후`, imminent: false };
  return { text: `${Math.floor(diff / HOUR)}시간 후`, imminent: false };
}

/** Live countdown "M분 S초 남음" (or "곧 종료" at/under zero) for the 내 정보 drawer. */
export function countdownLabel(iso: string, now: number = Date.now()): { text: string; warn: boolean } {
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return { text: iso, warn: false };
  const diff = t - now;
  if (diff <= 0) return { text: "곧 자동 로그아웃됩니다", warn: true };
  const totalSec = Math.floor(diff / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  const text = m > 0 ? `${m}분 ${s}초 남음` : `${s}초 남음`;
  return { text, warn: diff < 2 * MIN };
}
