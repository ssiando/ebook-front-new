import type { ReactElement } from "react";
import { IconInbox, IconUsers, IconShieldGroup, IconActivity, IconMonitor } from "../components/icons";
import { t } from "../i18n";

// Permission context the sidebar passes to each node's `visible` predicate.
// Visibility only HIDES menus — every route is still gated server-side (AC-5.2).
export interface NavCtx {
  isSuper: boolean;
  canManageAccess: boolean;
  hasAccess: boolean;
}

type IconCmp = (props: { width?: number; height?: number }) => ReactElement;

export type NavNode =
  | { kind: "item"; label: string; icon?: IconCmp; to: string; visible?: (c: NavCtx) => boolean }
  | { kind: "group"; label: string; icon?: IconCmp; children: NavNode[]; visible?: (c: NavCtx) => boolean };

// The seed tree. A fork adds nested menus by editing this config — never the
// renderer. The engine recurses on `children`, so depth is unbounded (a group
// child may itself be a group → 3+ levels).
export function buildNavTree(): NavNode[] {
  return [
    {
      kind: "item",
      label: t("shell.nav.notices"),
      icon: IconInbox,
      to: "/notices",
      visible: (c) => c.hasAccess,
    },
    {
      kind: "group",
      label: t("shell.nav.accessGroup"),
      icon: IconUsers,
      visible: (c) => c.isSuper || c.canManageAccess,
      children: [{ kind: "item", label: t("shell.nav.access"), to: "/access" }],
    },
    {
      kind: "group",
      label: t("shell.nav.securityGroup"),
      icon: IconShieldGroup,
      visible: (c) => c.isSuper,
      children: [
        { kind: "item", label: t("shell.nav.activity"), icon: IconActivity, to: "/audit" },
        { kind: "item", label: t("shell.nav.sessions"), icon: IconMonitor, to: "/sessions" },
      ],
    },
  ];
}
