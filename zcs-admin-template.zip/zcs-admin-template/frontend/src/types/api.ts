// API response types — 1:1 with _workspace/api_contracts.md. camelCase, as the
// Go backend serializes. Do not widen these without updating the contract first.

export interface MeUser {
  newNo: string;
  name: string;
  tribe: string;
  church: string;
  duty: string;
}

export interface MeAccess {
  super: boolean;
  hasAccess: boolean;
  canManageAccess: boolean;
}

export interface MeSession {
  id: string;
  createdAt: string;
  lastSeenAt: string;
  expiresAt: string;
  idleExpiresAt: string;
  usageSeconds: number;
}

export interface MeResponse {
  user: MeUser;
  access: MeAccess;
  session: MeSession;
  heartbeatSeconds: number;
}

export interface Notice {
  id: number;
  title: string;
  body: string;
  authorName: string;
  createdAt: string;
  updatedAt: string;
}

export type GrantRole = "STAFF";

export interface Grant {
  id: string;
  newNo: string;
  role: GrantRole;
  canManageAccess: boolean;
  grantedBy: string;
  grantedAt: string;
  confirmed: boolean;
  confirmedAt: string | null;
  // The backend is Bearer-only (no Admin Key), so it does NOT resolve other
  // people's names — this field is simply absent in the current contract. The UI
  // shows 고유번호 + an "이름 미확인"/"확인됨" badge (keyed off `confirmed`). Kept
  // optional only so a future Admin-API name resolution could populate it without
  // a type change; today it is always undefined.
  name?: string | null;
}

// 보안·감사 (super-admin only) — CR-02.

export interface SessionInfo {
  id: string; // opaque handle — pass to DELETE; never a token, never 고유번호 in URL
  newNo: string;
  name: string; // login-time snapshot; may be empty for legacy rows
  loginAt: string;
  lastSeenAt: string;
  idleExpiresAt: string;
  isCurrent: boolean;
}

export type ActivityAction =
  | "LOGIN"
  | "LOGOUT"
  | "NOTICE_CREATE"
  | "NOTICE_UPDATE"
  | "NOTICE_DELETE"
  | "GRANT"
  | "REVOKE"
  | "SESSION_REVOKE";

export interface ActivityEntry {
  id: number;
  actorNo: string;
  action: ActivityAction;
  target: string | null; // GRANT/REVOKE = 고유번호; NOTICE_* = notice id; SESSION_REVOKE = session id; LOGIN/LOGOUT = null
  detail: string | null;
  createdAt: string;
}

export interface ActivityResponse {
  items: ActivityEntry[];
  total: number;
  limit: number;
  offset: number;
}

export interface QrIssueResponse {
  scanUrl: string;
}

/** List endpoints always wrap as { items: [...] } (contract convention). */
export interface ListResponse<T> {
  items: T[];
}
