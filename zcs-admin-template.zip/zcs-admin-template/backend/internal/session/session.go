// Package session implements DB-authoritative sessions keyed by the ZAuth
// access_token (zion-login canon): the bearer token is opaque here, rows are
// looked up by token_hash = SHA-256(token), and the raw token is never stored
// or logged. The row layers local revocation, idle expiry, and usage tracking
// on top of the canon; live tokens are periodically revalidated against ZAuth,
// fail-closed.
package session

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"net/http"
	"strings"
	"time"

	"github.com/google/uuid"

	"zcsadmin/internal/config"
	"zcsadmin/internal/store"
)

// Principal is the authenticated caller, resolved from a valid session on each
// request. Name/tribe/church/duty are display-only snapshots stored on the
// session row (session-lifetime only — purged with the session).
type Principal struct {
	NewNo  string
	Name   string
	Tribe  string
	Church string
	Duty   string
	Super  bool
	SID    string
}

// AuthError carries one of the three 401 contract codes.
type AuthError struct{ Code string }

func (e *AuthError) Error() string { return e.Code }

var (
	errUnauthorized = &AuthError{Code: "UNAUTHORIZED"}
	errRevoked      = &AuthError{Code: "SESSION_REVOKED"}
	errExpired      = &AuthError{Code: "SESSION_EXPIRED"}
)

// Validator revalidates a live ZAuth access_token (zion-login canon §3).
// Implemented by the zauth client; any error means not-valid.
type Validator interface {
	Validate(ctx context.Context, accessToken string) error
}

// Row is a session record. Computed fields (idleExpiresAt) are not stored.
type Row struct {
	ID              string
	UserNewNo       string
	UserName        string // display-name snapshot for the 세션 관리 screen
	Tribe           string
	Church          string
	Duty            string
	IsSuper         bool
	IsDev           bool // test-login session: skips ZAuth revalidation
	CreatedAt       time.Time
	LastSeenAt      time.Time
	LastValidatedAt time.Time
	ExpiresAt       time.Time
	RevokedAt       *time.Time
	RevokedBy       *string
	UsageSeconds    int64
}

type Service struct {
	st        *store.Store
	cfg       *config.Config
	validator Validator
}

func New(st *store.Store, cfg *config.Config, v Validator) *Service {
	return &Service{st: st, cfg: cfg, validator: v}
}

// Create opens a session row for a ZAuth access_token. Only SHA-256(token) is
// persisted; the absolute expiry follows the token's exp claim.
func (s *Service) Create(p Principal, token, userAgent, ip string) (Row, error) {
	return s.create(p, token, userAgent, ip, false)
}

// CreateDev opens a dev session (test-login) for an opaque local token; dev
// sessions are never revalidated against ZAuth.
func (s *Service) CreateDev(p Principal, token, userAgent, ip string) (Row, error) {
	return s.create(p, token, userAgent, ip, true)
}

func (s *Service) create(p Principal, token, userAgent, ip string, isDev bool) (Row, error) {
	now := s.st.Now()
	expires, ok := tokenExp(token)
	if !ok {
		expires = now.Add(12 * time.Hour) // opaque dev tokens carry no exp
	}
	row := Row{
		ID: uuid.NewString(), UserNewNo: p.NewNo, UserName: p.Name,
		Tribe: p.Tribe, Church: p.Church, Duty: p.Duty,
		IsSuper: p.Super, IsDev: isDev,
		CreatedAt: now, LastSeenAt: now, LastValidatedAt: now, ExpiresAt: expires,
	}
	if _, err := s.st.DB.Exec(`
		INSERT INTO sessions (id, token_hash, user_new_no, user_name, tribe, church,
			duty, is_super, is_dev, user_agent, ip,
			created_at, last_seen_at, last_validated_at, expires_at, usage_seconds)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$12,$12,$13,0)`,
		row.ID, hashToken(token), p.NewNo, truncate(p.Name, 200),
		truncate(p.Tribe, 200), truncate(p.Church, 200), truncate(p.Duty, 200),
		p.Super, isDev, truncate(userAgent, 400), truncate(ip, 64), now, expires,
	); err != nil {
		return Row{}, err
	}
	return row, nil
}

// Authenticate runs the per-request pipeline — bearer → token_hash lookup →
// revoked/absolute/idle checks → periodic ZAuth revalidation (fail-closed) →
// touch — and returns the live Principal, or an AuthError with the contract code.
func (s *Service) Authenticate(r *http.Request) (*Principal, *AuthError) {
	raw := bearer(r)
	if raw == "" {
		return nil, errUnauthorized
	}

	row, err := s.loadByTokenHash(hashToken(raw))
	if err != nil {
		return nil, errUnauthorized // treat lookup error as not-authenticated, fail-closed
	}
	if row == nil {
		return nil, errUnauthorized // unknown token
	}
	if row.RevokedAt != nil {
		return nil, errRevoked
	}

	now := s.st.Now()
	if now.After(row.ExpiresAt) {
		return nil, s.lazyRevoke(row.ID, now, "expired")
	}
	idle := time.Duration(s.cfg.IdleWindowSeconds()) * time.Second
	if now.Sub(row.LastSeenAt) > idle {
		return nil, s.lazyRevoke(row.ID, now, "idle")
	}

	// Periodic ZAuth revalidation (dev sessions excepted). Any non-valid outcome
	// — including a missing validator — revokes the session, fail-closed.
	revalidate := time.Duration(s.cfg.SessionRevalidateSeconds) * time.Second
	revalidated := false
	if !row.IsDev && now.Sub(row.LastValidatedAt) >= revalidate {
		if s.validator == nil || s.validator.Validate(r.Context(), raw) != nil {
			_, _ = s.st.DB.Exec(
				`UPDATE sessions SET revoked_at = $1, revoked_by = 'revalidate'
				 WHERE id = $2 AND revoked_at IS NULL`, now, row.ID)
			return nil, errRevoked
		}
		revalidated = true
	}

	// Touch: accrue usage and advance last_seen (and the validation stamp when
	// this request revalidated). Synchronous Exec is durable before the response
	// leaves (commit-before-response rule).
	delta := int64(now.Sub(row.LastSeenAt).Seconds())
	touch := `UPDATE sessions SET usage_seconds = usage_seconds + $1, last_seen_at = $2
		 WHERE id = $3 AND revoked_at IS NULL`
	if revalidated {
		touch = `UPDATE sessions SET usage_seconds = usage_seconds + $1, last_seen_at = $2,
			 last_validated_at = $2 WHERE id = $3 AND revoked_at IS NULL`
	}
	if _, err := s.st.DB.Exec(touch, delta, now, row.ID); err != nil {
		return nil, errUnauthorized
	}

	return &Principal{
		NewNo: row.UserNewNo, Name: row.UserName, Tribe: row.Tribe,
		Church: row.Church, Duty: row.Duty, Super: row.IsSuper, SID: row.ID,
	}, nil
}

// lazyRevoke performs the race-safe conditional revoke. The single winner gets
// SESSION_EXPIRED; concurrent losers (rows-affected 0) get SESSION_REVOKED.
func (s *Service) lazyRevoke(id string, now time.Time, reason string) *AuthError {
	res, err := s.st.DB.Exec(
		`UPDATE sessions SET revoked_at = $1, revoked_by = $2
		 WHERE id = $3 AND revoked_at IS NULL`, now, reason, id)
	if err != nil {
		return errUnauthorized
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return errRevoked
	}
	return errExpired
}

// Revoke marks a session revoked by an actor (logout / force logout). Idempotent:
// an already-revoked row keeps its original revoked_at/revoked_by.
func (s *Service) Revoke(id, actorNewNo string) error {
	_, err := s.st.DB.Exec(
		`UPDATE sessions SET revoked_at = $1, revoked_by = $2
		 WHERE id = $3 AND revoked_at IS NULL`, s.st.Now(), actorNewNo, id)
	return err
}

const rowColumns = `id, user_new_no, user_name, tribe, church, duty, is_super,
	is_dev, created_at, last_seen_at, last_validated_at, expires_at,
	revoked_at, revoked_by, usage_seconds`

func (s *Service) loadWhere(where string, arg any) (*Row, error) {
	var (
		row                 Row
		tribe, church, duty sql.NullString
	)
	err := s.st.DB.QueryRow(
		`SELECT `+rowColumns+` FROM sessions WHERE `+where, arg).Scan(
		&row.ID, &row.UserNewNo, &row.UserName, &tribe, &church, &duty,
		&row.IsSuper, &row.IsDev, &row.CreatedAt, &row.LastSeenAt,
		&row.LastValidatedAt, &row.ExpiresAt,
		&row.RevokedAt, &row.RevokedBy, &row.UsageSeconds)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	row.Tribe, row.Church, row.Duty = tribe.String, church.String, duty.String
	return &row, nil
}

func (s *Service) loadByTokenHash(hash string) (*Row, error) {
	return s.loadWhere("token_hash = $1", hash)
}

// LoadRow exposes a session row by id for /me's session block.
func (s *Service) LoadRow(id string) (*Row, error) { return s.loadWhere("id = $1", id) }

// ListActive returns every genuinely-live session (not revoked, not past the
// absolute or idle deadline), newest first — for the 세션 관리 screen. Idle
// expiry is computed here for the listing; it does not revoke (that stays lazy
// on the owner's next request).
func (s *Service) ListActive() ([]Row, error) {
	now := s.st.Now()
	idleCutoff := now.Add(-time.Duration(s.cfg.IdleWindowSeconds()) * time.Second)
	rows, err := s.st.DB.Query(`
		SELECT id, user_new_no, user_name, is_super, created_at, last_seen_at,
		       expires_at, usage_seconds
		FROM sessions
		WHERE revoked_at IS NULL AND expires_at > $1 AND last_seen_at > $2
		ORDER BY last_seen_at DESC`, now, idleCutoff)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []Row
	for rows.Next() {
		var r Row
		if err := rows.Scan(&r.ID, &r.UserNewNo, &r.UserName, &r.IsSuper,
			&r.CreatedAt, &r.LastSeenAt, &r.ExpiresAt, &r.UsageSeconds); err != nil {
			return nil, err
		}
		out = append(out, r)
	}
	return out, rows.Err()
}

// IdleExpiresAt is the computed (never stored) idle deadline for a row.
func (s *Service) IdleExpiresAt(lastSeen time.Time) time.Time {
	return lastSeen.Add(time.Duration(s.cfg.IdleWindowSeconds()) * time.Second)
}

func hashToken(token string) string {
	sum := sha256.Sum256([]byte(token))
	return hex.EncodeToString(sum[:])
}

// tokenExp reads the exp claim from an UNVERIFIED JWT payload decode — for
// scheduling the absolute expiry only, never for trust (trust comes from the
// ZAuth validate endpoint; there is no published key for downstream apps).
// Returns false for opaque/non-JWT tokens.
func tokenExp(token string) (time.Time, bool) {
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return time.Time{}, false
	}
	payload, err := base64.RawURLEncoding.DecodeString(strings.TrimRight(parts[1], "="))
	if err != nil {
		return time.Time{}, false
	}
	var c struct {
		Exp float64 `json:"exp"`
	}
	if err := json.Unmarshal(payload, &c); err != nil || c.Exp <= 0 {
		return time.Time{}, false
	}
	return time.Unix(int64(c.Exp), 0).UTC(), true
}

func bearer(r *http.Request) string {
	h := r.Header.Get("Authorization")
	if after, ok := strings.CutPrefix(h, "Bearer "); ok {
		return strings.TrimSpace(after)
	}
	return ""
}

func truncate(s string, n int) string {
	if len(s) > n {
		return s[:n]
	}
	return s
}
