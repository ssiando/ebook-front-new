// Package access implements the local 고유번호 (newNo) permission model that
// replaces the standard ZAuth RBAC for this template.
//
// Evaluation order (fail-closed):
//  1. super-admin (from the ZAuth authority, carried on the Principal) → full access
//  2. newNo present in access_grant → that grant's role/capability
//  3. otherwise → no access
//
// Super-admin is NEVER stored here; it cannot be granted or revoked locally.
package access

import (
	"database/sql"
	"errors"
	"regexp"
	"strings"
	"time"

	"github.com/google/uuid"

	"zcsadmin/internal/activity"
	"zcsadmin/internal/store"
)

// RoleStaff is the single local role (운영자). Add roles by extending this set
// and the validation in handlers — this is the documented extension point.
const RoleStaff = "STAFF"

// newNoPattern is a lenient 고유번호 format check (digits with one hyphen, e.g.
// "00341130-00036"). Lenient by design: it must reject obviously-wrong input
// (names, emails) without risking a valid member key (P-9). Tune for your tenant.
var newNoPattern = regexp.MustCompile(`^[0-9]{4,10}-[0-9]{3,8}$`)

// ValidNewNo reports whether s is a plausibly-formatted 고유번호.
func ValidNewNo(s string) bool { return newNoPattern.MatchString(strings.TrimSpace(s)) }

// Decision is the resolved capability of a caller for the current request.
type Decision struct {
	Super           bool // from the ZAuth super-admin authority
	HasAccess       bool // may use feature screens (notices, QR)
	CanManageAccess bool // may open 고유번호 접근 관리
}

// Grant is a stored local access record. ID is the opaque URL handle; NewNo is
// the 고유번호 business key (carried only in bodies, never in URLs).
type Grant struct {
	ID              string
	NewNo           string
	Role            string
	CanManageAccess bool
	GrantedBy       string
	GrantedAt       time.Time
	ConfirmedAt     *time.Time // nil = 미확인 (granted before first login)
}

type Service struct{ st *store.Store }

func New(st *store.Store) *Service { return &Service{st: st} }

// Evaluate resolves a caller's access. super comes from the authenticated
// Principal (the ZAuth authority snapshot); the grant table decides the rest.
func (s *Service) Evaluate(newNo string, super bool) (Decision, error) {
	if super {
		return Decision{Super: true, HasAccess: true, CanManageAccess: true}, nil
	}
	g, err := s.Get(newNo)
	if err != nil {
		return Decision{}, err
	}
	if g == nil {
		return Decision{}, nil // fail-closed: no row → no access
	}
	return Decision{HasAccess: true, CanManageAccess: g.CanManageAccess}, nil
}

const grantColumns = `id, new_no, role, can_manage_access, granted_by, granted_at, confirmed_at`

func scanGrant(sc interface{ Scan(...any) error }) (*Grant, error) {
	var g Grant
	err := sc.Scan(&g.ID, &g.NewNo, &g.Role, &g.CanManageAccess,
		&g.GrantedBy, &g.GrantedAt, &g.ConfirmedAt)
	if err != nil {
		return nil, err
	}
	return &g, nil
}

// Get resolves a grant by 고유번호 (used by access evaluation).
func (s *Service) Get(newNo string) (*Grant, error) {
	g, err := scanGrant(s.st.DB.QueryRow(
		`SELECT `+grantColumns+` FROM access_grant WHERE new_no = $1`, newNo))
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	return g, err
}

// GetByID resolves a grant by its opaque URL handle.
func (s *Service) GetByID(id string) (*Grant, error) {
	g, err := scanGrant(s.st.DB.QueryRow(
		`SELECT `+grantColumns+` FROM access_grant WHERE id = $1`, id))
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	return g, err
}

func (s *Service) List() ([]Grant, error) {
	rows, err := s.st.DB.Query(
		`SELECT ` + grantColumns + ` FROM access_grant ORDER BY granted_at DESC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []Grant
	for rows.Next() {
		g, err := scanGrant(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, *g)
	}
	return out, rows.Err()
}

// Upsert creates or updates a grant (idempotent — AC-3.3) and records the GRANT
// in the unified activity log within the same transaction (durable before the
// response, sessions.md §2).
func (s *Service) Upsert(actorNo, targetNo, role string, canManage bool) (*Grant, error) {
	now := s.st.Now()
	tx, err := s.st.DB.Begin()
	if err != nil {
		return nil, err
	}
	defer tx.Rollback() //nolint:errcheck // no-op after a successful Commit

	if _, err := tx.Exec(`
		INSERT INTO access_grant (id, new_no, role, can_manage_access, granted_by, granted_at)
		VALUES ($1,$2,$3,$4,$5,$6)
		ON CONFLICT (new_no) DO UPDATE
		SET role = EXCLUDED.role,
		    can_manage_access = EXCLUDED.can_manage_access,
		    granted_by = EXCLUDED.granted_by,
		    granted_at = EXCLUDED.granted_at`,
		uuid.NewString(), targetNo, role, canManage, actorNo, now); err != nil {
		return nil, err
	}
	detail := grantDetail(role, canManage)
	target := targetNo
	if err := activity.Write(tx, now, actorNo, activity.Grant, &target, &detail); err != nil {
		return nil, err
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	return s.Get(targetNo)
}

// Delete removes a grant addressed by its opaque id and records a REVOKE in the
// unified activity log, keyed by the grant's 고유번호. Returns false when no grant
// has that id (the handler maps that to 404). The audit target is the resolved
// 고유번호 so the accountability record stays meaningful even though the URL never
// carried it.
func (s *Service) Delete(actorNo, id string) (bool, error) {
	g, err := s.GetByID(id)
	if err != nil {
		return false, err
	}
	if g == nil {
		return false, nil
	}

	now := s.st.Now()
	tx, err := s.st.DB.Begin()
	if err != nil {
		return false, err
	}
	defer tx.Rollback() //nolint:errcheck

	if _, err := tx.Exec(`DELETE FROM access_grant WHERE id = $1`, id); err != nil {
		return false, err
	}
	target := g.NewNo
	if err := activity.Write(tx, now, actorNo, activity.Revoke, &target, nil); err != nil {
		return false, err
	}
	return true, tx.Commit()
}

// grantDetail is a compact audit note for a grant (role + delegate marker).
func grantDetail(role string, canManage bool) string {
	if canManage {
		return role + "+MANAGE"
	}
	return role
}

// ConfirmLogin marks a granted newNo as confirmed on their first login, clearing
// the 미확인 state. No-op when no grant exists or it is already confirmed. Stores
// only the timestamp — never the member's name.
func (s *Service) ConfirmLogin(newNo string) {
	_, _ = s.st.DB.Exec(
		`UPDATE access_grant SET confirmed_at = $1
		 WHERE new_no = $2 AND confirmed_at IS NULL`, s.st.Now(), newNo)
}
