package access

import (
	"encoding/json"
	"net/http"

	"zcsadmin/internal/httpx"
	"zcsadmin/internal/i18n"
	"zcsadmin/internal/session"
)

// Handlers serve the 고유번호 접근 관리 page and the audit log. Gating is applied
// by the guard at registration time (Manage for grants, Super for audit).
//
// 고유번호 never travels in a URL: grants are created/updated by a body field and
// addressed for deletion by their opaque id (P-6, privacy review).
type Handlers struct{ svc *Service }

func NewHandlers(svc *Service) *Handlers { return &Handlers{svc: svc} }

func grantDTO(g *Grant) map[string]any {
	return map[string]any{
		"id":              g.ID, // opaque handle for DELETE
		"newNo":           g.NewNo,
		"role":            g.Role,
		"canManageAccess": g.CanManageAccess,
		"grantedBy":       g.GrantedBy,
		"grantedAt":       g.GrantedAt,
		"confirmed":       g.ConfirmedAt != nil,
		"confirmedAt":     g.ConfirmedAt,
	}
}

// List: GET /api/access/grants → { "items": [...] }. 고유번호 shown in full
// (public working key); 미확인 surfaced via the confirmed flag (AC-3.5).
func (h *Handlers) List(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	grants, err := h.svc.List()
	if err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	items := make([]map[string]any, 0, len(grants))
	for i := range grants {
		items = append(items, grantDTO(&grants[i]))
	}
	httpx.JSON(w, http.StatusOK, map[string]any{"items": items})
}

// Upsert: PUT /api/access/grants → idempotent grant create/update (AC-3.3).
// Body: { "newNo": "...", "role"?: "STAFF", "canManageAccess"?: false }.
// 고유번호 is carried in the body, never the URL.
//
// Escalation guard: only a super-admin may set canManageAccess=true, so a
// delegate cannot mint further delegates. Documented extension point.
func (h *Handlers) Upsert(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	var in struct {
		NewNo           string `json:"newNo"`
		Role            string `json:"role"`
		CanManageAccess bool   `json:"canManageAccess"`
	}
	if err := json.NewDecoder(r.Body).Decode(&in); err != nil || !ValidNewNo(in.NewNo) {
		httpx.Error(w, http.StatusBadRequest, httpx.CodeBadRequest, i18n.T("error.bad_request"))
		return
	}
	if in.Role == "" {
		in.Role = RoleStaff
	}
	if in.Role != RoleStaff {
		httpx.Error(w, http.StatusBadRequest, httpx.CodeBadRequest, i18n.T("error.bad_request"))
		return
	}
	if in.CanManageAccess && !p.Super {
		httpx.Error(w, http.StatusForbidden, httpx.CodeForbidden, i18n.T("error.forbidden"))
		return
	}

	g, err := h.svc.Upsert(p.NewNo, in.NewNo, in.Role, in.CanManageAccess)
	if err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	httpx.JSON(w, http.StatusOK, grantDTO(g))
}

// Delete: DELETE /api/access/grants/{id} → revoke by opaque id → 204
// (404 if the id is unknown). The target hits noperm on their next request.
func (h *Handlers) Delete(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	id := r.PathValue("id")
	if id == "" {
		httpx.Error(w, http.StatusBadRequest, httpx.CodeBadRequest, i18n.T("error.bad_request"))
		return
	}
	removed, err := h.svc.Delete(p.NewNo, id)
	if err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	if !removed {
		httpx.Error(w, http.StatusNotFound, httpx.CodeNotFound, i18n.T("error.not_found"))
		return
	}
	httpx.JSON(w, http.StatusNoContent, nil)
}
