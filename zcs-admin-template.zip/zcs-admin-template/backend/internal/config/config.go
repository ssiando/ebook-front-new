// Package config loads runtime configuration from the environment.
//
// Env names are identical to the zion-login canon so the same .env works
// across stacks. There is no JWT_SECRET — the session token IS the ZAuth
// access_token (never a self-issued JWT). A tiny .env loader is included for
// local development; real environment variables always win over .env values.
package config

import (
	"bufio"
	"log"
	"os"
	"strconv"
	"strings"
)

type Config struct {
	// ZAuth OAuth2. client_id is the REST API Key — there is NO client_secret.
	OAuth2ClientID       string
	OAuth2AuthURL        string // {AUTH_URL}/oauth/authorize  (path is /oauth/, NOT /oauth2/)
	OAuth2TokenURL       string // {AUTH_URL}/oauth/token
	OAuth2UserinfoURL    string // {API_URL}/api/auth/v3_0/me
	OAuth2ValidateURL    string // {API_URL}/api/auth/v1_0/validate — session revalidation
	OAuth2AuthoritiesURL string // {API_URL}/api/external/v1/user-authorities — DO_EVERYTHING detection only
	OAuth2RedirectURI    string // unset → auto-detected from request headers

	// Max age of a session's last successful ZAuth validation before the next
	// request must revalidate the token (fail-closed on any non-valid outcome).
	SessionRevalidateSeconds int

	SessionIdleMinutes      int
	SessionIdleSeconds      *int // test override — wins when set
	SessionHeartbeatSeconds int
	SessionPurgeDays        int

	// AuditRetentionDays bounds how long grant/revoke audit rows are kept. Purging
	// is deliberate (the `purge` subcommand / an external cron), never auto on
	// startup — audit is accountability data. 0 disables (keep forever).
	AuditRetentionDays int

	// QR issuance owns its own HMAC secret (no external WAO signing service).
	QRSecret      string
	QRScanBaseURL string // public https base embedded in the scan URL

	DatabaseURL string
	CORSOrigins []string // first entry = the OAuth callback frontend origin
	FrontendURL string   // where the callback redirects with the token

	// DevBypassAuth enables POST /api/auth/test-login for local development
	// before 총회 registration. It does NOT disable auth. Never true in production.
	DevBypassAuth bool
}

func Load() *Config {
	loadDotEnv(".env")

	c := &Config{
		OAuth2ClientID:       env("OAUTH2_CLIENT_ID", ""),
		OAuth2AuthURL:        env("OAUTH2_AUTH_URL", ""),
		OAuth2TokenURL:       env("OAUTH2_TOKEN_URL", ""),
		OAuth2UserinfoURL:    env("OAUTH2_USERINFO_URL", ""),
		OAuth2ValidateURL:    env("OAUTH2_VALIDATE_URL", ""),
		OAuth2AuthoritiesURL: env("OAUTH2_AUTHORITIES_URL", ""),
		OAuth2RedirectURI:    env("OAUTH2_REDIRECT_URI", ""),

		SessionRevalidateSeconds: envInt("SESSION_REVALIDATE_SECONDS", 300),

		SessionIdleMinutes:      envInt("SESSION_IDLE_MINUTES", 30),
		SessionHeartbeatSeconds: envInt("SESSION_HEARTBEAT_SECONDS", 60),
		SessionPurgeDays:        envInt("SESSION_PURGE_DAYS", 90),
		AuditRetentionDays:      envInt("AUDIT_RETENTION_DAYS", 365),

		QRSecret:      env("QR_SECRET", ""),
		QRScanBaseURL: env("QR_SCAN_BASE_URL", ""),

		DatabaseURL:   env("DATABASE_URL", ""),
		CORSOrigins:   splitCSV(env("CORS_ORIGINS", "")),
		FrontendURL:   env("FRONTEND_URL", ""),
		DevBypassAuth: env("DEV_BYPASS_AUTH", "false") == "true",
	}

	if v, ok := os.LookupEnv("SESSION_IDLE_SECONDS"); ok {
		if n, err := strconv.Atoi(v); err == nil {
			c.SessionIdleSeconds = &n
		}
	}

	// Frontend URL defaults to the first CORS origin (the callback target).
	if c.FrontendURL == "" && len(c.CORSOrigins) > 0 {
		c.FrontendURL = c.CORSOrigins[0]
	}

	// A configured ZAuth app with no validate URL would silently skip session
	// revalidation — refuse to boot. Both empty = pure dev/test-login posture.
	if c.OAuth2ClientID != "" && c.OAuth2ValidateURL == "" {
		log.Fatal("OAUTH2_VALIDATE_URL is required when OAUTH2_CLIENT_ID is set " +
			"(set it to {API_URL}/api/auth/v1_0/validate)")
	}
	return c
}

// IdleWindowSeconds is the effective idle window, honoring the test override.
func (c *Config) IdleWindowSeconds() int {
	if c.SessionIdleSeconds != nil {
		return *c.SessionIdleSeconds
	}
	return c.SessionIdleMinutes * 60
}

func env(key, def string) string {
	if v, ok := os.LookupEnv(key); ok && v != "" {
		return v
	}
	return def
}

func envInt(key string, def int) int {
	if v, ok := os.LookupEnv(key); ok {
		if n, err := strconv.Atoi(v); err == nil {
			return n
		}
	}
	return def
}

func splitCSV(s string) []string {
	if s == "" {
		return nil
	}
	parts := strings.Split(s, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		if p = strings.TrimSpace(p); p != "" {
			out = append(out, p)
		}
	}
	return out
}

// loadDotEnv reads KEY=VALUE lines from path into the process environment,
// skipping keys already set in the real environment.
func loadDotEnv(path string) {
	f, err := os.Open(path)
	if err != nil {
		return
	}
	defer f.Close()

	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, val, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key = strings.TrimSpace(key)
		val = strings.Trim(strings.TrimSpace(val), `"'`)
		if _, exists := os.LookupEnv(key); !exists {
			_ = os.Setenv(key, val)
		}
	}
}
