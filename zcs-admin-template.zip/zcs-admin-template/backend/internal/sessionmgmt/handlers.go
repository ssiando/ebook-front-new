// Package sessionmgmt serves the 세션 관리 screen: list active sessions and force
// a logout. Both routes are SUPER-ADMIN ONLY (gated by the guard at
// registration). Sessions are addressed by their opaque id — never by 고유번호 —
// and tokens are never exposed.
package sessionmgmt

import (
	"net/http"

	"zcsadmin/internal/activity"
	"zcsadmin/internal/httpx"
	"zcsadmin/internal/i18n"
	"zcsadmin/internal/session"
)

type Handlers struct {
	sess *session.Service
	act  *activity.Service
}

func New(sess *session.Service, act *activity.Service) *Handlers {
	return &Handlers{sess: sess, act: act}
}

// List: GET /api/sessions → active sessions, newest activity first.
//
//	{ "items": [ {id, newNo, name, loginAt, lastSeenAt, idleExpiresAt, isCurrent} ] }
//
// newNo/name are shown because this endpoint is super-admin only. Tokens are
// never included. isCurrent marks the caller's own session (frontend confirms
// before self-revoke).
func (h *Handlers) List(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	rows, err := h.sess.ListActive()
	if err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	items := make([]map[string]any, 0, len(rows))
	for i := range rows {
		row := rows[i]
		items = append(items, map[string]any{
			"id":            row.ID, // opaque handle for DELETE
			"newNo":         row.UserNewNo,
			"name":          row.UserName,
			"loginAt":       row.CreatedAt,
			"lastSeenAt":    row.LastSeenAt,
			"idleExpiresAt": h.sess.IdleExpiresAt(row.LastSeenAt),
			"isCurrent":     row.ID == p.SID,
		})
	}
	httpx.JSON(w, http.StatusOK, map[string]any{"items": items})
}

// Revoke: DELETE /api/sessions/{id} → force-logout a session by opaque id.
// 404 if the id is unknown. Self-revoke is allowed (the frontend confirms).
func (h *Handlers) Revoke(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	id := r.PathValue("id")
	if id == "" {
		httpx.Error(w, http.StatusBadRequest, httpx.CodeBadRequest, i18n.T("error.bad_request"))
		return
	}
	row, err := h.sess.LoadRow(id)
	if err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	if row == nil {
		httpx.Error(w, http.StatusNotFound, httpx.CodeNotFound, i18n.T("error.not_found"))
		return
	}
	if err := h.sess.Revoke(id, p.NewNo); err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	h.act.Log(p.NewNo, activity.SessionRevoke, &id)
	httpx.JSON(w, http.StatusNoContent, nil)
}
