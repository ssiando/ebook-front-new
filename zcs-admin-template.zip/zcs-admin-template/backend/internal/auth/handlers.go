// Package auth wires the Zion 로그인 flow: login redirect, callback (code →
// token → /me + super-admin detection → session), plus /me, logout, heartbeat,
// and the dev-only test-login.
//
// Fail-closed rule (AC-1.3): if EITHER /me or the authorities lookup fails, the
// login fails entirely — the user is never treated as super-admin or as granted
// staff. We redirect to the login screen with an error code; no session is made.
package auth

import (
	"crypto/rand"
	"encoding/hex"
	"log"
	"net/http"

	"zcsadmin/internal/access"
	"zcsadmin/internal/activity"
	"zcsadmin/internal/config"
	"zcsadmin/internal/httpx"
	"zcsadmin/internal/i18n"
	"zcsadmin/internal/session"
	"zcsadmin/internal/zauth"
)

const stateCookie = "zcs_oauth_state"

type Handlers struct {
	cfg      *config.Config
	zauth    *zauth.Client
	sess     *session.Service
	access   *access.Service
	activity *activity.Service
}

func New(cfg *config.Config, z *zauth.Client, s *session.Service, a *access.Service, act *activity.Service) *Handlers {
	return &Handlers{cfg: cfg, zauth: z, sess: s, access: a, activity: act}
}

// Login: GET /api/auth/login → set a one-shot state cookie → 302 to ZAuth.
func (h *Handlers) Login(w http.ResponseWriter, r *http.Request) {
	redirectURI := h.redirectURI(r)
	state := randomHex(32)

	http.SetCookie(w, &http.Cookie{
		Name: stateCookie, Value: state,
		Path: "/api/auth", MaxAge: 300, HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
		Secure:   isHTTPS(redirectURI),
	})
	http.Redirect(w, r, h.zauth.AuthorizeURL(redirectURI, state), http.StatusFound)
}

// Callback: GET /api/auth/callback?code&state → validate state → exchange →
// /me + super detection → session → 302 to the frontend with the token.
func (h *Handlers) Callback(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie(stateCookie)
	if err != nil || cookie.Value == "" || cookie.Value != r.URL.Query().Get("state") {
		h.failLogin(w, r, "state_mismatch")
		return
	}
	h.clearStateCookie(w)

	code := r.URL.Query().Get("code")
	if code == "" {
		h.failLogin(w, r, "oauth_failed")
		return
	}

	ctx := r.Context()
	token, err := h.zauth.ExchangeCode(ctx, code, h.redirectURI(r))
	if err != nil {
		log.Printf("login failed: token exchange") // no code/token in logs
		h.failLogin(w, r, "oauth_failed")
		return
	}

	member, err := h.zauth.FetchMe(ctx, token)
	if err != nil {
		log.Printf("login failed: /me lookup")
		h.failLogin(w, r, "oauth_failed")
		return
	}
	// Fail-closed: an authorities failure aborts the login (AC-1.3) — we never
	// proceed unsure whether the user is super-admin.
	super, err := h.zauth.IsSuperAdmin(ctx, token)
	if err != nil {
		log.Printf("login failed: authorities lookup")
		h.failLogin(w, r, "oauth_failed")
		return
	}
	p := session.Principal{
		NewNo: member.NewNo, Name: member.Name, Tribe: member.Tribe,
		Church: member.Church, Duty: member.Duty, Super: super,
	}
	// The access_token IS the session token (zion-login canon): the session row
	// stores only its SHA-256 hash, and the raw token goes back to the frontend.
	if _, err := h.sess.Create(p, token, r.UserAgent(), clientIP(r)); err != nil {
		log.Printf("login failed: session create: %v", err)
		h.failLogin(w, r, "oauth_failed")
		return
	}
	h.access.ConfirmLogin(member.NewNo) // clears 미확인 on first login
	h.activity.Log(member.NewNo, activity.Login, nil)

	http.Redirect(w, r,
		h.cfg.FrontendURL+"/#/auth/callback?token="+token, http.StatusFound)
}

// Me: GET /api/auth/me → own record (full newNo) + access + session block.
func (h *Handlers) Me(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	decision, err := h.access.Evaluate(p.NewNo, p.Super)
	if err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	row, err := h.sess.LoadRow(p.SID)
	if err != nil || row == nil {
		httpx.Error(w, http.StatusUnauthorized, httpx.CodeSessionRevoked, i18n.T("error.session_revoked"))
		return
	}

	httpx.JSON(w, http.StatusOK, map[string]any{
		"user": map[string]any{
			"newNo":  p.NewNo, // own record: full, never masked
			"name":   p.Name,
			"tribe":  p.Tribe,
			"church": p.Church,
			"duty":   p.Duty,
		},
		"access": map[string]any{
			"super":           decision.Super,
			"hasAccess":       decision.HasAccess,
			"canManageAccess": decision.CanManageAccess,
		},
		"session":          h.sessionBlock(row),
		"heartbeatSeconds": h.cfg.SessionHeartbeatSeconds,
	})
}

// sessionBlock is the shared session serialization used by /me and heartbeat.
// idleExpiresAt is computed from lastSeenAt (never stored), so after the request
// pipeline has Touched the session it reflects the post-activity idle deadline.
func (h *Handlers) sessionBlock(row *session.Row) map[string]any {
	return map[string]any{
		"id":            row.ID,
		"createdAt":     row.CreatedAt,
		"lastSeenAt":    row.LastSeenAt,
		"expiresAt":     row.ExpiresAt,
		"idleExpiresAt": h.sess.IdleExpiresAt(row.LastSeenAt),
		"usageSeconds":  row.UsageSeconds,
	}
}

// Logout: POST /api/auth/logout → revoke the session → 204.
func (h *Handlers) Logout(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	if err := h.sess.Revoke(p.SID, p.NewNo); err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	h.activity.Log(p.NewNo, activity.Logout, nil)
	httpx.JSON(w, http.StatusNoContent, nil)
}

// Heartbeat: POST /api/sessions/heartbeat → the cheapest authed request. The
// pipeline already Touched the session before this runs, so the returned
// lastSeenAt/idleExpiresAt are the post-activity values — the frontend uses them
// to reset its idle auto-logout countdown.
func (h *Handlers) Heartbeat(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	row, err := h.sess.LoadRow(p.SID)
	if err != nil || row == nil {
		httpx.Error(w, http.StatusUnauthorized, httpx.CodeSessionRevoked, i18n.T("error.session_revoked"))
		return
	}
	httpx.JSON(w, http.StatusOK, map[string]any{"session": h.sessionBlock(row)})
}

func (h *Handlers) redirectURI(r *http.Request) string {
	if h.cfg.OAuth2RedirectURI != "" {
		return h.cfg.OAuth2RedirectURI
	}
	proto := r.Header.Get("X-Forwarded-Proto") // the proxy MUST forward Proto + Host
	if proto == "" {
		if r.TLS != nil {
			proto = "https"
		} else {
			proto = "http"
		}
	}
	return proto + "://" + r.Host + "/api/auth/callback"
}

func (h *Handlers) failLogin(w http.ResponseWriter, r *http.Request, code string) {
	http.Redirect(w, r, h.cfg.FrontendURL+"/#/login?error="+code, http.StatusFound)
}

func (h *Handlers) clearStateCookie(w http.ResponseWriter) {
	http.SetCookie(w, &http.Cookie{
		Name: stateCookie, Value: "", Path: "/api/auth", MaxAge: -1, HttpOnly: true,
	})
}

func randomHex(n int) string {
	b := make([]byte, n)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func isHTTPS(u string) bool { return len(u) >= 8 && u[:8] == "https://" }

func clientIP(r *http.Request) string {
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
		if i := indexByte(xff, ','); i >= 0 {
			return xff[:i]
		}
		return xff
	}
	return r.RemoteAddr
}

func indexByte(s string, b byte) int {
	for i := 0; i < len(s); i++ {
		if s[i] == b {
			return i
		}
	}
	return -1
}
