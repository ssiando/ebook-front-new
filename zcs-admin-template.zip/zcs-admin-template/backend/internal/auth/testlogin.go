package auth

import (
	"encoding/json"
	"net/http"

	"zcsadmin/internal/activity"
	"zcsadmin/internal/httpx"
	"zcsadmin/internal/i18n"
	"zcsadmin/internal/session"
)

// TestLogin mints an opaque random dev token and a real session for a chosen
// identity, WITHOUT calling Zion 로그인. Dev sessions are marked is_dev, so they
// skip ZAuth revalidation. It exists only to let a fork run locally before 총회
// registration is complete. It is registered only when DEV_BYPASS_AUTH=true;
// otherwise the route is absent and a request 404s "as if unregistered". Never
// enable it in production.
//
// Request:  POST /api/auth/test-login  { "newNo": "...", "name": "...", "super": false }
// Response: 200 { "token": "dev-<64 hex>" }
func (h *Handlers) TestLogin(w http.ResponseWriter, r *http.Request) {
	var in struct {
		NewNo string `json:"newNo"`
		Name  string `json:"name"`
		Super bool   `json:"super"`
	}
	if err := json.NewDecoder(r.Body).Decode(&in); err != nil || in.NewNo == "" {
		httpx.Error(w, http.StatusBadRequest, httpx.CodeBadRequest, i18n.T("error.bad_request"))
		return
	}

	token := "dev-" + randomHex(32)
	p := session.Principal{NewNo: in.NewNo, Name: in.Name, Super: in.Super}
	_, err := h.sess.CreateDev(p, token, r.UserAgent(), clientIP(r))
	if err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	h.access.ConfirmLogin(in.NewNo)
	h.activity.Log(in.NewNo, activity.Login, nil)
	httpx.JSON(w, http.StatusOK, map[string]any{"token": token})
}
