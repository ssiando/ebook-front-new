// Package store owns the PostgreSQL connection and schema migrations.
//
// Migrations are plain .sql files embedded into the binary and applied at every
// startup (the alembic-upgrade-head analog). Each file runs once, tracked in
// schema_migrations, so startup is idempotent.
package store

import (
	"database/sql"
	"embed"
	"fmt"
	"log"
	"sort"
	"time"

	_ "github.com/jackc/pgx/v5/stdlib" // registers the "pgx" database/sql driver
)

//go:embed migrations/*.sql
var migrationFS embed.FS

type Store struct {
	DB *sql.DB
}

func Open(databaseURL string) (*Store, error) {
	db, err := sql.Open("pgx", databaseURL)
	if err != nil {
		return nil, fmt.Errorf("open db: %w", err)
	}
	db.SetMaxOpenConns(10)
	db.SetMaxIdleConns(5)
	db.SetConnMaxLifetime(30 * time.Minute)
	if err := db.Ping(); err != nil {
		return nil, fmt.Errorf("ping db: %w", err)
	}
	return &Store{DB: db}, nil
}

func (s *Store) Close() error { return s.DB.Close() }

// Now returns the canonical app time: UTC, truncated to milliseconds so DB and
// JSON representations stay identical.
func (s *Store) Now() time.Time {
	return time.Now().UTC().Truncate(time.Millisecond)
}

// Migrate applies every embedded migration that has not run yet, in filename
// order. Safe to call on every boot.
func (s *Store) Migrate() error {
	if _, err := s.DB.Exec(`
		CREATE TABLE IF NOT EXISTS schema_migrations (
			name       TEXT PRIMARY KEY,
			applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
		)`); err != nil {
		return fmt.Errorf("create schema_migrations: %w", err)
	}

	entries, err := migrationFS.ReadDir("migrations")
	if err != nil {
		return err
	}
	names := make([]string, 0, len(entries))
	for _, e := range entries {
		names = append(names, e.Name())
	}
	sort.Strings(names)

	for _, name := range names {
		var exists bool
		if err := s.DB.QueryRow(
			`SELECT EXISTS(SELECT 1 FROM schema_migrations WHERE name = $1)`, name,
		).Scan(&exists); err != nil {
			return err
		}
		if exists {
			continue
		}
		sqlBytes, err := migrationFS.ReadFile("migrations/" + name)
		if err != nil {
			return err
		}
		if _, err := s.DB.Exec(string(sqlBytes)); err != nil {
			return fmt.Errorf("apply migration %s: %w", name, err)
		}
		if _, err := s.DB.Exec(
			`INSERT INTO schema_migrations (name) VALUES ($1)`, name,
		); err != nil {
			return err
		}
		log.Printf("migration applied: %s", name)
	}
	return nil
}

// PurgeRevokedSessions deletes sessions revoked more than purgeDays ago
// (storage limitation, PIPA Art. 21 / GDPR Art. 5(1)(e)). purgeDays <= 0 is a
// no-op. Returns the number of rows removed.
func (s *Store) PurgeRevokedSessions(purgeDays int) (int64, error) {
	if purgeDays <= 0 {
		return 0, nil
	}
	cutoff := s.Now().AddDate(0, 0, -purgeDays)
	res, err := s.DB.Exec(
		`DELETE FROM sessions WHERE revoked_at IS NOT NULL AND revoked_at < $1`, cutoff)
	if err != nil {
		return 0, err
	}
	return res.RowsAffected()
}

// PurgeActivityLog deletes activity-log rows older than retentionDays (storage
// limitation under the documented accountability retention bound). retentionDays
// <= 0 is a no-op (keep forever). Called deliberately via the `purge` subcommand,
// never automatically at startup. Returns the number of rows removed.
func (s *Store) PurgeActivityLog(retentionDays int) (int64, error) {
	if retentionDays <= 0 {
		return 0, nil
	}
	cutoff := s.Now().AddDate(0, 0, -retentionDays)
	res, err := s.DB.Exec(`DELETE FROM activity_log WHERE created_at < $1`, cutoff)
	if err != nil {
		return 0, err
	}
	return res.RowsAffected()
}
