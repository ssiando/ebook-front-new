-- Initial schema for the ZCS admin template.
--
-- Privacy posture: the ONLY persisted member field is 고유번호 (newNo), the public
-- working key, plus session-lifetime display snapshots (name/tribe/church/duty)
-- that are purged with the session. 주민번호(idNumber) is never touched.

-- Revocable server-side sessions (zion-login canon): the session token IS the
-- ZAuth access_token; rows are keyed by token_hash = SHA-256(access_token) and
-- the raw token is never stored or logged. The uuid id stays as the row handle
-- for the 세션 관리 screen and revoke-by-id.
-- No FK to a users table: this template persists no member-data snapshot.
CREATE TABLE IF NOT EXISTS sessions (
    id                VARCHAR(36) PRIMARY KEY,        -- uuid, opaque row handle
    token_hash        VARCHAR(64) NOT NULL,           -- hex SHA-256 of the bearer token
    user_new_no       VARCHAR(20) NOT NULL,           -- 고유번호 of the session owner
    is_super          BOOLEAN     NOT NULL DEFAULT FALSE, -- super-admin snapshot at login
    is_dev            BOOLEAN     NOT NULL DEFAULT FALSE, -- test-login session: skips ZAuth revalidation
    tribe             VARCHAR(200),                   -- display snapshots, session-lifetime only
    church            VARCHAR(200),
    duty              VARCHAR(200),
    user_agent        VARCHAR(400),
    ip                VARCHAR(64),
    created_at        TIMESTAMPTZ NOT NULL,
    last_seen_at      TIMESTAMPTZ NOT NULL,
    last_validated_at TIMESTAMPTZ NOT NULL,           -- last successful ZAuth revalidation
    expires_at        TIMESTAMPTZ NOT NULL,           -- absolute expiry (= token exp claim)
    revoked_at        TIMESTAMPTZ,                    -- soft revoke
    revoked_by        VARCHAR(20),                    -- actor newNo OR marker 'idle'/'expired'/'revalidate'
    usage_seconds     BIGINT      NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_sessions_token_hash ON sessions (token_hash);
CREATE INDEX IF NOT EXISTS ix_sessions_user_new_no ON sessions (user_new_no);

-- Local access grants. 고유번호 is the unique business key (UNIQUE new_no), but
-- rows are ADDRESSED in URLs by an opaque id so 고유번호 never travels in a path
-- or query string (it stays in request bodies / logs-free). The single local
-- role is 'STAFF' (운영자); can_manage_access marks the access-management
-- delegate. Super-admin is NEVER stored here (it comes from the ZAuth authority)
-- — by design, so it cannot be revoked from this table and the bootstrap account
-- can never lock out.
CREATE TABLE IF NOT EXISTS access_grant (
    id                VARCHAR(36)  PRIMARY KEY,   -- opaque uuid, used in URLs
    new_no            VARCHAR(20)  NOT NULL UNIQUE,
    role              VARCHAR(40)  NOT NULL DEFAULT 'STAFF',
    can_manage_access BOOLEAN      NOT NULL DEFAULT FALSE,
    granted_by        VARCHAR(20)  NOT NULL,      -- actor newNo
    granted_at        TIMESTAMPTZ  NOT NULL,
    -- Set on that person's first successful login. NULL = 미확인 (granted ahead
    -- of first login, AC-3.5). We store only the timestamp, never their name.
    confirmed_at      TIMESTAMPTZ
);

-- Append-only audit of grant/revoke actions. Kept indefinitely as an
-- accountability record (PIPA Art. 29 / GDPR Art. 30). Readable by super-admin only.
CREATE TABLE IF NOT EXISTS access_audit (
    id                BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    actor_no          VARCHAR(20) NOT NULL,       -- who performed the action
    target_no         VARCHAR(20) NOT NULL,       -- the affected 고유번호
    action            VARCHAR(20) NOT NULL,       -- GRANT | REVOKE
    role              VARCHAR(40),
    can_manage_access BOOLEAN,
    created_at        TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_access_audit_created_at ON access_audit (created_at DESC);

-- Worked example resource.
--
-- author_no (고유번호) is kept for accountability ONLY and is never exposed on the
-- notices API. author_name is a point-in-time snapshot captured from the author's
-- own session at creation. The API shows the snapshot, so the notices feed never
-- broadcasts the 고유번호 working key (privacy P-3).
--
-- Deliberate, scoped deviation from "name never persisted": a name is the
-- plaintext directory tier (lowest sensitivity) and a point-in-time authorship
-- record is the lesser evil vs. exposing 고유번호 to every reader. Minimization
-- still holds elsewhere (grants/sessions persist only 고유번호).
CREATE TABLE IF NOT EXISTS notice (
    id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    title       VARCHAR(300) NOT NULL,
    body        TEXT         NOT NULL,
    author_no   VARCHAR(20)  NOT NULL,   -- internal accountability key, never on the API
    author_name VARCHAR(200) NOT NULL,   -- snapshot at creation, shown on the API
    created_at  TIMESTAMPTZ  NOT NULL,
    updated_at  TIMESTAMPTZ  NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_notice_created_at ON notice (created_at DESC);
