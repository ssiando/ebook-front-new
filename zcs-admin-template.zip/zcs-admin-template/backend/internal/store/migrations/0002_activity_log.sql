-- Change request 02: unified activity log + session name snapshot.
--
-- Design: ONE activity_log table is the single source of truth for every audited
-- action (LOGIN, LOGOUT, NOTICE_CREATE/UPDATE/DELETE, GRANT, REVOKE,
-- SESSION_REVOKE). It replaces the access-only access_audit table: existing rows
-- are copied over, then access_audit is dropped. One table, one writer, one
-- retention bound (AUDIT_RETENTION_DAYS), one query.

-- Name snapshot for the 세션 관리 screen, so super-admin sees who is logged in by
-- name + 고유번호. Session-lifetime only (purged with the session) — same scoped
-- "name snapshot" exception already accepted for notices (P-3). DEFAULT '' covers
-- any pre-existing rows.
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS user_name VARCHAR(200) NOT NULL DEFAULT '';

CREATE TABLE IF NOT EXISTS activity_log (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    actor_no   VARCHAR(20) NOT NULL,   -- who performed the action (고유번호)
    action     VARCHAR(40) NOT NULL,   -- LOGIN | LOGOUT | NOTICE_* | GRANT | REVOKE | SESSION_REVOKE
    target     VARCHAR(64),            -- opaque id (session/notice) OR target 고유번호; nullable
    detail     VARCHAR(200),           -- small context (e.g. grant role); no PII beyond target
    created_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_activity_log_created_at ON activity_log (created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS ix_activity_log_action ON activity_log (action);

-- Preserve existing grant/revoke history under the unified schema.
INSERT INTO activity_log (actor_no, action, target, detail, created_at)
SELECT actor_no, action, target_no, role, created_at FROM access_audit;

DROP TABLE access_audit;
