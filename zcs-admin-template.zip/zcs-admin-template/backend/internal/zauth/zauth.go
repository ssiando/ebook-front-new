// Package zauth talks to the Zion auth platform (OAuth2 + member data +
// authorities). Verified-flow values only — never change them:
//
//   - OAuth path is /oauth/ (NOT /oauth2/), even though env names are OAUTH2_*.
//   - client_id is the REST API Key; there is NO client_secret.
//   - The /me properties request uses the SINGULAR ORGANIZATION_WITH_DUTY;
//     the response key is the PLURAL organizationWithDuties (known asymmetry).
//   - Every response uses the {success, data, error, traceId} envelope —
//     always check success (HTTP 200 with success=false is a real failure).
//
// This template is Bearer-REST-only: it makes no server-to-server (Admin Key)
// calls, so member/authority data refreshes only happen during a user login.
package zauth

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"time"

	"zcsadmin/internal/config"
)

// Data minimization: request only what login + super-admin detection need.
const properties = "NAME,NEW_NO,ORGANIZATION_PATH,ORGANIZATION_WITH_DUTY"

// errZAuth wraps every failure; it never carries tokens, codes, or member data
// (those must not reach logs).
var errZAuth = errors.New("zauth call failed")

type Client struct {
	cfg  *config.Config
	http *http.Client
}

func New(cfg *config.Config) *Client {
	return &Client{cfg: cfg, http: &http.Client{Timeout: 10 * time.Second}}
}

// Member is the reduced /me result this template uses for display (session-only,
// never persisted) plus the newNo key.
type Member struct {
	NewNo  string
	Name   string
	Tribe  string
	Church string
	Duty   string
}

// AuthorizeURL builds the /oauth/authorize redirect.
func (c *Client) AuthorizeURL(redirectURI, state string) string {
	q := url.Values{
		"client_id":     {c.cfg.OAuth2ClientID},
		"redirect_uri":  {redirectURI},
		"response_type": {"code"},
		"state":         {state},
		"encode_state":  {"true"},
	}
	return c.cfg.OAuth2AuthURL + "?" + q.Encode()
}

// ExchangeCode swaps the authorization code for an access_token. No client_secret.
func (c *Client) ExchangeCode(ctx context.Context, code, redirectURI string) (string, error) {
	form := url.Values{
		"grant_type":   {"authorization_code"},
		"client_id":    {c.cfg.OAuth2ClientID},
		"redirect_uri": {redirectURI},
		"code":         {code},
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost,
		c.cfg.OAuth2TokenURL, strings.NewReader(form.Encode()))
	if err != nil {
		return "", errZAuth
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := c.http.Do(req)
	if err != nil {
		return "", errZAuth
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return "", errZAuth
	}
	var body struct {
		AccessToken string `json:"access_token"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil || body.AccessToken == "" {
		return "", errZAuth
	}
	return body.AccessToken, nil
}

type envelope struct {
	Success bool            `json:"success"`
	Data    json.RawMessage `json:"data"`
}

type orgDto struct {
	ID    int64  `json:"id"`
	Name  string `json:"name"`
	Type  string `json:"type"`  // ROOT|TRIBE|CHURCH|DEPARTMENT|...
	Level string `json:"level"` // HEAD|TRIBE|CHURCH|ADMIN_DEPARTMENT|NONE
}

// FetchMe reads member data with the access_token (used once, never stored).
func (c *Client) FetchMe(ctx context.Context, accessToken string) (*Member, error) {
	u := c.cfg.OAuth2UserinfoURL + "?properties=" + properties
	var data struct {
		Properties struct {
			Name                   string   `json:"name"`
			NewNo                  string   `json:"newNo"`
			OrganizationPaths      []orgDto `json:"organizationPaths"`
			OrganizationWithDuties []struct {
				Organization orgDto `json:"organization"`
				Duty         struct {
					Name         string `json:"name"`
					PositionName string `json:"positionName"`
				} `json:"duty"`
				Type string `json:"type"` // MEMBER | DUTY
			} `json:"organizationWithDuties"`
		} `json:"properties"`
	}
	if err := c.get(ctx, u, accessToken, &data); err != nil {
		return nil, err
	}
	p := data.Properties
	if p.NewNo == "" {
		return nil, errZAuth
	}

	m := &Member{NewNo: p.NewNo, Name: p.Name}
	for _, org := range p.OrganizationPaths {
		switch org.Type {
		case "TRIBE":
			m.Tribe = org.Name
		case "CHURCH":
			m.Church = org.Name
		}
	}
	for _, owd := range p.OrganizationWithDuties {
		if owd.Type == "DUTY" {
			m.Duty = owd.Duty.PositionName
			if m.Duty == "" {
				m.Duty = owd.Duty.Name
			}
			break
		}
	}
	return m, nil
}

// Validate revalidates a live access_token against the ZAuth validate endpoint
// (zion-login canon §3 session revalidation). Fail-closed: any non-200,
// success=false, decode failure, network error, or valid=false is an error.
// The token never reaches logs.
func (c *Client) Validate(ctx context.Context, accessToken string) error {
	var data struct {
		Valid bool `json:"valid"`
	}
	if err := c.get(ctx, c.cfg.OAuth2ValidateURL, accessToken, &data); err != nil {
		return err
	}
	if !data.Valid {
		return fmt.Errorf("%w: valid=false", errZAuth)
	}
	return nil
}

// superAdminAuthority is ZAuth's canonical global master permission. Constant
// by canon: ZAuth returns DO_EVERYTHING, never the name SUPER_ADMIN.
const superAdminAuthority = "DO_EVERYTHING"

// IsSuperAdmin reports whether DO_EVERYTHING is present in the roleBased
// permissions of global ∪ app; orgBased is ignored entirely. Fail-closed: any
// lookup failure returns (false, error) so the caller refuses the login rather
// than guessing.
//
// This is the ONLY use of user-authorities in this template — ordinary access
// comes from the local 고유번호 grant table, never from ZAuth.
func (c *Client) IsSuperAdmin(ctx context.Context, accessToken string) (bool, error) {
	var data struct {
		Global authoritySet `json:"global"`
		App    authoritySet `json:"app"`
	}
	if err := c.get(ctx, c.cfg.OAuth2AuthoritiesURL, accessToken, &data); err != nil {
		return false, err
	}
	for _, set := range []authoritySet{data.Global, data.App} {
		for _, rb := range set.RoleBased {
			for _, p := range rb.Permissions {
				if p == superAdminAuthority {
					return true, nil
				}
			}
		}
	}
	return false, nil
}

type authoritySet struct {
	RoleBased []struct {
		Permissions []string `json:"permissions"`
	} `json:"roleBased"`
}

// get performs a Bearer GET, unwraps the envelope, and decodes data into out.
func (c *Client) get(ctx context.Context, urlStr, accessToken string, out any) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, urlStr, nil)
	if err != nil {
		return errZAuth
	}
	req.Header.Set("Authorization", "Bearer "+accessToken)

	resp, err := c.http.Do(req)
	if err != nil {
		return fmt.Errorf("%w: request", errZAuth)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("%w: status %d", errZAuth, resp.StatusCode)
	}
	var env envelope
	if err := json.NewDecoder(resp.Body).Decode(&env); err != nil {
		return errZAuth
	}
	if !env.Success {
		return fmt.Errorf("%w: success=false", errZAuth)
	}
	return json.Unmarshal(env.Data, out)
}
