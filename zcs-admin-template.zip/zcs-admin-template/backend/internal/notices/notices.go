// Package notices is the worked example resource. Beginners copy this package
// (model + handlers) and register it under the extension point in main.go to add
// their own feature.
//
// Privacy (P-3): the notices API exposes the author's NAME (a point-in-time
// snapshot captured at creation), never the author's 고유번호. AuthorNo is kept
// internally for accountability only and never leaves this package.
package notices

import (
	"database/sql"
	"errors"
	"time"

	"zcsadmin/internal/store"
)

type Notice struct {
	ID         int64
	Title      string
	Body       string
	AuthorNo   string // internal accountability key — never serialized to the API
	AuthorName string // snapshot at creation — the only author field shown
	CreatedAt  time.Time
	UpdatedAt  time.Time
}

type Service struct{ st *store.Store }

func New(st *store.Store) *Service { return &Service{st: st} }

const columns = `id, title, body, author_no, author_name, created_at, updated_at`

func scan(sc interface{ Scan(...any) error }) (*Notice, error) {
	var n Notice
	err := sc.Scan(&n.ID, &n.Title, &n.Body, &n.AuthorNo, &n.AuthorName,
		&n.CreatedAt, &n.UpdatedAt)
	if err != nil {
		return nil, err
	}
	return &n, nil
}

func (s *Service) List() ([]Notice, error) {
	rows, err := s.st.DB.Query(
		`SELECT ` + columns + ` FROM notice ORDER BY created_at DESC, id DESC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []Notice
	for rows.Next() {
		n, err := scan(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, *n)
	}
	return out, rows.Err()
}

func (s *Service) Get(id int64) (*Notice, error) {
	n, err := scan(s.st.DB.QueryRow(`SELECT `+columns+` FROM notice WHERE id = $1`, id))
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	return n, err
}

// Create stores the notice with the author's 고유번호 (internal) and a snapshot
// of their display name (the value shown on the API).
func (s *Service) Create(title, body, authorNo, authorName string) (*Notice, error) {
	now := s.st.Now()
	var id int64
	if err := s.st.DB.QueryRow(`
		INSERT INTO notice (title, body, author_no, author_name, created_at, updated_at)
		VALUES ($1,$2,$3,$4,$5,$5) RETURNING id`,
		title, body, authorNo, authorName, now).Scan(&id); err != nil {
		return nil, err
	}
	return s.Get(id)
}

// Update edits title/body (the author snapshot is immutable). Returns nil when
// the notice does not exist.
func (s *Service) Update(id int64, title, body string) (*Notice, error) {
	res, err := s.st.DB.Exec(`
		UPDATE notice SET title = $1, body = $2, updated_at = $3 WHERE id = $4`,
		title, body, s.st.Now(), id)
	if err != nil {
		return nil, err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return nil, nil
	}
	return s.Get(id)
}

// Delete reports whether a row was removed.
func (s *Service) Delete(id int64) (bool, error) {
	res, err := s.st.DB.Exec(`DELETE FROM notice WHERE id = $1`, id)
	if err != nil {
		return false, err
	}
	n, _ := res.RowsAffected()
	return n > 0, nil
}
