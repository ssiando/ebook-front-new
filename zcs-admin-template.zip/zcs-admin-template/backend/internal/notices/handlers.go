package notices

import (
	"encoding/json"
	"net/http"
	"strconv"

	"zcsadmin/internal/activity"
	"zcsadmin/internal/httpx"
	"zcsadmin/internal/i18n"
	"zcsadmin/internal/session"
)

type Handlers struct {
	svc *Service
	act *activity.Service
}

func NewHandlers(svc *Service, act *activity.Service) *Handlers {
	return &Handlers{svc: svc, act: act}
}

// dto shapes one notice for the API. It exposes the author NAME snapshot only —
// never the author's 고유번호 (P-3).
func dto(n *Notice) map[string]any {
	return map[string]any{
		"id":         n.ID,
		"title":      n.Title,
		"body":       n.Body,
		"authorName": n.AuthorName,
		"createdAt":  n.CreatedAt,
		"updatedAt":  n.UpdatedAt,
	}
}

// List: GET /api/notices → { "items": [...] }.
func (h *Handlers) List(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	list, err := h.svc.List()
	if err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	items := make([]map[string]any, 0, len(list))
	for i := range list {
		items = append(items, dto(&list[i]))
	}
	httpx.JSON(w, http.StatusOK, map[string]any{"items": items})
}

// Get: GET /api/notices/{id}.
func (h *Handlers) Get(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	id, ok := parseID(w, r)
	if !ok {
		return
	}
	n, err := h.svc.Get(id)
	if err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	if n == nil {
		httpx.Error(w, http.StatusNotFound, httpx.CodeNotFound, i18n.T("error.not_found"))
		return
	}
	httpx.JSON(w, http.StatusOK, dto(n))
}

// Create: POST /api/notices  { "title": "...", "body": "..." }. The author's
// 고유번호 (accountability) and a snapshot of their display name (shown on the
// API) are both captured from the caller's own session.
func (h *Handlers) Create(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	in, ok := decodeBody(w, r)
	if !ok {
		return
	}
	n, err := h.svc.Create(in.Title, in.Body, p.NewNo, p.Name)
	if err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	h.act.Log(p.NewNo, activity.NoticeCreate, noticeTarget(n.ID))
	httpx.JSON(w, http.StatusCreated, dto(n))
}

// Update: PUT /api/notices/{id}. Any granted staff may edit any notice
// (per-author ownership is a documented extension point).
func (h *Handlers) Update(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	id, ok := parseID(w, r)
	if !ok {
		return
	}
	in, ok := decodeBody(w, r)
	if !ok {
		return
	}
	n, err := h.svc.Update(id, in.Title, in.Body)
	if err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	if n == nil {
		httpx.Error(w, http.StatusNotFound, httpx.CodeNotFound, i18n.T("error.not_found"))
		return
	}
	h.act.Log(p.NewNo, activity.NoticeUpdate, noticeTarget(n.ID))
	httpx.JSON(w, http.StatusOK, dto(n))
}

// Delete: DELETE /api/notices/{id} → 204 (404 if it never existed).
func (h *Handlers) Delete(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	id, ok := parseID(w, r)
	if !ok {
		return
	}
	removed, err := h.svc.Delete(id)
	if err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	if !removed {
		httpx.Error(w, http.StatusNotFound, httpx.CodeNotFound, i18n.T("error.not_found"))
		return
	}
	h.act.Log(p.NewNo, activity.NoticeDelete, noticeTarget(id))
	httpx.JSON(w, http.StatusNoContent, nil)
}

// noticeTarget renders a notice id as the audit target string.
func noticeTarget(id int64) *string {
	s := strconv.FormatInt(id, 10)
	return &s
}

type noticeInput struct {
	Title string `json:"title"`
	Body  string `json:"body"`
}

func decodeBody(w http.ResponseWriter, r *http.Request) (noticeInput, bool) {
	var in noticeInput
	if err := json.NewDecoder(r.Body).Decode(&in); err != nil || in.Title == "" {
		httpx.Error(w, http.StatusBadRequest, httpx.CodeBadRequest, i18n.T("error.notice_title"))
		return in, false
	}
	return in, true
}

func parseID(w http.ResponseWriter, r *http.Request) (int64, bool) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		httpx.Error(w, http.StatusBadRequest, httpx.CodeBadRequest, i18n.T("error.bad_request"))
		return 0, false
	}
	return id, true
}
