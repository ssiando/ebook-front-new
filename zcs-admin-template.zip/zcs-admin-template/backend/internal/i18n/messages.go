// Package i18n is the backend's user-facing message catalog. The template ships
// Korean only, but every string is keyed so another locale can be added by
// extending the map (and, later, selecting by the Accept-Language header).
//
// Only user-facing strings live here. Internal/log messages stay in English in
// the code and never reach this catalog.
package i18n

// ko is the Korean message catalog. Keep these human and plain — never expose
// permission codes, internal IDs, or the word "ZAuth" to end users.
var ko = map[string]string{
	"error.unauthorized":    "로그인이 필요합니다.",
	"error.session_revoked": "다른 곳에서 로그아웃되었습니다. 다시 로그인해 주세요.",
	"error.session_expired": "한동안 사용하지 않아 자동으로 로그아웃됐습니다. 다시 로그인해 주세요.",
	"error.forbidden":       "이 화면을 볼 수 있는 권한이 없습니다. 관리자에게 권한을 요청해 주세요.",
	"error.not_found":       "요청하신 정보를 찾을 수 없습니다.",
	"error.bad_request":     "입력한 내용을 다시 확인해 주세요.",
	"error.internal":        "잠시 문제가 생겼습니다. 잠시 후 다시 시도해 주세요.",

	"error.login_failed":    "로그인에 실패했습니다. 다시 시도해 주세요.",
	"error.state_mismatch":  "로그인 요청이 만료됐거나 올바르지 않습니다. 다시 로그인해 주세요.",
	"error.qr_target_empty": "QR을 만들 대상을 입력해 주세요.",
	"error.notice_title":    "제목을 입력해 주세요.",
}

// T returns the Korean message for key, or the key itself if unknown (so a
// missing translation is visible in development rather than silent).
func T(key string) string {
	if msg, ok := ko[key]; ok {
		return msg
	}
	return key
}
