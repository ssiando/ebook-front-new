// Package qr issues 위아원 (WeAreOne) QR codes: a static HMAC-signed payload
// embedded in a plain HTTPS scan URL (the edux model). This template OWNS its
// signing secret (QR_SECRET) — it does not call an external WAO signing service.
//
// Scope: issuance only. The consuming endpoint is a documented pattern, not
// shipped (see CLAUDE.md). Consume rules a fork must honor:
//   - verify the HMAC with QR_SECRET before trusting any field;
//   - treat the scan as single-use and short-TTL (enforced server-side at consume
//     time against your own records — the static QR carries no expiry);
//   - never write the signed payload to logs; strip it from the URL after use;
//   - the WAO auth handoff (wao_authentication → ZAuth) is a further option for
//     identifying the scanning member.
package qr

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"strings"

	"zcsadmin/internal/config"
)

// payload is the signed QR content. Keep it tiny: a version, the reference the
// scan should act on, and the signature. Extend `ref` (or add fields + include
// them in signingString) for richer payloads.
type payload struct {
	V   int    `json:"v"`
	Ref string `json:"ref"`
	Sig string `json:"sig"`
}

type Issuer struct{ cfg *config.Config }

func New(cfg *config.Config) *Issuer { return &Issuer{cfg: cfg} }

// Issue signs ref and returns the base64url token plus the full scan URL to
// render as a QR image. The token is never logged by the caller.
func (i *Issuer) Issue(ref string) (token, scanURL string) {
	p := payload{V: 1, Ref: ref, Sig: i.sign(ref)}
	token = encode(p)
	base := strings.TrimRight(i.cfg.QRScanBaseURL, "/")
	return token, base + "/scan?d=" + token
}

// Verify recomputes the signature for the consume side (documented pattern;
// exported so a fork's consume endpoint can reuse the exact check).
func (i *Issuer) Verify(token string) (ref string, ok bool) {
	p, err := decode(token)
	if err != nil {
		return "", false
	}
	if p.V != 1 || p.Ref == "" {
		return "", false
	}
	if !hmac.Equal([]byte(p.Sig), []byte(i.sign(p.Ref))) {
		return "", false
	}
	return p.Ref, true
}

func (i *Issuer) sign(ref string) string {
	mac := hmac.New(sha256.New, []byte(i.cfg.QRSecret))
	mac.Write([]byte("v=1&ref=" + ref))
	return hex.EncodeToString(mac.Sum(nil))
}

func encode(p payload) string {
	b, _ := json.Marshal(p)
	return base64.RawURLEncoding.EncodeToString(b)
}

func decode(token string) (payload, error) {
	var p payload
	b, err := base64.RawURLEncoding.DecodeString(token)
	if err != nil {
		return p, err
	}
	return p, json.Unmarshal(b, &p)
}
