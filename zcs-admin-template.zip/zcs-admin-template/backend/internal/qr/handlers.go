package qr

import (
	"encoding/json"
	"net/http"
	"strings"

	"zcsadmin/internal/httpx"
	"zcsadmin/internal/i18n"
	"zcsadmin/internal/session"
)

type Handlers struct{ issuer *Issuer }

func NewHandlers(issuer *Issuer) *Handlers { return &Handlers{issuer: issuer} }

// Issue: POST /api/qr/issue  { "ref": "<item id or key>" }
// Response: 200 { "scanUrl": "https://.../scan?d=<token>" }
//
// The signed token is returned only inside scanUrl and is NEVER logged.
func (h *Handlers) Issue(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	var in struct {
		Ref string `json:"ref"`
	}
	if err := json.NewDecoder(r.Body).Decode(&in); err != nil {
		httpx.Error(w, http.StatusBadRequest, httpx.CodeBadRequest, i18n.T("error.bad_request"))
		return
	}
	in.Ref = strings.TrimSpace(in.Ref)
	if in.Ref == "" {
		httpx.Error(w, http.StatusBadRequest, httpx.CodeBadRequest, i18n.T("error.qr_target_empty"))
		return
	}

	_, scanURL := h.issuer.Issue(in.Ref)
	httpx.JSON(w, http.StatusOK, map[string]any{"scanUrl": scanURL})
}
