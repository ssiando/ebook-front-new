// Package guard turns the session pipeline and the local access model into HTTP
// middleware. Every API route registers through a guard, never bare — UI hiding
// is never the only defense (AC-5.3).
package guard

import (
	"net/http"

	"zcsadmin/internal/access"
	"zcsadmin/internal/httpx"
	"zcsadmin/internal/i18n"
	"zcsadmin/internal/session"
)

// Handler is an authenticated handler: it receives the resolved Principal so it
// never has to re-parse the token.
type Handler func(w http.ResponseWriter, r *http.Request, p *session.Principal)

type Guard struct {
	sess   *session.Service
	access *access.Service
}

func New(sess *session.Service, acc *access.Service) *Guard {
	return &Guard{sess: sess, access: acc}
}

// Auth requires a live session only (any logged-in user). Used for /me,
// heartbeat, and logout.
func (g *Guard) Auth(h Handler) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		p, err := g.authenticate(w, r)
		if err != nil {
			return
		}
		h(w, r, p)
	}
}

// Access requires super-admin OR a local grant (운영자). Ungranted callers get
// 403 with no data — the frontend renders the ZCS noperm state.
func (g *Guard) Access(h Handler) http.HandlerFunc {
	return g.gate(h, func(d access.Decision) bool { return d.HasAccess })
}

// Manage requires super-admin OR a delegate (can_manage_access). Gates the
// 고유번호 접근 관리 endpoints.
func (g *Guard) Manage(h Handler) http.HandlerFunc {
	return g.gate(h, func(d access.Decision) bool { return d.CanManageAccess })
}

// Super requires super-admin. Gates the audit log.
func (g *Guard) Super(h Handler) http.HandlerFunc {
	return g.gate(h, func(d access.Decision) bool { return d.Super })
}

func (g *Guard) gate(h Handler, allow func(access.Decision) bool) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		p, authErr := g.authenticate(w, r)
		if authErr != nil {
			return
		}
		d, err := g.access.Evaluate(p.NewNo, p.Super)
		if err != nil {
			httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
			return
		}
		if !allow(d) {
			httpx.Error(w, http.StatusForbidden, httpx.CodeForbidden, i18n.T("error.forbidden"))
			return
		}
		h(w, r, p)
	}
}

// authenticate runs the session pipeline and writes the matching 401 envelope on
// failure. The three codes map to distinct frontend messages.
func (g *Guard) authenticate(w http.ResponseWriter, r *http.Request) (*session.Principal, *session.AuthError) {
	p, err := g.sess.Authenticate(r)
	if err == nil {
		return p, nil
	}
	var msgKey string
	switch err.Code {
	case "SESSION_REVOKED":
		msgKey = "error.session_revoked"
	case "SESSION_EXPIRED":
		msgKey = "error.session_expired"
	default:
		msgKey = "error.unauthorized"
	}
	httpx.Error(w, http.StatusUnauthorized, err.Code, i18n.T(msgKey))
	return nil, err
}
