// Package httpx holds the shared HTTP plumbing: the JSON response/error
// envelope, the fallback mux wrapper, and CORS. Nothing here knows about
// sessions, access, or any domain — it stays generic so every feature reuses it.
package httpx

import (
	"encoding/json"
	"log"
	"net/http"
)

// Error codes used across the API. Clients distinguish auth failures (all 401)
// by code: UNAUTHORIZED (bad/missing token), SESSION_REVOKED (logged out
// elsewhere), SESSION_EXPIRED (idle/absolute expiry).
const (
	CodeUnauthorized   = "UNAUTHORIZED"
	CodeSessionRevoked = "SESSION_REVOKED"
	CodeSessionExpired = "SESSION_EXPIRED"
	CodeForbidden      = "FORBIDDEN"
	CodeNotFound       = "NOT_FOUND"
	CodeBadRequest     = "BAD_REQUEST"
	CodeInternal       = "INTERNAL"
)

// envelopeHeader marks responses written by our handlers so the fallback mux
// wrapper does not mistake a real handler 404 for an unmatched-route 404.
const envelopeHeader = "X-Envelope"

type errorBody struct {
	Error errorDetail `json:"error"`
}

type errorDetail struct {
	Code    string `json:"code"`
	Message string `json:"message"`
}

// JSON writes a success payload. Pass nil for an empty 204-style body.
func JSON(w http.ResponseWriter, status int, payload any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set(envelopeHeader, "1")
	w.WriteHeader(status)
	if payload == nil {
		return
	}
	if err := json.NewEncoder(w).Encode(payload); err != nil {
		log.Printf("response encode failed: %v", err) // never logs payload contents
	}
}

// Error writes the error envelope. message should be a user-facing, localized
// string (see internal/i18n) — never an internal error string.
func Error(w http.ResponseWriter, status int, code, message string) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set(envelopeHeader, "1")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(errorBody{errorDetail{Code: code, Message: message}})
}
