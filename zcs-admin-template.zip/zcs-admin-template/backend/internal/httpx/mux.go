package httpx

import (
	"net/http"

	"zcsadmin/internal/i18n"
)

// EnvelopeMux wraps a handler so the stdlib mux's plain-text fallbacks (404 for
// an unknown path, 405 for a method mismatch) speak the JSON error envelope
// instead. Real handler responses set the envelope header and pass through
// untouched.
func EnvelopeMux(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		next.ServeHTTP(&fallbackWriter{ResponseWriter: w}, r)
	})
}

type fallbackWriter struct {
	http.ResponseWriter
	swallow bool
}

func (w *fallbackWriter) WriteHeader(code int) {
	// The stdlib ServeMux writes 404 (no route) and 405 (method mismatch) as
	// text/plain without our envelope header. Rewrite those as JSON.
	if (code == http.StatusNotFound || code == http.StatusMethodNotAllowed) &&
		w.Header().Get(envelopeHeader) == "" {
		w.swallow = true
		Error(w.ResponseWriter, code, CodeNotFound, i18n.T("error.not_found"))
		return
	}
	w.ResponseWriter.WriteHeader(code)
}

func (w *fallbackWriter) Write(b []byte) (int, error) {
	if w.swallow { // discard the stdlib plain-text body
		return len(b), nil
	}
	return w.ResponseWriter.Write(b)
}
