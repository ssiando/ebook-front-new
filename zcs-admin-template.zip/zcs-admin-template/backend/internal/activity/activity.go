// Package activity is the unified audit log: one append-only table recording
// every key action (the single source of truth, replacing the old access-only
// audit table). Reads are super-admin only (gated by the caller); 고유번호 lives
// in the rows for accountability but never in a URL or an application log line.
package activity

import (
	"database/sql"
	"log"
	"strconv"
	"strings"
	"time"

	"zcsadmin/internal/store"
)

// Action constants — the closed set of audited actions.
const (
	Login         = "LOGIN"
	Logout        = "LOGOUT"
	NoticeCreate  = "NOTICE_CREATE"
	NoticeUpdate  = "NOTICE_UPDATE"
	NoticeDelete  = "NOTICE_DELETE"
	Grant         = "GRANT"
	Revoke        = "REVOKE"
	SessionRevoke = "SESSION_REVOKE"
)

// Entry is one audit row.
type Entry struct {
	ID        int64
	ActorNo   string
	Action    string
	Target    *string
	Detail    *string
	CreatedAt time.Time
}

// Execer is satisfied by both *sql.DB and *sql.Tx, so a transactional caller
// (grant create/revoke) can write the audit row atomically with its change.
type Execer interface {
	Exec(query string, args ...any) (sql.Result, error)
}

// Write inserts one audit row through any Execer. Use this inside a transaction.
func Write(e Execer, now time.Time, actorNo, action string, target, detail *string) error {
	_, err := e.Exec(`
		INSERT INTO activity_log (actor_no, action, target, detail, created_at)
		VALUES ($1,$2,$3,$4,$5)`, actorNo, action, target, detail, now)
	return err
}

type Service struct{ st *store.Store }

func New(st *store.Store) *Service { return &Service{st: st} }

// Log records an action best-effort (the action already happened; the breadcrumb
// must not fail the request). A failure is logged as a class only — no PII.
func (s *Service) Log(actorNo, action string, target *string) {
	if err := Write(s.st.DB, s.st.Now(), actorNo, action, target, nil); err != nil {
		log.Printf("activity log write failed: action=%s", action)
	}
}

// ListOpts filters and paginates the log.
type ListOpts struct {
	Actions []string   // OR-match; empty = all
	From    *time.Time // inclusive
	To      *time.Time // exclusive
	Limit   int        // capped at 200; defaults to 50
	Offset  int
}

// List returns matching entries (newest first) and the total count for paging.
func (s *Service) List(o ListOpts) ([]Entry, int, error) {
	if o.Limit <= 0 {
		o.Limit = 50
	}
	if o.Limit > 200 {
		o.Limit = 200
	}
	if o.Offset < 0 {
		o.Offset = 0
	}

	where, args := buildWhere(o)

	var total int
	if err := s.st.DB.QueryRow(
		`SELECT count(*) FROM activity_log`+where, args...).Scan(&total); err != nil {
		return nil, 0, err
	}

	args = append(args, o.Limit, o.Offset)
	rows, err := s.st.DB.Query(`
		SELECT id, actor_no, action, target, detail, created_at
		FROM activity_log`+where+
		` ORDER BY created_at DESC, id DESC LIMIT $`+strconv.Itoa(len(args)-1)+
		` OFFSET $`+strconv.Itoa(len(args)), args...)
	if err != nil {
		return nil, 0, err
	}
	defer rows.Close()

	out := make([]Entry, 0, o.Limit)
	for rows.Next() {
		var e Entry
		if err := rows.Scan(&e.ID, &e.ActorNo, &e.Action, &e.Target, &e.Detail, &e.CreatedAt); err != nil {
			return nil, 0, err
		}
		out = append(out, e)
	}
	return out, total, rows.Err()
}

// buildWhere assembles the parameterized filter clause. Positional args are
// 1-based; LIMIT/OFFSET are appended by the caller.
func buildWhere(o ListOpts) (string, []any) {
	var conds []string
	var args []any

	if len(o.Actions) > 0 {
		placeholders := make([]string, len(o.Actions))
		for i, a := range o.Actions {
			args = append(args, a)
			placeholders[i] = "$" + strconv.Itoa(len(args))
		}
		conds = append(conds, "action IN ("+strings.Join(placeholders, ",")+")")
	}
	if o.From != nil {
		args = append(args, *o.From)
		conds = append(conds, "created_at >= $"+strconv.Itoa(len(args)))
	}
	if o.To != nil {
		args = append(args, *o.To)
		conds = append(conds, "created_at < $"+strconv.Itoa(len(args)))
	}
	if len(conds) == 0 {
		return "", args
	}
	return " WHERE " + strings.Join(conds, " AND "), args
}
