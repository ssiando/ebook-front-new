package activity

import (
	"net/http"
	"strconv"
	"strings"
	"time"

	"zcsadmin/internal/httpx"
	"zcsadmin/internal/i18n"
	"zcsadmin/internal/session"
)

// Handlers serve the 활동 감사 로그 screen. The route is gated SUPER-ADMIN ONLY by
// the guard at registration; this is read-only.
type Handlers struct{ svc *Service }

func NewHandlers(svc *Service) *Handlers { return &Handlers{svc: svc} }

// List: GET /api/activity?limit&offset&action&from&to → paginated, newest first.
//
//	{ "items": [ {id, actorNo, action, target, detail, createdAt} ],
//	  "total": N, "limit": L, "offset": O }
//
// action may repeat or be comma-separated; from/to are ISO 8601 (date or datetime).
func (h *Handlers) List(w http.ResponseWriter, r *http.Request, p *session.Principal) {
	q := r.URL.Query()
	opts := ListOpts{
		Actions: parseActions(q["action"]),
		From:    parseTime(q.Get("from")),
		To:      parseTime(q.Get("to")),
		Limit:   atoiDefault(q.Get("limit"), 50),
		Offset:  atoiDefault(q.Get("offset"), 0),
	}

	entries, total, err := h.svc.List(opts)
	if err != nil {
		httpx.Error(w, http.StatusInternalServerError, httpx.CodeInternal, i18n.T("error.internal"))
		return
	}
	items := make([]map[string]any, 0, len(entries))
	for _, e := range entries {
		items = append(items, map[string]any{
			"id":        e.ID,
			"actorNo":   e.ActorNo,
			"action":    e.Action,
			"target":    e.Target,
			"detail":    e.Detail,
			"createdAt": e.CreatedAt,
		})
	}
	httpx.JSON(w, http.StatusOK, map[string]any{
		"items":  items,
		"total":  total,
		"limit":  opts.Limit,
		"offset": opts.Offset,
	})
}

func parseActions(raw []string) []string {
	var out []string
	for _, r := range raw {
		for _, a := range strings.Split(r, ",") {
			if a = strings.TrimSpace(a); a != "" {
				out = append(out, a)
			}
		}
	}
	return out
}

// parseTime accepts a date (2006-01-02) or an RFC3339 datetime; invalid → nil.
func parseTime(s string) *time.Time {
	if s == "" {
		return nil
	}
	for _, layout := range []string{time.RFC3339, "2006-01-02"} {
		if t, err := time.Parse(layout, s); err == nil {
			u := t.UTC()
			return &u
		}
	}
	return nil
}

func atoiDefault(s string, def int) int {
	if n, err := strconv.Atoi(s); err == nil {
		return n
	}
	return def
}
