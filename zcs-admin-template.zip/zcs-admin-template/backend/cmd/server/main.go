// Command server is the ZCS admin template backend.
//
// Boot sequence: load config → open Postgres → run embedded migrations → purge
// long-revoked sessions → register routes through the guard → serve.
//
// There is NO HTTP access logging by design: request paths and member data must
// never reach logs. Only failure CLASSES are logged (never tokens/newNo/names).
package main

import (
	"log"
	"net/http"
	"os"

	"zcsadmin/internal/access"
	"zcsadmin/internal/activity"
	"zcsadmin/internal/auth"
	"zcsadmin/internal/config"
	"zcsadmin/internal/guard"
	"zcsadmin/internal/httpx"
	"zcsadmin/internal/notices"
	"zcsadmin/internal/qr"
	"zcsadmin/internal/session"
	"zcsadmin/internal/sessionmgmt"
	"zcsadmin/internal/store"
	"zcsadmin/internal/zauth"
)

func main() {
	cfg := config.Load()

	st, err := store.Open(cfg.DatabaseURL)
	if err != nil {
		log.Fatalf("database: %v", err)
	}
	defer st.Close()

	// `server purge`: deliberate retention purge (sessions + audit), then exit.
	// Run on a schedule from outside (cron / a scheduled Job) — never auto-cron here.
	if len(os.Args) > 1 && os.Args[1] == "purge" {
		runPurge(st, cfg)
		return
	}

	if err := st.Migrate(); err != nil {
		log.Fatalf("migrate: %v", err)
	}
	if n, err := st.PurgeRevokedSessions(cfg.SessionPurgeDays); err != nil {
		log.Printf("session purge failed: %v", err)
	} else if n > 0 {
		log.Printf("purged %d long-revoked session(s)", n)
	}

	// Services. The zauth client doubles as the session revalidator (canon:
	// periodic token revalidation against ZAuth, fail-closed).
	z := zauth.New(cfg)
	sess := session.New(st, cfg, z)
	accessSvc := access.New(st)
	activitySvc := activity.New(st)
	g := guard.New(sess, accessSvc)

	// Handlers.
	authH := auth.New(cfg, z, sess, accessSvc, activitySvc)
	accessH := access.NewHandlers(accessSvc)
	noticesH := notices.NewHandlers(notices.New(st), activitySvc)
	qrH := qr.NewHandlers(qr.New(cfg))
	activityH := activity.NewHandlers(activitySvc)
	sessionsH := sessionmgmt.New(sess, activitySvc)

	mux := http.NewServeMux()

	// Health (no auth) — used by docker-compose / infra probes.
	mux.HandleFunc("GET /api/health", func(w http.ResponseWriter, r *http.Request) {
		if err := st.DB.Ping(); err != nil {
			httpx.Error(w, http.StatusServiceUnavailable, httpx.CodeInternal, "unhealthy")
			return
		}
		httpx.JSON(w, http.StatusOK, map[string]any{"status": "ok"})
	})

	// Zion 로그인 (browser redirects — no JSON guard).
	mux.HandleFunc("GET /api/auth/login", authH.Login)
	mux.HandleFunc("GET /api/auth/callback", authH.Callback)

	// Session-scoped (any logged-in user).
	mux.HandleFunc("GET /api/auth/me", g.Auth(authH.Me))
	mux.HandleFunc("POST /api/auth/logout", g.Auth(authH.Logout))
	mux.HandleFunc("POST /api/sessions/heartbeat", g.Auth(authH.Heartbeat))

	// 고유번호 접근 관리 — delegate-or-super (Manage).
	mux.HandleFunc("GET /api/access/grants", g.Manage(accessH.List))
	mux.HandleFunc("PUT /api/access/grants", g.Manage(accessH.Upsert)) // 고유번호 in body, not URL
	mux.HandleFunc("DELETE /api/access/grants/{id}", g.Manage(accessH.Delete))

	// 보안·감사 — SUPER-ADMIN ONLY (fail-closed). Read-only audit + session control.
	mux.HandleFunc("GET /api/activity", g.Super(activityH.List))
	mux.HandleFunc("GET /api/sessions", g.Super(sessionsH.List))
	mux.HandleFunc("DELETE /api/sessions/{id}", g.Super(sessionsH.Revoke))

	// ---- Feature resources (access-gated). Copy this block to add a feature. ----
	mux.HandleFunc("GET /api/notices", g.Access(noticesH.List))
	mux.HandleFunc("POST /api/notices", g.Access(noticesH.Create))
	mux.HandleFunc("GET /api/notices/{id}", g.Access(noticesH.Get))
	mux.HandleFunc("PUT /api/notices/{id}", g.Access(noticesH.Update))
	mux.HandleFunc("DELETE /api/notices/{id}", g.Access(noticesH.Delete))

	mux.HandleFunc("POST /api/qr/issue", g.Access(qrH.Issue))
	// ---------------------------------------------------------------------------

	// Local-dev escape hatch: a real session without Zion 로그인. Present only
	// under DEV_BYPASS_AUTH; otherwise the route is absent (404 as if unregistered).
	if cfg.DevBypassAuth {
		mux.HandleFunc("POST /api/auth/test-login", authH.TestLogin)
		log.Println("DEV_BYPASS_AUTH: POST /api/auth/test-login is ENABLED (never use in production)")
	}

	handler := httpx.CORS(cfg.CORSOrigins, httpx.EnvelopeMux(mux))

	addr := ":" + port()
	log.Printf("listening on %s", addr)
	if err := http.ListenAndServe(addr, handler); err != nil {
		log.Fatalf("server: %v", err)
	}
}

func port() string {
	if p := os.Getenv("PORT"); p != "" {
		return p
	}
	return "8080"
}

// runPurge applies both retention bounds and reports counts. Audit purge honors
// AUDIT_RETENTION_DAYS; session purge honors SESSION_PURGE_DAYS.
func runPurge(st *store.Store, cfg *config.Config) {
	if n, err := st.PurgeRevokedSessions(cfg.SessionPurgeDays); err != nil {
		log.Fatalf("session purge failed: %v", err)
	} else {
		log.Printf("purged %d revoked session(s) older than %d day(s)", n, cfg.SessionPurgeDays)
	}
	if n, err := st.PurgeActivityLog(cfg.AuditRetentionDays); err != nil {
		log.Fatalf("activity-log purge failed: %v", err)
	} else {
		log.Printf("purged %d activity-log row(s) older than %d day(s)", n, cfg.AuditRetentionDays)
	}
}
