module zcsadmin

go 1.25.0

// Direct dependencies are kept to two, each load-bearing:
//   - jackc/pgx/v5 PostgreSQL driver (used via database/sql, the stdlib pgx driver)
//   - google/uuid  session id generation
// Everything else (HTTP, crypto for QR + token hashing, JSON) is the standard
// library — the session token is the ZAuth access_token, so no JWT library.
require (
	github.com/google/uuid v1.6.0
	github.com/jackc/pgx/v5 v5.10.0
)

require (
	github.com/jackc/pgpassfile v1.0.0 // indirect
	github.com/jackc/pgservicefile v0.0.0-20240606120523-5a60cdf6a761 // indirect
	github.com/jackc/puddle/v2 v2.2.2 // indirect
	golang.org/x/sync v0.17.0 // indirect
	golang.org/x/text v0.29.0 // indirect
)
