# 05 — Integration QA Report (ZCS Admin Template)

> Cross-comparison QA: "does the response match what the caller expects?", read both sides at once.
> Status legend: **PASS** / **FAIL** / **UNVERIFIED** (could not exercise — stated, never hidden).
> Run 2026-06-30, code stage. Security/privacy/design findings live in `04_review_report.md`.

## Builds & static checks

| Check | Command | Result |
|-------|---------|--------|
| Go build | `cd backend && go build ./...` | **PASS** (exit 0) |
| Go vet | `cd backend && go vet ./...` | **PASS** (exit 0) |
| Frontend typecheck + build | `cd frontend && npm run build` (`tsc --noEmit && vite build`) | **PASS** (139 modules, no TS errors) |

No `any`/cast smell found in the changed surface; types are 1:1 with the contract (`types/api.ts` header enforces this).

## API contract ↔ frontend type cross-check

| Endpoint (api_contracts.md) | Backend shape | Frontend type | Result |
|---|---|---|---|
| `GET /api/auth/me` | `auth/handlers.go:120` | `MeResponse`/`MeUser`/`MeAccess`/`MeSession` | **PASS** — fields + nesting match |
| `GET /api/access/grants` | `access/handlers.go:21` | `Grant` | **PASS** w/ known mismatch (see below) |
| `PUT /api/access/grants` | body `{newNo,role?,canManageAccess?}` | `GrantInput` | **PASS** |
| `DELETE /api/access/grants/{id}` | 204 / 404 | `revokeGrant(id)` | **PASS** |
| `GET /api/access/audit` | `access/handlers.go:106` | `AuditEntry` | **PASS** w/ known mismatch (see below) |
| `GET/POST/PUT/DELETE /api/notices` | `notices/handlers.go` (`authorName` only) | `Notice` (no `authorNo`) | **PASS** |
| `POST /api/qr/issue` | `{scanUrl}` | `QrIssueResponse` | **PASS** |
| `POST /api/auth/test-login` (DEV) | `{token}` | `DevLoginPanel` | **PASS** (dev-only both ends) |
| List wrapping `{items:[…]}` | all list handlers | `ListResponse<T>` / `useList` | **PASS** |
| Error envelope + codes | `httpx.Error` / `EnvelopeMux` | `ApiError`/`parseError` | **PASS** — all 7 codes aligned; 401 → drop token + route to login (`services/api.ts:86`) |

### Known mismatches (confirmed accepted, NOT bugs)
- **Grants list has no `name`.** `Grant` declares `name?: string | null`; the backend `grantDTO` never returns it
  (Bearer-only — no server-to-server name lookup). Frontend **degrades gracefully**: the name column keys off the
  `confirmed` flag (`AccessManagementPage.tsx:74-78`, shows 확인됨 / 이름 미확인). **Accepted Bearer-only consequence.**
  *Doc nit:* the contract + type comment claim live name resolution that does not happen — see D-1 in `04`.
- **Audit list has no actor/target name.** `AuditEntry` carries `actorNo`/`targetNo` only; the panel renders 고유번호
  only (`AccessAuditPanel.tsx:39-40`). **Accepted Bearer-only consequence**, and aligns with privacy (no name broadcast).

## Routing consistency

| Route (App.tsx) | Element | Gate | Result |
|---|---|---|---|
| `/login`, `/auth/callback` | LoginScreen / OAuthCallback | none | **PASS** |
| `index` | → `/notices` | — | **PASS** |
| `/notices`, `/qr` | pages | `Gate need="access"` | **PASS** |
| `/access` | AccessManagementPage | `Gate need="manage"` | **PASS** |
| `*` | → `/` | — | **PASS** (no dead route) |

- **Nav ↔ route ↔ server gate parity (PASS).** `AppShell` builds nav from `access` (notices+qr for `hasAccess`,
  access for `super`/`canManageAccess`) — mirrors the server guards. Menu hiding is convenience; the server is the gate.
- QR is reachable from both the menu and `/qr` (earlier concern cleared). Backend 404/405 speak the JSON envelope
  via `EnvelopeMux` — **PASS**.

## Required-behavior verification (SSOT overrides)

| Requirement | Result |
|---|---|
| Exactly ONE permission screen (고유번호 접근 관리), **no** permission catalog/guide page | **PASS** — only `/access`; no catalog route/page exists |
| Access enforced **server-side** on every gated endpoint (not just menu hiding) | **PASS** — every route through a guard (`main.go:80-97`); `Gate`/403 is belt-and-suspenders |
| Super-admin = exact authority `ZADMIN-TEMPLATE-SUPER`, nothing else, fail-closed | **PASS** (`zauth.go:163-193`, `config.go:70`) |
| 고유번호 in full where justified; idNumber/주민번호 never shown | **PASS** |
| ZCS vendored byte-identical; source not modified | **PASS** (`diff -rq` clean; source has no changes) |

## Acceptance criteria (static verification)

AC-1.x (login/fail-closed), AC-2.x (super detection), AC-3.x (grant/idempotent/audit/미확인), AC-4.x (revoke/no
self-lockout), AC-5.x (server-side gating), AC-6.x (notices CRUD + author by name), AC-7.x (HMAC QR + never-logged):
**all statically satisfied** in code per the cross-checks above and the security/privacy verification in `04`.

## Unverified scope (stated honestly)

- **No dynamic run.** The review environment has no Postgres or ZAuth, so the backend was not booted and these were
  NOT exercised at runtime: live OAuth code→token→/me round-trip, session heartbeat/idle-expiry/absolute-expiry
  transitions, the grant→login→ConfirmLogin (미확인 clear) flow, the real `noperm` 403 path, and end-to-end QR
  issuance against a live `QR_SECRET`. Verification was static cross-comparison + builds. Recommend a smoke run via
  `docker compose up` + `DEV_BYPASS_AUTH` test-login before release.
- **humanize-korean not re-run.** `locales/ko.json` and the backend `i18n` catalog read natural, carry no developer
  terminology (no raw codes/IDs/enums, no "ZAuth" — uses Zion 계정 / 고유번호 / 총괄 관리자 / 운영자), and map all
  roles/codes to labels; no AI-tell issues observed, but the skill was not formally run over them.

## QA verdict

Integration is **consistent and builds clean** — no boundary bugs, no routing dead-ends, contract and types in lockstep,
required SSOT behaviors present. The only completion blocker is **B-1 (missing `CLAUDE.md`)** in `04_review_report.md`,
which is a deliverable gap, not an integration defect. Overall: **PASS (integration) — gated on B-1 for full sign-off.**

---

# CR-02 Integration QA — Shell / Nav / Session Mgmt / Activity Audit (2026-07-01)

## Builds & static checks

| Check | Command | Result |
|-------|---------|--------|
| Go build | `cd backend && go build ./...` | **PASS** (exit 0) |
| Go vet | `cd backend && go vet ./...` | **PASS** (exit 0) |
| Frontend typecheck + build | `cd frontend && npm run build` | **PASS** (150 modules, no TS errors) |

No `any`/cast smell in the CR-02 surface; `types/api.ts` 1:1 with `api_contracts.md` §6.

## API contract ↔ frontend type cross-check (CR-02 endpoints)

| Endpoint | Backend shape | Frontend type | Result |
|---|---|---|---|
| `GET /api/sessions` (super) | `sessionmgmt/handlers.go:41-49` `{id,newNo,name,loginAt,lastSeenAt,idleExpiresAt,isCurrent}` | `SessionInfo` | **PASS** |
| `DELETE /api/sessions/{id}` (super) | 204 / 404 / 400 | `revokeSession(id)` | **PASS** |
| `GET /api/activity` (super) | `activity/handlers.go:43-57` `{items[{id,actorNo,action,target,detail,createdAt}],total,limit,offset}` | `ActivityResponse`/`ActivityEntry` | **PASS** |
| List wrap / error envelope / 7 codes | as before | unchanged | **PASS** |

### Accepted Bearer-only consequences (NOT bugs)
- **`activity.actorNo`/`target` carry no name.** The panel renders 고유번호 in mono (`ActivityLogPage.tsx:72-77`,
  `targetCell`), aligning with privacy (no name broadcast). Graceful.
- **`sessions` name resolution limited** to the login-time snapshot; empty/legacy rows render
  `t("sessions.unknownName")` = "이름 미확인" (`SessionsPage.tsx:76`). Graceful, not a crash.

## Routing / nav / gate parity

| Item | Result |
|---|---|
| `/audit`, `/sessions` routes gated `Gate need="super"` (`App.tsx:43-58`) ↔ backend `g.Super` (`main.go:95-97`) | **PASS** |
| QR removed from nav (`config/nav.ts` has no QR node) but `/qr` route still gated `need="access"` ↔ backend `g.Access` (`main.go:106`) | **PASS** — endpoint + page retained as reference, just unlinked |
| Nav config tree ↔ recursive renderer ↔ `visible` predicates mirror server access | **PASS** |
| Logout moved to sidebar footer → `POST /api/auth/logout` → login (`LogoutButton.tsx`) | **PASS** |
| 내 정보 drawer = read-only own identity + live session; no logout, no raw codes, no 주민번호 | **PASS** |

## User-facing copy

| Check | Result |
|---|---|
| No "ZAuth" in any rendered copy (only in code comments) | **PASS** (`grep -niE zauth src/` → comment-only) |
| No raw action/role codes in `ko.json`; all mapped to Korean labels (`lib/activity.ts`, `lib/role.ts`) | **PASS** |
| 고유번호 labeled "고유번호" (`common.newNoLabel`); CR-02 i18n keys all present (sessions/activity/myInfo) | **PASS** |
| Login branding "신천지 어드민 템플릿" intact (`ko.json:3,22`) | **PASS** |

## Unverified scope (stated honestly)

- **No dynamic run** (no Postgres/ZAuth in env): not exercised at runtime — live force-logout
  (`DELETE /api/sessions/{id}` → revoked user gets `SESSION_REVOKED` next request), self-revoke
  logout-and-redirect, activity-log write-through from each handler, idle/absolute expiry filtering
  in `ListActive`, and the `server purge` deletion of `activity_log` + revoked sessions. Recommend a
  `docker compose up` + `DEV_BYPASS_AUTH` smoke run before release.
- **Migration 0002** verified statically (atomic implicit tx, ordering after 0001, once-only via
  `schema_migrations`); not applied against a live DB here. Minor M-1 (historical delegate marker
  lost) noted in `04`.

## CR-02 QA verdict

**PASS (integration).** Contracts and types in lockstep, routing/nav/gate parity correct, QR cleanly
unlinked yet still gated, builds green, no developer terminology or branding regressions. The prior
B-1 blocker is resolved. One Minor (M-1) and two cosmetic carry-forwards remain, none integration-blocking.
