# 04 — Review Report (ZCS Admin Template)

> Quality gate. Blockers block sign-off; Majors need a recorded accept-risk decision by the leader.
> Sections: Security / Privacy / Design. Each finding: severity + location + problem + concrete fix.

---

## Privacy (PIPA + GDPR) — Spec Stage

Reviewed: `00_input/request.md`, `01_pm_spec.md` §4 (member-data usage table) + §5 (local permission model).
Home jurisdiction PIPA, GDPR as global floor; stricter wins. This is a **template non-developers copy with AI**, so every default must be safe-by-default — a beginner must trip *toward* compliance, not away from it.

### Overarching context — special-category data raises the floor
This is an admin system for a **religious community**. The grant table and audit log are, by construction, **lists of identified members/staff of a religious organisation** → that membership is **special-category data (GDPR Art. 9 / PIPA Art. 23 sensitive data)**, regardless of 고유번호's reclassification as a non-national-ID public key. The reclassification (CLAUDE.md 2026-06-16) correctly lowers the bar for *displaying* 고유번호; it does **not** lower the bar for the *dataset as a whole*. Access control, audit, retention, and at-rest protection are judged against the special-category bar below.

### Confirmations (the two questions asked)

**CONFIRM — persisting 고유번호 (not name) is the correct minimization choice.** 고유번호 is a stable, opaque working key; name is mutable and more directly identifying in casual exposure. Persisting the stable key and resolving name/tribe/church/duty live per session is correct on two grounds: minimization (only one field at rest) **and** accuracy/PIPA Art. 3 (a renamed/transferred member is reflected automatically; no stale copies). Keep it. **Caveat:** 고유번호 is still personal data under PIPA — "public working key" is not "exempt." The template's `CLAUDE.md` must not teach beginners it is safe to sprinkle anywhere; the rules below (no URLs, no logs, no exports, auth-gated only) still apply. (See P-7.)

**CHALLENGE / scope the audit log (answers spec Q2).** Yes — the grant/revoke audit log needs its own access restriction and a retention limit. It is a history of *who holds administrative access to a religious-org system*, keyed by 고유번호 → high-value, special-category-adjacent. It must be **super-admin-only, never reachable by general staff, never returned by any feature API**, and bounded in time. The spec currently only says it is *written*; it does not state who may *read* it or for how long. See P-1 and P-2.

### Findings

**[Major] P-1 — No retention period or destruction procedure (Storage limitation: PIPA Art. 21 / GDPR Art. 5(1)(e)).**
`01_pm_spec.md:168-169` ("audit rows persist per retention policy" — no policy defined; "grant rows persist until revoked"). "Keep forever by default" is a finding, and the template will be the default every fork inherits.
*Fix:* Define template defaults now: (a) audit log retention = a concrete default (recommend 1–3 years for access-control accountability) after which rows are purged; (b) a documented manual destruction procedure (or a simple scheduled purge) shipped/described in `CLAUDE.md`; (c) revoked grants — decide hard-delete vs. tombstone, and if tombstoned, give them a retention bound too. Beginners must be handed a default, not a TODO.

**[Major] P-2 — Audit log read-access is undefined (Safety/Accountability: PIPA Art. 29·29 enforcement / GDPR Art. 32).**
`01_pm_spec.md:172-173, 175`. The audit log holds 고유번호 of actors+targets and reveals the admin-access graph, but no screen, API, or access rule governs *reading* it.
*Fix:* State explicitly in the spec/CLAUDE.md: the audit table is **super-admin-only**; it is **not** exposed by any staff-facing or notices/QR API; if a viewing screen is ever added it is gated identically to 고유번호 접근 관리 (delegate excluded unless deliberately granted). Default = write-only from the app's perspective, read only by super-admin via an explicitly-gated path.

**[Major] P-3 — 고유번호 of notice authors over-exposed to all staff (Minimization / Purpose limitation: PIPA Art. 16·15 / GDPR Art. 5(1)(b·c)).**
`request.md:80`, `01_pm_spec.md:128, 157` (AC-6.2: notice list shows author "name (+ 고유번호 in full)" to every granted staff). The *purpose* of the author column is "who wrote this" — **name alone satisfies it.** Broadcasting every author's 고유번호 across a notices feed exposes the working key beyond its justified purpose (grantee identification on the access page). Storing author as 고유번호 is correct (stable key, P-confirm); *displaying* it on the notices list is not.
*Fix:* Template default = notices list/detail display **name only** (resolved live from the author's 고유번호). Reserve full-고유번호 display for the **고유번호 접근 관리** page, where pinning down *who* is the stated purpose. Document showing author 고유번호 as an opt-in extension, not the default. This also makes the template teach purpose-limitation by example.

**[Major] P-4 — `/me` response not whitelisted → idNumber/extra fields can leak by default (Minimization: PIPA Art. 16 / GDPR Art. 5(1)(c)).**
`01_pm_spec.md:163` (idNumber "NOT USED") states intent but no mechanism. ZAuth `/me` may return more than the five needed fields depending on app scope; a beginner who passes the raw `/me` payload to the frontend will surface whatever it contains — potentially idNumber-grade fields.
*Fix:* Backend must parse `/me` into an explicit allow-list struct of exactly `{newNo, name, tribe, church, duty}` and discard everything else server-side before it reaches the session/frontend. Ship this as the only `/me` mapping in the template so a fork cannot accidentally widen it. Add a CLAUDE.md caution: never forward the raw `/me` body.

**[Major] P-5 — No safe-logging default; beginners will log 고유번호 (No PII in logs: PIPA Art. 29 / GDPR Art. 32).**
`01_pm_spec.md:172`, `AC-7.4` assert "no PII in logs" and "QR never logged" as *intent*, but the template ships no mechanism. The single most likely beginner mistake is logging request bodies / the author 고유번호 / the grant target in a debug line, or printing the QR payload while testing.
*Fix:* (a) Ship the template's logger configured to **not** dump request/response bodies; (b) provide one worked, copy-this example of recording a grant action that logs an **action + opaque grant-id**, not the 고유번호, alongside the audit row; (c) CLAUDE.md: explicit "never log 고유번호, QR payloads, or `/me` bodies" with the grep verification (`AC-7.4`). Make the safe path the path of least resistance.

**[Major] P-6 — 고유번호 must never travel in URLs/query strings (No PII in URLs: PIPA Art. 29 / GDPR Art. 32).**
`01_pm_spec.md` access-management + notices flows don't constrain transport. A beginner will naturally write `GET /api/grants?newNo=...` or route by author 고유번호, putting personal data into access logs, proxy logs, browser history, and Referer headers.
*Fix:* Mandate in spec + CLAUDE.md: 고유번호 travels only in request **bodies** (POST/PUT) or as the authenticated session subject — never in path segments or query strings; grant rows and notices are addressed by an internal opaque id, not by 고유번호. Note this is doubly important under HashRouter (the fragment is client-side, but API URLs are not).

### Minor / hygiene

**[Minor] P-7 — CLAUDE.md framing of 고유번호.** Ensure the "public working key, shown in full" guidance is paired with "still personal data: auth-gated screens only, no logs, no URLs, no ungated export." Without the pairing a beginner over-reads "shown in full" as "unrestricted."

**[Minor] P-8 — Seed/fixtures/docs must use obviously-fake 고유번호.** `_workspace` artifacts, docker-compose seed data, and CLAUDE.md examples must contain no real member 고유번호 (PIPA Art. 29; fixtures are a recurring real-data leak channel). Mandate a clearly-fake format in all samples.

**[Minor] P-9 — Orphan grants from AC-3.5 (grant-ahead-of-login).** `01_pm_spec.md:100-102`: grants stored for a 고유번호 that may never log in accumulate indefinitely (intersects P-1 retention) and store an identifier that was never validated against a real member. *Fix:* add input-format validation for 고유번호 on entry, and fold "미확인" grants older than a documented window into the purge procedure.

**[Minor] P-10 — Data-subject rights path (PIPA Art. 35-37 / GDPR Art. 15-17).** Template tier, but CLAUDE.md should note: local grant rows + audit entries are personal data subject to deletion/access requests; give a one-line manual procedure (delete a person's grants; retain audit entries under the accountability legal basis and document that retention as the lawful exception to erasure).

**[Minor] P-11 — At-rest + TLS posture.** Per the 2026-06-16 reclassification, 고유번호 does **not** require column-level encryption (it is not idNumber). But because the DB as a whole is a religious-membership dataset, CLAUDE.md should require DB-level/disk encryption + restricted DB credentials, and reaffirm TLS everywhere (OAuth exchange, secure+httponly session cookies per the zauth session canon). Reaffirm idNumber is never fetched, decrypted, displayed, or logged anywhere (`01_pm_spec.md:163`).

### Spec-stage verdict
No Blockers at spec stage (the design intent is sound and minimization is genuinely strong). **6 Majors** are mechanism/exposure gaps that must be closed in the spec + `CLAUDE.md` and verified in code before sign-off — P-1/P-2 (retention + audit access), P-3/P-4 (display & response minimization), P-5/P-6 (logs & URLs). For a template, these "missing safe-default" gaps are the high-leverage items: every fork inherits them. Route P-3 and the §4 table edits to **pm-planner**; route P-4/P-5/P-6 enforcement to **backend-builder**, P-3 display to **frontend-builder**.

---

---

# Final Review — Security / Privacy / Design / Integration (code stage, 2026-06-30)

> Final sign-off pass over `backend/` (Go stdlib) + `frontend/` (React 19 + Vite + TS, vendored ZCS).
> Builds run: `go build ./...` PASS, `go vet ./...` PASS, `npm run build` (tsc --noEmit && vite build) PASS.
> Bar applied: *"does the default keep a beginner safe and correct?"* — this is a template non-developers copy with AI.
> Dynamic scope NOT exercised (no DB/ZAuth in the review env): no live boot, OAuth round-trip, heartbeat, or
> idle-expiry was run. Findings below are static cross-verification + builds. See `05_qa_report.md` for the QA matrix.

## Security

The security posture is strong and the code itself contains **no permission-bypass, IDOR, injection, or
secret-leak defect**. Specifics verified:

- **Auth/session (PASS).** `session.Authenticate` runs the canon pipeline: JWT verified by **signature only**
  (`WithoutClaimsValidation`) so a stale token still reaches the row checks and gets the correct contract code;
  the **DB row is the source of truth** (revoked/expired beats a cryptographically valid token); lookup errors
  **fail closed** to `UNAUTHORIZED` (`session.go:137`); `lazyRevoke` is race-safe (single winner → `SESSION_EXPIRED`,
  losers → `SESSION_REVOKED`, `session.go:169-180`). The three 401 codes map correctly (`guard.go:83-92`).
- **Server-side gating on every route (PASS, AC-5.3).** Every API path in `main.go:80-97` is registered through a
  guard (`Auth`/`Access`/`Manage`/`Super`); none is bare. `guard.gate` re-evaluates access from the live grant table
  per request (`guard.go:57-73`) — menu hiding in `AppShell.tsx` is convenience only.
- **Super-admin detection (PASS, AC-2.x).** `zauth.IsSuperAdmin` resolves `roleBased ∪ orgBased ALLOW − DENY` and
  returns `allow[want] && !deny[want]` (`zauth.go:191-192`) — exact, case-sensitive, **DENY wins**, only the
  configured string read, duties never inspected. Fail-closed `(false, error)` on any lookup failure; the callback
  aborts the whole login on that error (`handlers.go:83-88`). Authority string is one env-overridable constant
  (`config.go:70`, default `ZADMIN-TEMPLATE-SUPER`).
- **Local 고유번호 grant gate (PASS).** Super-admin is never stored locally (`Evaluate` short-circuits on the
  Principal flag, `access.go:71-83`); a missing row → no access (fail-closed). Escalation guard: only a super-admin
  may set `canManageAccess=true`, enforced in the handler (`handlers.go:72-75`) **and** behind the `Manage` gate —
  a delegate cannot mint delegates.
- **IDOR (PASS).** Grants are addressed in URLs by an opaque uuid (`DELETE /api/access/grants/{id}`), notices by an
  integer id; both behind gates. Flat access model (any granted staff edits any notice) is **documented as intentional**
  (spec §5; AC-6.3) — not an ownership bug.
- **Injection (PASS).** All SQL is parameterized (`$1…`); no string-built queries anywhere.
- **Secrets (PASS).** `JWT_SECRET` boot guard refuses weak/placeholder unless `DEV_BYPASS_AUTH` (`config.go:115-130`);
  the ZAuth `access_token` is dropped after login (`handlers.go:89`); QR token lives only inside `scanUrl` and is
  never logged; HMAC uses constant-time `hmac.Equal` (`qr.go:58`).
- **CORS/redirect (PASS).** Origin allow-list is exact-match (`cors.go`); `redirectURI` prefers the explicit env and
  the infra doc instructs the proxy to strip client `X-Forwarded-*` (`03_infra_env.md` §5).

### Findings

**[Major — accept-risk candidate] S-1 — `docker-compose.yml` ships an open-by-default local stack that a beginner
could expose publicly.** `docker-compose.yml:43,48` set `DEV_BYPASS_AUTH: ${DEV_BYPASS_AUTH:-true}` **and**
`JWT_SECRET: ${JWT_SECRET:-local-dev-only-secret-change-me-0123456789}` — a 44-char default that **passes** the
`enforceJWTSecret` boot guard (it is ≥32 chars and ≠`CHANGE_ME`). Together this means the compose stack boots with
`POST /api/auth/test-login` enabled and a known signing key: anyone reaching it can mint a **super-admin session**
(`{"super":true}`) with no Zion 로그인. This is *by design for local dev* (the file is labeled "LOCAL-ONLY throwaway",
production is the separate infra handoff which correctly fails closed), and `.env.example` is safe-by-default
(`JWT_SECRET=CHANGE_ME`, `DEV_BYPASS_AUTH=false`). But the audience is non-developers building with AI who will run
`docker compose up`, and the failure mode (public exposure of the local stack) is catastrophic and silent.
*Fix (pick at least one):* (a) flip the compose default to `DEV_BYPASS_AUTH: ${DEV_BYPASS_AUTH:-false}` so dev-login is
opt-in; (b) drop the passing `JWT_SECRET` default so the boot guard fires and forces an explicit local secret; and
(c) **mandatory** — `CLAUDE.md` must carry a prominent "this compose is local-only; never bind it to a public
interface" warning (currently undeliverable — see B-1). Recommended as an explicitly-recorded accepted-risk **only
after** (c) lands.

## Privacy (PIPA + GDPR) — code verification of spec-stage findings

All six spec-stage Majors are **implemented in code**:

- **P-2 (audit super-only) — CLOSED.** `GET /api/access/audit` is behind `g.Super` (`main.go:88`); the audit table is
  returned by no other endpoint. Frontend audit tab renders only for `super` (`AccessManagementPage.tsx:112`).
- **P-3 (no authorNo; name snapshot) — CLOSED.** `notices.dto` exposes `authorName` only (`handlers.go:19-28`);
  `author_no` is stored for accountability and never serialized (`notices.go:22`, migration comment); the name is a
  point-in-time snapshot captured from the author's own session (`Create`, `notices.go:73`). Frontend has no
  `authorNo` field and renders `authorName` only (`NoticeDetail.tsx`, `NoticesPage.tsx:75`).
- **P-4 (/me whitelist; raw discarded) — CLOSED.** `FetchMe` requests only `NAME,NEW_NO,ORGANIZATION_PATH,
  ORGANIZATION_WITH_DUTY` (`zauth.go:29` — no idNumber) and decodes into an explicit struct, mapping to a 5-field
  `Member`; everything else in the `/me` body is discarded server-side. The `access_token` never reaches the frontend.
- **P-5 (no PII/token in logs) — CLOSED in code.** No access-log middleware; `log.Print*` lines are failure *classes*
  only ("login failed: /me lookup", etc.); `httpx.JSON` never logs payload contents (`respond.go:48`). *Caveat:* the
  beginner-facing "never log 고유번호/QR/`/me`" rule + the AC-7.4 grep verification were routed to `CLAUDE.md`, which is
  missing (B-1).
- **P-6 (고유번호 never in URLs) — CLOSED.** Grants travel in request bodies and are deleted by opaque id; notices use
  an integer id. Grep confirms no `newNo` in any path/query construction (`hooks/access.ts`, `hooks/notices.ts`).
- **P-1 (retention + purge) — CLOSED.** `AUDIT_RETENTION_DAYS` (365) + `SESSION_PURGE_DAYS` (90) defaults; `server purge`
  subcommand applies both bounds (`main.go:123-136`, `store.go:99-126`); the infra doc documents the schedule, the
  manual SQL, and the DSR erasure exception (`03_infra_env.md` §7).
- **idNumber/주민번호 — CONFIRMED untouched.** Never requested, stored, decrypted, displayed, or logged anywhere.
- **고유번호 full-display — CORRECT scope.** Full only on the access page, the user's own record (topbar / noperm
  self-hint), and the super-only audit; never broadcast on the notices feed.

### Findings (Minor — carry-forward)

**[Minor] P-8 (carry-forward) — sample 고유번호 are not obviously fake.** `DevLoginPanel.tsx:12` defaults
`newNo="00341130-00036"`/`name="김도현"`; `api_contracts.md` examples use `00341130-00036`/`홍길동`. The format is
realistic enough to collide with a real member key. *Fix:* use a clearly-synthetic value (e.g. `00000000-00001`,
name "홍길동(예시)") in the dev panel default and the contract examples. Low risk (dev-only, tree-shaken from prod).

**[Minor] P-10 / P-7 (carry-forward) — beginner-facing privacy guidance lives only in the infra doc.** The DSR
procedure, the "고유번호 is still personal data" framing, and the "never log" rule exist operationally in
`03_infra_env.md` but were meant for the beginner audience via `CLAUDE.md` (B-1). Fold them into `CLAUDE.md` when it is
written.

## Design (SOLID + clarity)

Design quality is **high** — clean enough to be the ZCS-vendoring reference it is meant to be.

- **SRP / package boundaries (PASS).** `config / store / session / guard / access / auth / zauth / notices / qr /
  httpx / i18n` each own one concern; `httpx` is domain-agnostic plumbing.
- **OCP (PASS).** The four guards share one `gate(h, allow func(Decision) bool)` predicate (`guard.go:42-74`) — adding a
  capability is a one-line predicate, not a new pipeline. The `Handler` type passes the resolved `Principal` so handlers
  never re-parse the token.
- **Extensibility done right, not over-built (PASS).** `notices` is the explicit "copy me" example; the single `STAFF`
  role + delegate flag is a documented extension point; `MaskedValue` is intentionally retained-unused for a fork that
  adds a sensitive field (`MaskedValue.tsx:3-6`). No speculative abstraction.
- **Frontend (PASS).** Generic `useList`, thin hooks, a clean `Gate`/`AuthedLayout` split, nav gating that mirrors the
  server decision. ZCS vendored **byte-identical** to source (`diff -rq` clean) with a11y overrides isolated in
  `src/styles/zcs-a11y.css`; the source `/Users/mins/Workspace/zcs/` was **NOT modified**.

### Findings

**[Minor] D-1 — misleading "live name resolution" claim.** `types/api.ts:54-56` and `api_contracts.md` §2 state the
backend resolves a grantee's `name` live once they have logged in, but the backend `grantDTO` **never** returns a
`name` (`access/handlers.go:21-32`) — it is Bearer-only with no server-to-server lookup. The frontend degrades
gracefully (the `name` column keys off the `confirmed` flag), so this is not a bug, but the comment/contract overstate a
capability that does not exist. *Fix:* correct the comment + contract to "name is not returned (Bearer-only); the table
shows 확인됨/이름 미확인 from the `confirmed` flag." Optionally drop the dead `name`-search branch in
`AccessManagementPage.tsx:42`.

**[Minor] D-2 — nav-key inconsistency.** `AppShell.tsx:37` labels the QR nav item with `t("qr.title")` while other nav
items use `shell.nav.*` keys; there is no `shell.nav.qr`. Cosmetic; add the key for consistency.

## Blocker

**[Blocker] B-1 — the central deliverable `CLAUDE.md` is MISSING from the template root.** The SSOT names
`CLAUDE.md` as *"the primary teacher"* and *"the central deliverable"* (`request.md` §"Primary deliverable emphasis";
spec milestone #8). It is absent (`ls` of the root shows no `CLAUDE.md`). This blocks completion on three grounds:
(1) the template's entire purpose — teaching non-developers building with AI — is undelivered (총회 registration
onboarding, env/secrets, Zion 로그인 flow, the local permission model, ZCS usage, 위아원 QR **consume** rules,
"copy notices to add a feature", run-locally); (2) several privacy cautions were explicitly *routed to CLAUDE.md*
(P-5 beginner "never log" rule + AC-7.4 grep, P-7 framing, P-10 DSR) and are therefore not reaching the audience;
(3) the S-1 public-exposure warning has nowhere to live. *Fix:* author `CLAUDE.md` per the spec §7 milestone-8 outline;
include the S-1 docker-compose warning and the P-5/P-7/P-10 privacy guidance. **Sign-off cannot be granted until this
exists.** (Note: this may be in progress by another agent — the orchestrator must confirm before declaring done.)

## Verdict

**BLOCKED** — 1 Blocker (B-1, missing `CLAUDE.md`). The **code is sign-off quality** (no security/privacy leaks,
builds + vet clean, contracts consistent, ZCS vendoring clean and source untouched). On delivery of `CLAUDE.md` with
the S-1 warning and the carried-forward privacy guidance, this flips to **PASS-WITH-NOTES**, with:
- **Accepted-risk Major:** S-1 (docker-compose open-by-default local stack) — acceptable only once the CLAUDE.md
  local-only warning lands; flipping the `DEV_BYPASS_AUTH`/`JWT_SECRET` defaults is the stronger fix.
- **Minors to schedule:** P-8 (fake sample IDs), P-10/P-7 (privacy guidance into CLAUDE.md), D-1 (name-resolution
  comment), D-2 (nav key).

---

---

# CR-02 Final Review — Shell / Nav / Session Mgmt / Activity Audit (code stage, 2026-07-01)

> Scope: the CR-02 surface only (`internal/activity`, `internal/sessionmgmt`, `internal/session`,
> `internal/access`, `internal/auth`, `internal/notices`, `store/migrations/0002`, `cmd/server/main.go`;
> frontend `config/nav.ts`, `NavTree`, `Topbar`, `MyInfoDrawer`, `HamburgerButton`, `LogoutButton`,
> `Sidebar`, `AppShell`, `SessionsPage`, `ActivityLogPage`, `lib/activity.ts`, `lib/role.ts`,
> `styles/zcs-a11y.css`). Unchanged spine re-verified only where CR-02 touches it.
> Builds run: `go build ./...` PASS, `go vet ./...` PASS, `npm run build` (tsc --noEmit && vite build) PASS.
> Dynamic scope NOT exercised (no DB/ZAuth in the review env) — static cross-verification + builds; see `05`.

## Carried-forward items from the prior pass

- **B-1 (Blocker, missing `CLAUDE.md`) — RESOLVED.** `CLAUDE.md` and `README.md` now exist at the
  template root; CLAUDE.md points at README §7 (privacy: no PII in logs/URLs) as the SoT.
- **S-1 (Major, docker-compose open-by-default) — MITIGATED to the stronger fix.**
  `docker-compose.yml:59` now defaults `DEV_BYPASS_AUTH: ${DEV_BYPASS_AUTH:-false}`, so the
  test-login super-admin-minting route is **absent by default**; the file carries a LOCAL-ONLY
  banner (`:10`) and README documents the dev-bypass as local-only (`:72`). The passing `JWT_SECRET`
  default remains (`:44`) but is inert without dev-bypass. No longer an accepted-risk gate.
- **D-1 / D-2 — effectively closed.** `types/api.ts:54-59` now states the Bearer-only "no name
  resolution" reality accurately; `config/nav.ts` no longer references a `qr` nav key.

## Security

The three new endpoints are correctly gated and the CR-02 code contains **no permission-bypass,
IDOR, injection, or secret-leak defect**.

- **Super-admin-only, server-gated, fail-closed (PASS).** `GET /api/activity`, `GET /api/sessions`,
  `DELETE /api/sessions/{id}` all register through `g.Super` (`main.go:95-97`). `guard.gate` resolves
  access live per request and allows only `d.Super` (`guard.go:53-55, 57-73`); `Super` comes solely
  from the authenticated Principal (the ZAuth authority snapshot), never from the grant table
  (`access.go:62-65`) — **no delegate/staff path** can reach these screens. Auth/Evaluate errors
  fail closed (`guard.go:64-66`, `access.go:71`).
- **Session revoke is IDOR-safe (PASS).** Addressed by opaque uuid; `LoadRow` → nil → `404`
  (`sessionmgmt/handlers.go:62-70`); 고유번호 never in the URL (only the opaque session id). Revoke is
  idempotent (`session.go:185-190`).
- **No token / no over-exposure on /api/sessions (PASS).** The DTO returns
  `id,newNo,name,loginAt,lastSeenAt,idleExpiresAt,isCurrent` only (`sessionmgmt/handlers.go:41-49`);
  no token field exists on the row path. newNo/name are justified by the super-only surface.
- **Self-revoke handled safely (PASS).** Backend allows it (`isCurrent` is informational); the
  frontend confirms, then clears the token and routes to login (`SessionsPage.tsx:56-62`).
- **Removed `/api/access/audit` — no dangling hole (PASS).** The route is unregistered and the old
  `access.Handlers` audit method is gone; the unified `GET /api/activity` (super-only) is the sole
  reader. Grant/revoke history is filterable via `?action=GRANT,REVOKE`.
- **Activity write paths cannot be forged (PASS).** `actor_no` is always the authenticated
  `p.NewNo`; `action`/`target`/`detail` are server-controlled (notice id, server-resolved grant
  고유번호, path session id, role string). All inserts parameterized (`activity.go:47-49`). Grant/revoke
  audit rows are written **in the same transaction** as the change (`access.go:151, 185`); login/logout/
  notice/session-revoke breadcrumbs are best-effort by design (the action already happened) and log a
  **failure class only, no PII** (`activity.go:60-62`).

No new Security findings.

## Privacy (PIPA + GDPR)

- **New data is super-only + retained + purged (PASS).** `activity_log` (actor/target 고유번호,
  login history) and `sessions.user_name` (login-time name snapshot) are reachable **only** through
  the `g.Super` endpoints — never a staff/feature API. Retention: `AUDIT_RETENTION_DAYS=365`
  (`config.go:78`) + `SESSION_PURGE_DAYS=90` (`config.go:77`); `server purge` applies both
  (`main.go:134-145`, `store.go:99-126`). The name snapshot lives in the session row → purged with
  the session, the same scoped exception accepted for notices (P-3) — documented in the migration.
- **Migration 0002 does not widen exposure (PASS).** `ALTER ... ADD user_name` and the
  `access_audit → activity_log` copy preserve the same super-only access posture; `access_audit` is
  dropped after the copy. Multi-statement migration runs as one implicit Postgres transaction (pgx
  simple protocol) → atomic; `schema_migrations` records each file once (`store.go:69-92`), and 0001
  always creates `access_audit` before 0002 reads it.
- **No 주민번호 / no unexpected PII in target/detail (PASS).** `detail` for grants is `STAFF` /
  `STAFF+MANAGE` only (`access.go:192-197`); `target` is a 고유번호 (super-only surface), a notice id, or
  an opaque session id. SESSION_REVOKE records the opaque session id, not the revoked user's 고유번호 —
  correct minimization. idNumber/주민번호 never requested, stored, or logged anywhere in the CR-02 surface.

### Findings

**[Minor] M-1 — migration 0002 drops the delegate marker from historical GRANT rows.**
`store/migrations/0002_activity_log.sql:27-28` maps only the old `role` column into the new `detail`,
discarding `access_audit.can_manage_access`. A historical delegate grant that should read `STAFF+MANAGE`
will show as `STAFF` in the unified log. Audit-history fidelity only — not a privacy/security issue.
*Fix:* `SELECT actor_no, action, target_no, CASE WHEN can_manage_access THEN role || '+MANAGE' ELSE role END, created_at FROM access_audit;`

## Design (SOLID + clarity)

- **Nav engine (PASS).** `config/nav.ts` is a typed `NavNode` tree (item | group, optional `visible`
  predicate); `NavTree.tsx` renders it recursively with unbounded depth (a group child may be a group),
  auto-expands the active trail, and persists open state. Clean SRP split (config vs. renderer vs.
  shell), no speculative abstraction. Visibility predicates only hide — server is the gate.
- **Single-source label maps (PASS).** `lib/activity.ts` (`ACTION_LABELS` + `ACTION_ORDER`) and
  `lib/role.ts` (`roleLabel`) are the sole code→Korean mapping; both the table and the filter dropdown
  read the same map, both the sidebar footer and 내 정보 drawer read `roleLabel`. Unknown/future action
  codes degrade to "기타 활동" rather than leaking a raw code.
- **Vendored ZCS untouched (PASS).** All CR-02 nav/footer styling lives in `src/styles/zcs-a11y.css`
  (`.nav-item/.nav-group/.nav-sub/.nav-chev/.sidebar-logout`, `text-decoration:none`); no edits under
  `frontend/zcs/`. (Source `/Users/mins/Workspace/zcs` not present in this env to `diff`, but the change
  set is isolated to the override layer and the build only emits the override CSS.)

No new Design findings.

## CR-02 Verdict

**PASS-WITH-NOTES.** All four CR-02 dimensions pass: the three new endpoints are super-admin-only,
server-gated, fail-closed, IDOR-safe and token-free; the new audit/session data is minimized,
super-only, and retention-bounded; the nav engine and label maps are clean with the vendored ZCS
untouched; contracts and types are in lockstep and all builds are green. The prior Blocker (B-1) is
resolved and the prior accepted-risk Major (S-1) is mitigated to its stronger form.

- **Open Minors (schedule, non-blocking):** M-1 (migration delegate-marker fidelity); plus the
  still-cosmetic carry-forwards P-8 (obviously-fake sample 고유번호 in `DevLoginPanel`/contract examples)
  and the AppShell `/qr → qr.title` reference-route mapping (harmless, route intentionally unlinked).
- **Unverified (dynamic):** no live boot/OAuth/heartbeat/idle-expiry/force-logout round-trip — see `05`.
