# API Contracts — ZCS Admin Template (Go backend)

> Source of truth for the frontend. Keep this in sync with `backend/` on every change.
> Backend stack: **Go (stdlib net/http, Go 1.22+ method mux)** + PostgreSQL. Three
> direct deps: `jackc/pgx/v5`, `golang-jwt/jwt/v5`, `google/uuid`.

## Conventions (read first)

- **Base path:** all endpoints are under `/api`. Default backend port `8080`.
- **Field casing:** `camelCase` everywhere.
- **Timestamps:** ISO 8601 UTC strings (e.g. `2026-06-30T12:00:00Z`).
- **Success wrapping:**
  - **List endpoints** return `{ "items": [ ... ] }` (never a bare array).
  - **Single-resource** endpoints return the object directly (no wrapper).
  - **No-content** actions (logout, delete) return `204` with an empty body.
- **Error envelope (every error):**
  ```json
  { "error": { "code": "FORBIDDEN", "message": "이 화면을 볼 수 있는 권한이 없습니다. ..." } }
  ```
  `message` is a humanized Korean, user-displayable string. Prefer branching on
  `code` (stable) over `message` (copy may change).
- **Error codes:** `UNAUTHORIZED`, `SESSION_REVOKED`, `SESSION_EXPIRED` (all HTTP 401),
  `FORBIDDEN` (403), `NOT_FOUND` (404), `BAD_REQUEST` (400), `INTERNAL` (500).
- **Auth header:** authenticated calls send `Authorization: Bearer <appToken>`
  (the token from the callback, stored in `localStorage`). The ZAuth access_token
  is never exposed to the frontend.

### The three 401 codes (distinct frontend copy)
| code | meaning | suggested UX |
|------|---------|--------------|
| `UNAUTHORIZED` | missing/invalid token | route to login silently |
| `SESSION_REVOKED` | logged out elsewhere / already revoked | "다른 곳에서 로그아웃되었습니다" → login |
| `SESSION_EXPIRED` | idle or absolute expiry | "한동안 사용하지 않아 로그아웃됐습니다" → login |

A 401 on **any** request (including heartbeat) means the session is dead — drop
the token, do not retry, route to login showing the code-specific message.

### Access gating → ZCS `noperm`
A gated endpoint called without sufficient access returns **403 `FORBIDDEN` with no
data**. The frontend renders the ZCS `noperm` (권한 없음) state on 403. Menu hiding
is convenience only — the server is the real gate (AC-5.3).

---

## 1. Auth & session

### `GET /api/auth/login`  (browser redirect, no token)
Point the browser at this URL (`window.location.href = "{API}/api/auth/login"`).
302 → Zion 로그인. Sets a short-lived HttpOnly state cookie.

### `GET /api/auth/callback?code&state`  (browser redirect, no token)
Handled entirely server-side. On success: `302 → {FRONTEND_URL}/#/auth/callback?token=<appToken>`.
On failure: `302 → {FRONTEND_URL}/#/login?error=<code>` where `error ∈ {state_mismatch, oauth_failed}`.
Frontend `OAuthCallback`: read `token` from the hash, store in `localStorage["auth_token"]`, go to the app.

> Fail-closed (AC-1.3): if `/me` OR the authorities lookup fails, login fails →
> `#/login?error=oauth_failed`. The user is never treated as super-admin or staff.

### `GET /api/auth/me`  (auth)
```json
{
  "user":   { "newNo": "00341130-00036", "name": "홍길동",
              "tribe": "베드로지파", "church": "서울교회", "duty": "부장" },
  "access": { "super": false, "hasAccess": true, "canManageAccess": false },
  "session": {
    "id": "uuid", "createdAt": "...", "lastSeenAt": "...",
    "expiresAt": "...", "idleExpiresAt": "...", "usageSeconds": 1234
  },
  "heartbeatSeconds": 60
}
```
- `user.newNo` is the caller's **own** record → always full (never masked).
- `tribe/church/duty` may be empty strings.
- **Gate the UI from `access`:** `hasAccess=false` → show `noperm`; show the
  고유번호 접근 관리 menu only when `canManageAccess=true`; super-only screens
  (audit) only when `super=true`.

### `POST /api/auth/logout`  (auth) → `204`
Revokes the current session.

### `POST /api/sessions/heartbeat`  (auth) → `200`
Cheapest authed request; keeps the session alive AND returns the refreshed session
block so the frontend can **reset its idle auto-logout countdown** on activity. The
request pipeline advances `lastSeenAt` before the handler runs, so the returned
values are post-activity. Call every `heartbeatSeconds` while the tab is active and
visible. A 401 here means the session is dead (do not retry).
```json
{ "session": {
  "id": "uuid", "createdAt": "...", "lastSeenAt": "...",
  "idleExpiresAt": "...", "expiresAt": "...", "usageSeconds": 1234
} }
```
Same `session` serialization as `GET /api/auth/me`. Drive the countdown from
`idleExpiresAt` (recomputed from the just-advanced `lastSeenAt`).

### `POST /api/auth/test-login`  (DEV only)
Present only when `DEV_BYPASS_AUTH=true`; otherwise `404`. Mints a real session
without Zion 로그인 (local dev before 총회 registration).
Request: `{ "newNo": "...", "name": "...", "super": false }` → `200 { "token": "<appToken>" }`.

---

## 2. 고유번호 접근 관리 (local access grants)

Gating: **list / upsert / delete require `canManageAccess`** (super-admin or a
delegate). **audit requires `super`.**

> **고유번호 never travels in a URL** (privacy P-6): create/update carry it in the
> request **body**; delete addresses the row by its opaque `id`. Each grant row
> has an `id` (the URL handle) distinct from `newNo` (the business key).

### `GET /api/access/grants`  (manage)
```json
{ "items": [
  { "id": "f1c2...-uuid", "newNo": "00341130-00036", "role": "STAFF",
    "canManageAccess": false, "grantedBy": "00341130-00001", "grantedAt": "...",
    "confirmed": true, "confirmedAt": "..." }
] }
```
- `id` is the opaque handle — pass it to DELETE. Do not display it.
- `newNo` and `grantedBy` shown in full (public working key).
- `confirmed=false` (and `confirmedAt=null`) → the person has not logged in since
  being granted → render a **미확인** badge (AC-3.5).
- `role` is always `"STAFF"` in this template (single role). Never render the raw
  code — map to a label (e.g. "운영자"); `canManageAccess=true` → "운영자 · 접근 관리 위임".

### `PUT /api/access/grants`  (manage)  — no path param
Idempotent create/update by 고유번호 (AC-3.3).
Request: `{ "newNo": "00341130-00036", "role": "STAFF", "canManageAccess": false }`
(`role`/`canManageAccess` optional; role defaults to `STAFF`).
Response `200`: the grant object (same shape as a list item, including `id`).
- **Escalation rule:** setting `canManageAccess=true` requires the caller to be
  **super-admin**; a delegate attempting it gets `403 FORBIDDEN`. (A delegate can
  grant staff, but cannot mint new delegates.)
- Malformed `newNo` or invalid role → `400 BAD_REQUEST`.

### `DELETE /api/access/grants/{id}`  (manage) → `204`
Revoke by the opaque grant `id` from the list. `404` if the id is unknown. The
target hits `noperm` on their next gated request (AC-4.1). Super-admin status is
not in this table and cannot be removed here (AC-4.2).

> **REMOVED — `GET /api/access/audit`** (change 02): superseded by the unified
> **`GET /api/activity`** (§6), which is also super-admin only. Grant/revoke
> history now lives in the unified activity log; filter it with
> `GET /api/activity?action=GRANT,REVOKE`.

---

## 3. 공지사항 (notices) — the worked example

Gating: all endpoints require **`hasAccess`** (super-admin or staff). Ungranted → `403`.

**Notice object (final shape — `authorName` only, never `authorNo`):**
```json
{ "id": 12, "title": "...", "body": "...",
  "authorName": "홍길동", "createdAt": "...", "updatedAt": "..." }
```

### `GET /api/notices`  (access) → `{ "items": [ <notice> ] }`

### `GET /api/notices/{id}`  (access) → notice object (404 if missing)

### `POST /api/notices`  (access)
Request: `{ "title": "...", "body": "..." }` (title required) → `201` notice object.
Author captured server-side from the caller's session: the 고유번호 is stored
internally for accountability, and the **display name is snapshotted** at creation.

### `PUT /api/notices/{id}`  (access)
Request: `{ "title": "...", "body": "..." }` → `200` notice object (404 if missing).
Any granted staff may edit any notice (per-author ownership is a documented
extension). The author-name snapshot is immutable (unchanged on edit).

### `DELETE /api/notices/{id}`  (access) → `204` (404 if it never existed)

> **Privacy — author display (P-3, final decision):** the notices API returns
> **only `authorName`** — a point-in-time snapshot captured from the author's own
> session at creation. The author's **고유번호 is NEVER returned** by any notices
> endpoint (kept internally for accountability only). 주민번호 is never present
> anywhere. Frontend: render `authorName`; there is no `authorNo` field.

---

## 4. 위아원 QR issuance

Gating: requires **`hasAccess`**. Issuance only — there is no consume endpoint
(documented pattern in `CLAUDE.md`).

### `POST /api/qr/issue`  (access)
Request: `{ "ref": "<item id or key>" }` (non-empty).
Response `200`:
```json
{ "scanUrl": "https://<QR_SCAN_BASE_URL>/scan?d=<base64url-token>" }
```
- The frontend renders `scanUrl` as a QR image (use a client-side QR lib — the
  backend deliberately ships no image dependency).
- The signed token appears only inside `scanUrl`. **Never log it; strip it from
  the URL after consumption.** Empty `ref` → `400` (`error.qr_target_empty`).

---

## 5. Health

### `GET /api/health`  (no auth) → `200 { "status": "ok" }` (503 if DB is down)

> Note (change 02): the 위아원 QR endpoint (§4) stays available but is **removed
> from the shell navigation**. It remains as a reference example.

---

## 6. 보안·감사 (security & audit) — SUPER-ADMIN ONLY

Both screens are **super-admin only, server-gated, fail-closed**. A non-super
caller gets `403 FORBIDDEN` (frontend renders `noperm`). 고유번호/login history
appear here because the surface is super-admin only; tokens are never exposed.

### `GET /api/sessions`  (super only) — 세션 관리
Active sessions only (not revoked, not past absolute/idle expiry), newest activity first.
```json
{ "items": [
  { "id": "uuid", "newNo": "00341130-00036", "name": "홍길동",
    "loginAt": "...", "lastSeenAt": "...", "idleExpiresAt": "...", "isCurrent": false }
] }
```
- `id` is the opaque session handle → pass it to DELETE. No token is ever returned.
- `name` is the login-time snapshot (may be empty for legacy rows).
- `isCurrent=true` marks the caller's own session → the frontend confirms before self-revoke.

### `DELETE /api/sessions/{id}`  (super only) → `204` — 강제 로그아웃
Revoke a session by its opaque id (reuses the standard revoke). `404` if the id is
unknown. Self-revoke is allowed (frontend confirms). The revoked user gets
`SESSION_REVOKED` on their next request. Logged as `SESSION_REVOKE` in the activity log.
**고유번호 is never accepted in the URL** — only the opaque session id.

### `GET /api/activity`  (super only) — 활동 감사 로그
Unified audit log, newest first, paginated.
Query params (all optional): `limit` (default 50, max 200), `offset` (default 0),
`action` (repeatable or comma-separated), `from`/`to` (ISO date `2006-01-02` or RFC3339).
```json
{ "items": [
  { "id": 42, "actorNo": "00341130-00001", "action": "GRANT",
    "target": "00341130-00036", "detail": "STAFF+MANAGE", "createdAt": "..." }
], "total": 137, "limit": 50, "offset": 0 }
```
- `action ∈ { LOGIN, LOGOUT, NOTICE_CREATE, NOTICE_UPDATE, NOTICE_DELETE, GRANT, REVOKE, SESSION_REVOKE }`.
- `target` (nullable): for GRANT/REVOKE = the affected 고유번호; for NOTICE_* = the
  notice id; for SESSION_REVOKE = the revoked session's opaque id; for LOGIN/LOGOUT = `null`.
- `detail` (nullable): small context, e.g. a grant's role (`STAFF`, `STAFF+MANAGE`).
- Map `action` codes to Korean labels in the UI (no raw codes shown to users).
- Use `total` with `limit`/`offset` for paging.

---

## Open-question resolutions (from the PM spec §9)
- **Q1 (super-admin match):** exact, case-sensitive membership of
  `SUPER_ADMIN_AUTHORITY` in the resolved authority set (roleBased ∪ orgBased
  ALLOW, minus orgBased DENY). Only this string is read; duties are never inspected.
- **Q4 (QR scope):** issuance endpoint only (`POST /api/qr/issue`); consume rules
  are documented, not shipped.
