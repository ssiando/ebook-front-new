# Change Request 02 — Shell / Navigation / Session & Audit

Builds on the existing template. Keep everything already working (Zion 로그인, local
고유번호 permission model, ZCS-only styling, privacy rules). This is a shell + features
iteration. All user-facing copy Korean, humanized; no developer terminology; never "ZAuth".

## 1. Navigation menu — redesign + nesting
- The current nav looks poor and shows **underlines** on items — remove all text-decoration
  underlines; use the ZCS sidebar nav idiom (hover/active via background + left accent rail,
  not underline). Active route clearly indicated without underline.
- Support a **2–3 level deep nested menu** (collapsible groups → items → optional sub-items).
  Build a small **nav config** (a typed tree) that the sidebar renders recursively, so a fork
  adds nested menus by editing config, not JSX. Groups expand/collapse; remember open state;
  keyboard-accessible (focus-visible, Enter/Space toggles a group, arrow nav optional).
- Nesting CSS goes in the template override layer (`src/styles/zcs-a11y.css` or a new app
  stylesheet) — **do NOT edit the vendored `frontend/zcs/`**. List the nested-nav styles as a
  proposed ZCS backport.
- Reasonable grouping of the current features (demonstrating depth), e.g.:
  - 공지사항  (top-level item)
  - 접근 관리 (group) → 고유번호 접근 관리
  - 보안·감사 (group) → 활동 감사 로그, 세션 관리
  The engine must clearly support a 3rd level even if seed content is mostly 2 deep.

## 2. Remove 위아원 QR 발급 from the menu
- Remove the QR issuance nav item. The QR page/route is no longer linked from the shell.
  (Keep the QR backend endpoint + page code in the repo as a reference example, just not in
  the nav — or remove the route entirely if cleaner; do not break the build.)

## 3. Top-right = hamburger → 내 정보 (replaces the logout button)
- Replace the top-right logout control with a **hamburger / menu button** that opens a panel
  (ZCS `drawer` or a menu/popover) showing **내 정보**: name, **고유번호 (full, labeled)**,
  tribe/church/duty (display-only from session), role (운영자 / 위임 / 슈퍼어드민 in plain
  Korean), and **current session info** (로그인 시각, 마지막 활동, 자동 로그아웃까지 남은
  시간 / 유휴 만료). No raw codes/ids.

## 4. Bottom-left = logout
- Put the **로그아웃** action in the sidebar **footer (bottom-left)**. Calls
  `POST /api/auth/logout`, then routes to login.

## 5. Session management (현재 로그인 사용자 + 세션 관리)
- Always make the **current logged-in user** obvious (the 내 정보 hamburger covers this; also
  show name in the shell).
- Add a **세션 관리** screen (super-admin only) listing **active sessions**: user (name +
  고유번호), 로그인 시각, 마지막 활동(last seen), 유휴 만료, current-session marker. Allow
  **강제 로그아웃 (revoke)** of a session by its opaque id. The current session row is clearly
  marked and protected from accidental self-revoke (confirm).
- Backend: add `GET /api/sessions` (list active; super-admin only) and
  `DELETE /api/sessions/{id}` (revoke; super-admin only). Reuse the existing sessions table +
  revoke logic. Never expose tokens. 고유번호 body/opaque-id only, never in URLs except the
  opaque session id. Update `api_contracts.md`.

## 6. Activity audit log (활동 감사 로그)
- Add a broader **활동 감사 로그**: record key actions with actor 고유번호, action, target
  (opaque/where relevant), and timestamp — at minimum: 로그인 / 로그아웃, 공지 작성·수정·삭제,
  접근 권한 부여·회수, 세션 강제 로그아웃. Reuse/extend the existing grant/revoke audit infra
  (e.g. a unified `activity_log`, or keep `access_audit` and add `activity_log` for the rest —
  pick the cleaner design and state it; the screen may show a unified view).
- **세션 관리** screen and **활동 감사 로그** screen are **super-admin only** (fail-closed,
  server-gated). View = read-only, filterable by action/date if cheap.
- Backend: `GET /api/activity` (super-admin only, paginated `{items:[...]}`). Log entries
  written from the relevant handlers. Update `api_contracts.md`.

## Privacy/security (unchanged bar)
- The new audit/session data contains 고유번호 and login history → **super-admin only**,
  never on a non-admin API, never in logs, retained under the existing
  `AUDIT_RETENTION_DAYS` purge (extend `server purge` to the new table). 주민번호 never touched.
- Server-side gating on every new endpoint; fail closed. No PII in URLs (opaque ids only).
