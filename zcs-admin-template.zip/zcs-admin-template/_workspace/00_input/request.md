# Build Request — ZCS Admin Template (하달용 초보자 어드민 템플릿)

## Goal
A **distributable, beginner-friendly admin template** for the 신천지행정시스템 family.
The people who will USE this template build their systems **with AI only** (no coding background).
So the template must be a clean, minimal, correct scaffold whose `CLAUDE.md` documents **every
important caution in detail and kindly** — it is the primary teacher.

## Target directory
`/Users/mins/Workspace/zcs-admin-template`

## Confirmed decisions (SSOT — do not re-litigate)

### Stack
- **Backend: Go, standard-library based** (mirror the verified `zauth-integration` backend-go canon;
  sessions/masking/audit/secure cookies). **Do NOT reuse zadmin code.** Justify any extra dependency.
- **DB: PostgreSQL.**
- **Frontend: React 19 + Vite + TypeScript**, HashRouter.
- **Local dev: docker-compose** (frontend/nginx + Go backend + postgres). Infra handoff doc only —
  NO K8s/GitLab CI artifacts (not requested).

### Design system — ZCS (NOT ZDS)
- Use **ZCS = Zion Console System** at `/Users/mins/Workspace/zcs/` (plain-CSS class system,
  cobalt accent `#2f5bd0`, 13px body / 32px controls, table- & bar-first, 12-tribe palette for ID only).
- **Vendor ZCS into the template** (`frontend/zcs/` copy + link `styles.css`) and add a **sync script**
  (`npm run sync:zcs`, analogous to ZDS's `sync:zds`) so ZCS refreshes from the source folder.
  This template is the FIRST ZCS-vendoring reference — make the pattern clean and documented.
- "어떤 기능이든 ZCS를 쓸 수 있다": every screen/feature is built from ZCS classes only (no raw hex,
  no second UI kit). ZCS already ships `login` (Zion Login), `tbl`, `modal`, `drawer`, `sidebar`/`topbar`
  shell, `badge`, `masked`, `noperm`, `emptystate`, etc.

### Auth — Zion 로그인 (ZAuth)
- Login via **Zion 계정** (ZAuth OAuth2). Never say "ZAuth" in end-user copy — it is developer terminology.
- On callback: exchange code → token, fetch `/me` (newNo/name/tribe/church/duty) + user-authorities.

### Permission model — OVERRIDES the orchestrator's permission base rule (user-directed)
This template **does NOT** implement the standard ZAuth user-authorities RBAC matrix, the permission
**catalog/guide page**, or the ZAuth-driven grantee model. Instead:
1. **Super-admin = the ZAuth user-authorities authority `ZADMIN-TEMPLATE-SUPER`** (exact string,
   hyphenated — use verbatim). This is the only thing read from user-authorities. Fail-closed if the
   lookup fails. In the ZAuth console this authority is mapped to: the platform **superadmin**, each
   church's **정보통신부장**, and the **전산개발과장**. The app only checks "does user-authorities
   contain `ZADMIN-TEMPLATE-SUPER`?" — it does NOT hardcode duties; the duty→authority mapping lives
   in the ZAuth console (document this in CLAUDE.md / infra handoff). Make the authority string a
   single config constant (env-overridable) so forks can rename it.
2. **All other access is assigned LOCALLY by 고유번호 (newNo)** through **one local page**
   ("고유번호 접근 관리"): super-admin (or a delegate the super-admin grants) adds/removes newNos
   with a role/scope. A logged-in user whose newNo is in the local grant table gets that access;
   otherwise they hit the ZCS `noperm` state.
3. **No permission catalog/guide page. No full RBAC matrix.** The local access-management page is the
   ONLY permission-related screen.
4. Bootstrap: the ZAuth super-admin is the escape hatch — they can always access and seed the first
   local grants.
- User-facing copy rules still apply: no raw permission codes / internal IDs / enum values in UI;
  **고유번호 is shown in full, labeled '고유번호'**; the national-ID-grade field `idNumber`(주민번호) is
  never decrypted/shown. Permissions described in plain language, never "by ZAuth / in the ZAuth console".

### 위아원 (WeAreOne) QR — issuance pattern + docs
- Include **one QR issuance pattern**: the admin generates an **HMAC-signed static QR** (edux model:
  payload `{v,...,sig}`, `sig=HMAC-SHA256(QR_SECRET, ...)`, base64url, embedded in a plain HTTPS scan URL).
  Members scan it with the **위아원 app**. Own `QR_SECRET` env var — do NOT depend on a WAO signing service.
- Document the WAO integration in CLAUDE.md: how the QR is consumed, that the WAO auth handoff
  (`wao_authentication` → ZAuth) exists as a further option, single-use/short-TTL/never-log/strip-from-URL
  rules. (Reference impls: `edux/backend/app/core/qr.py`, `qr-attend/backend/app/services/zauth.py`.)

### 총회 등록 (General Assembly registration) — MANUAL prerequisite, document prominently
- Using Zion 로그인 + member data is **NOT self-service**. The operator must **manually contact the
  총회 (HQ / 전산팀)** to register the app and obtain a **`client_id` (= REST API Key; there is NO
  client_secret)**, register the OAuth callback/redirect URL, and — if any server-to-server call is
  needed — get **Admin-API approval + an Admin Key**. App-specific authorities (incl. SUPER_ADMIN)
  must be registered in the auth console and mapped to people. Until then the app behaves "as if
  unregistered". CLAUDE.md must explain this as the very first onboarding step, kindly and concretely.

### i18n
- **Korean-only**, but all user-facing text via translation **keys / a single ko locale file** so it is
  trivially extensible later. ko copy must be humanized (no AI-flavored Korean).

### Sample feature
- One worked example resource: **공지사항 (notices) CRUD** demonstrating ZCS components + the local
  access gate + member-data display (author by name/고유번호). Beginners copy this to add features.

## Primary deliverable emphasis
`CLAUDE.md` at the template root is the **central deliverable** — detailed, kind, beginner-oriented.
It must cover: 총회 registration prerequisite, env/secrets setup, Zion 로그인 flow, the local
고유번호 permission model + super-admin, ZCS usage ("how to build any feature with ZCS"), 위아원 QR
usage, privacy/security cautions (PIPA — 고유번호 vs idNumber, masking, audit, no PII in logs), how to
add a new feature (copy the notices example), and how to run locally.
