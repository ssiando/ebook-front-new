# 06 — i18n Guide (ZCS Admin Template, frontend)

## Summary

- **Source / only language:** Korean (`ko`). The template ships **Korean-only** UI,
  but **every user-facing string goes through a translation key** — there are no
  hardcoded strings in components. Adding a language later is a drop-in, not a
  rewrite.
- **Store:** a single git-tracked file, `frontend/src/locales/ko.json`. Git is the
  single source of truth for all translation values (no external TMS — i18n skill
  light path).
- **Runtime:** a tiny homegrown `t()` / `tNode()` resolver
  (`frontend/src/i18n/index.ts`). **No react-i18next** — justified: one language,
  no ICU plurals, internal admin tool. The structure stays framework-compatible so
  a fork can migrate if it ever needs many languages / lazy bundles.
- **ko humanization:** all explanatory / error / empty / caution copy was reviewed
  against the AI-tell taxonomy (humanize-korean skill) before delivery. The strings
  are short UI microcopy already in natural Korean; a few were tightened for
  naturalness (e.g. QR caution lines, the no-permission description).

## How to use a key

```tsx
import { t, tNode } from "../i18n";

t("notices.title");                       // "공지사항"
t("access.revokeModal.desc", { name });   // interpolation: "{name} 님은 …"
tNode("common.countItems", "count", <b>{n}</b>);  // inject a React node into a slot
```

- **Interpolation:** `{name}` placeholders, filled from the vars object.
- **`tNode`:** when one slot must be a React node (e.g. a bold count), so markup
  stays out of the locale file and we avoid `dangerouslySetInnerHTML`.
- **Fallback:** missing key → source language → the key string itself (never a
  crash, never a blank).

## Namespaces (top-level keys in `ko.json`)

| Namespace | Covers |
|-----------|--------|
| `app` | system name / brand sub / system label |
| `common` | shared buttons, states, count/range strings, `고유번호` label |
| `login` | login screen, redirect/error copy, dev-login panel |
| `session` | the two distinct dead-session messages (expired / revoked) |
| `shell` | nav labels, role labels, logout, menu toggles |
| `noperm` | 권한 없음 title/description + self 고유번호 hint |
| `notices` | list/form/detail/delete, columns, validation, toasts, empty/error |
| `access` | 고유번호 접근 관리: table, add/revoke modals, audit tab, toasts, empty/error |
| `qr` | 위아원 QR 발급: form, actions, idle hint, caution block, error |
| `errors` | generic + forbidden fallbacks |

## Key naming rules

- **Domain-based namespacing**, named by **meaning**, not screen position:
  `notices.col.author`, `access.addModal.newNoLabel` — robust to reuse and moves.
- Plurals: Korean needs no grammatical plural; counts are rendered with a counter
  word (`총 {count}건`, `총 {count}명`) and `tNode` for the bold number.
- Dates/numbers: never hardcoded — `Intl.DateTimeFormat("ko-KR", …)` via
  `src/lib/format.ts` (`formatDate`, `formatDateTime`). 고유번호 stays `.mono` +
  tabular regardless of locale.

## No developer terminology (house rule, enforced in copy)

The locale contains **no** permission codes, enum values, internal ids, or the word
"ZAuth". Role codes map to labels (`STAFF` → `운영자`; delegate → `운영자 · 접근
관리`); the auth platform is surfaced as **"Zion 계정"**. 고유번호 is always
labeled **고유번호** and shown in full; 주민번호/idNumber never appears.

## Completeness status

| Language | Status | Untranslated keys | ko humanization |
|----------|--------|-------------------|-----------------|
| `ko` (source) | ✅ complete | 0 | ✅ reviewed |

No other languages are shipped (Korean-only scope). When one is added: create
`locales/<lng>.json` mirroring every key in `ko.json`, register it in
`src/i18n/index.ts` `bundles`, select it via `localStorage["language"]`, and pass
it as `Accept-Language` on API calls so backend messages match. Any key missing in
a new language falls back to `ko` and should be listed here as untranslated.

## Adding a new language later (checklist)

1. Copy `ko.json` → `locales/<lng>.json`; translate values (keys unchanged).
2. `import` it and add to `bundles` in `src/i18n/index.ts`; set `SOURCE_LNG` stays
   `ko` as fallback (or switch the fallback policy deliberately).
3. Add a language switcher (ZCS ships `.lang` / `.lang-menu` classes) writing
   `localStorage["language"]`.
4. Send `Accept-Language` on API requests (extend `services/api.ts`) so backend
   error messages localize too.
5. Run the value review (humanize-korean for ko edits; native review for others) in
   the same PR.
