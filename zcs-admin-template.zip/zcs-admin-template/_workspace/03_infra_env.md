# Infra Handoff — ZCS Admin Template (Go backend)

For the infra team. Scope of this handoff: **working code + local docker-compose +
this document.** No Kubernetes / GitLab CI artifacts are produced (not requested).

## 1. 총회 (HQ / 전산팀) registration — MANUAL prerequisite (blocking)

Zion 로그인 + member data is **not self-service**. Before the app can authenticate
anyone, the operator must contact the 총회 to obtain/register:

1. **`client_id` (= REST API Key).** There is **NO `client_secret`** — ZAuth's
   OAuth flow uses `client_id` alone. → `OAUTH2_CLIENT_ID`.
2. **OAuth callback/redirect URL** registered in the auth console, matching the
   deployed value of `OAUTH2_REDIRECT_URI` exactly (`https://<host>/api/auth/callback`).
3. **The super-admin authority** `ZADMIN-TEMPLATE-SUPER` (the value of
   `SUPER_ADMIN_AUTHORITY`) registered in the console and **mapped to people**
   (platform superadmin + each church's 정보통신부장 + 전산개발과장). The app only
   checks for this string; the duty→authority mapping lives entirely in the
   console. At least one person must be mapped before first use (bootstrap).
4. **Admin Key / Admin-API approval — NOT required for this template.** It is
   **Bearer-REST-only**: it makes no server-to-server (Bearer-less) ZAuth calls.
   Member and authority data refresh only during user logins. (If a fork later
   adds a server-to-server call — e.g. refreshing someone's authorities without
   their login — it must request Admin-API enablement + an Admin Key, and that
   key joins the secret list below.)

Until step 1–3 are done the app behaves "as if unregistered" (login fails closed).

## 2. Environment variables

| Variable | Secret? | Default | Purpose |
|----------|:------:|---------|---------|
| `OAUTH2_CLIENT_ID` | no¹ | — | ZAuth REST API Key (the app's client_id). Required. |
| `OAUTH2_AUTH_URL` | no | alpha authorize URL | `{AUTH_URL}/oauth/authorize` (path is `/oauth/`, not `/oauth2/`). |
| `OAUTH2_TOKEN_URL` | no | alpha token URL | `{AUTH_URL}/oauth/token`. |
| `OAUTH2_USERINFO_URL` | no | alpha `/me` URL | `{API_URL}/api/auth/v3_0/me`. |
| `OAUTH2_AUTHORITIES_URL` | no | alpha authorities URL | `{API_URL}/api/external/v1/user-authorities`. |
| `OAUTH2_REDIRECT_URI` | no | (auto-detect) | Set **explicitly in production** to `https://<host>/api/auth/callback`. |
| `SUPER_ADMIN_AUTHORITY` | no | `ZADMIN-TEMPLATE-SUPER` | The single authority string read for super-admin. |
| `JWT_SECRET` | **YES** | `CHANGE_ME` (fails) | App session-token signing key, min 32 chars. `openssl rand -base64 48`. |
| `JWT_EXPIRE_MINUTES` | no | `720` | Absolute session/token lifetime. |
| `SESSION_IDLE_MINUTES` | no | `30` | Idle timeout window. |
| `SESSION_HEARTBEAT_SECONDS` | no | `60` | Heartbeat cadence advertised via `/api/auth/me`. |
| `SESSION_PURGE_DAYS` | no | `90` | Startup purge of long-revoked sessions (`0` disables). |
| `AUDIT_RETENTION_DAYS` | no | `365` | Retention bound for grant/revoke audit rows. Purged only by `server purge` (run on a schedule); `0` keeps forever. |
| `QR_SECRET` | **YES** | — | 위아원 QR HMAC signing key. `openssl rand -base64 48`. Required for QR. |
| `QR_SCAN_BASE_URL` | no | — | Public HTTPS base embedded in the QR scan URL. |
| `DATABASE_URL` | **YES²** | — | Postgres DSN, e.g. `postgres://user:pass@host:5432/db?sslmode=require`. |
| `CORS_ORIGINS` | no | — | Comma-separated. **First entry = the OAuth callback frontend origin.** |
| `FRONTEND_URL` | no | (= first CORS origin) | Where the callback redirects with the token. |
| `DEV_BYPASS_AUTH` | no | `false` | Enables `POST /api/auth/test-login`. **Never `true` in production.** |
| `PORT` | no | `8080` | Listen port. |

¹ `OAUTH2_CLIENT_ID` is not a password (it is the public-ish REST API Key), but it
identifies the app — treat it as configuration, not source-committed.
² `DATABASE_URL` embeds the DB password → provision as a secret.

**Secrets to provision** (secret store, never in code/images): `JWT_SECRET`,
`QR_SECRET`, `DATABASE_URL` (password). No ZAuth Admin Key for this template.

`JWT_SECRET` rule: a missing/short/`CHANGE_ME` value **refuses to boot** unless
`DEV_BYPASS_AUTH=true` (then a per-process secret is generated and logged). So a
production deploy with a placeholder secret fails fast by design.

## 3. Ports & healthcheck

- Backend listens on `:8080` (override with `PORT`).
- **Healthcheck:** `GET /api/health` → `200 {"status":"ok"}` (DB ping included;
  `503` if the DB is unreachable). Used by the Docker `HEALTHCHECK` and any infra probe.

## 4. Build / run / migrate

- **Build (image):** `docker build -t zcs-admin-backend ./backend` (multi-stage,
  static `CGO_ENABLED=0` binary on Alpine).
- **Run locally (full local stack):** from the repo root, `docker compose up -d --build`
  (starts Postgres + backend). Add `--profile frontend` once the frontend is wired.
- **Migrations:** **automatic at every startup.** SQL files are embedded
  (`go:embed`) and applied idempotently, tracked in `schema_migrations` (the
  `alembic upgrade head` analog). There is no separate migration command/Job —
  starting the container is sufficient. New migrations are added as new numbered
  `.sql` files under `backend/internal/store/migrations/` (never edit an applied one).
- **Retention purge:** at startup the app deletes sessions revoked more than
  `SESSION_PURGE_DAYS` ago (a single DELETE, no cron) and logs the count.

## 5. Reverse-proxy / forwarding requirements (critical)

The ZAuth `redirect_uri` must assemble as **https** or the callback fails. The Go
server reads `X-Forwarded-*` directly (no uvicorn-style trust flag), so:

- The proxy (nginx/ingress) **must forward `X-Forwarded-Proto` and `Host`** to the
  backend. Without `X-Forwarded-Proto: https` the auto-detected redirect_uri is
  `http://…` and ZAuth rejects it.
- In production, prefer setting `OAUTH2_REDIRECT_URI` **explicitly** and have the
  proxy **strip/overwrite client-supplied `X-Forwarded-*`** (so a client cannot
  spoof them).
- Route `/api/*` to the backend; serve the SPA for everything else. The OAuth
  state cookie is scoped to `Path=/api/auth` and is `Secure` when the redirect is
  https — keep `/api/auth/*` on the same host as the SPA.

## 6. Logging & privacy posture (operational)

- **No HTTP access logging by design** — request paths/bodies can carry member
  numbers. Only failure *classes* are logged (never tokens, newNo, names, or QR
  payloads). Do not add an access-log middleware in front of the backend that
  records full paths/bodies.
- **고유번호 never travels in a URL** — grants are created by a request body and
  addressed for deletion by an opaque id; notices use an integer id. (Privacy P-6.)
- Persisted member data is minimal: 고유번호 in the grant table + session owner +
  notice author (internal) + activity-log actor/target. The persisted **names** are
  the notice author-name snapshot and the **session name snapshot** (shown on the
  세션 관리 screen) — both deliberate, scoped exceptions (plaintext directory tier,
  session/record-lifetime). Tribe/church/duty live only in the session token.
  주민번호 is never touched.
- **Session & activity data is super-admin only** — `GET /api/sessions`,
  `DELETE /api/sessions/{id}`, and `GET /api/activity` are all super-gated and
  never reachable by a non-admin API. The activity log holds login history +
  고유번호 → treat as sensitive.

## 7. Data retention & purge (PIPA Art. 21 / GDPR Art. 5(1)(e))

The template ships concrete defaults so a fork does not silently keep everything
forever:

| Data | Default retention | How it is purged |
|------|-------------------|------------------|
| `sessions` (revoked) | `SESSION_PURGE_DAYS` (90) | Automatically at every startup, and by `server purge`. |
| `activity_log` (unified audit: login/logout/notice/grant/revoke/session-revoke) | `AUDIT_RETENTION_DAYS` (365) | **`server purge` only** (deliberate — accountability data). |
| `access_grant` (active grants) | until revoked | Hard-deleted on revoke; the revoke is recorded in `activity_log`, which then ages out on the audit bound. |
| `notice` | until deleted by staff | Application action. |

> Change 02 unified all audit into a single `activity_log` table (the old
> `access_audit` table was migrated into it and dropped). `AUDIT_RETENTION_DAYS`
> now governs the whole activity log.

- **Run the purge on a schedule** (cron / a scheduled container/Job), e.g. daily:
  `docker compose run --rm backend /app/server purge` (or `server purge` for the
  binary). It applies both bounds and logs the row counts, then exits. There is
  **no auto-cron inside the app** for the activity log (only the session purge runs at boot).
- Equivalent manual SQL (if a fork prefers a DB-side job):
  ```sql
  DELETE FROM activity_log WHERE created_at < now() - interval '365 days';
  DELETE FROM sessions     WHERE revoked_at IS NOT NULL
                             AND revoked_at < now() - interval '90 days';
  ```
- **Data-subject erasure (PIPA Art. 36 / GDPR Art. 17):** to honor a request,
  delete the person's `access_grant` row(s) and their `notice` rows; `activity_log`
  entries are retained under the accountability legal basis (document this as the
  lawful exception to erasure). `activity_log` is readable by super-admin only.
- **At rest:** 고유번호 needs no column encryption (it is not idNumber), but the DB
  as a whole is a religious-membership dataset → require DB/disk encryption,
  restricted DB credentials, and TLS everywhere (OAuth exchange + DB connection).
