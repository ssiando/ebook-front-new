# ZCS Admin Template — Product Spec (v1)

> Scope note: this is a spec for a **distributable admin template**, not a finished product.
> It defines a correct minimal scaffold plus **one worked example feature (공지사항/notices)** and
> **one worked example integration (위아원 QR issuance)**. People who fork this template are
> **non-developers building with AI**, so every requirement here must be unambiguous and small.
>
> Deliberate deviation from the house permission standard: per the SSOT request, this template
> **overrides** the usual ZAuth `user-authorities` RBAC. There is **NO permission catalog/guide page
> and NO RBAC matrix**. The only ZAuth authority read is the super-admin flag; everything else is a
> **local 고유번호 (newNo) access grant**. Sections 5–6 of the standard product-spec template are
> replaced accordingly (see §5). This is intentional and must not be "corrected" back to the standard.

---

## 1. Overview

### Purpose
Give the 신천지행정시스템 family a clean, copy-to-start admin scaffold that already does the hard,
error-prone parts correctly: Zion 로그인 (ZAuth OAuth2), a simple and safe access model, the ZCS
console look-and-feel, member-data display done within privacy rules, and one end-to-end feature a
beginner can clone to build their own. The template's `CLAUDE.md` is the primary teacher.

### Problem being solved
Non-developers building admin tools with AI repeatedly get auth, permissions, and member-data
handling wrong (over-exposed PII, broken access gates, ad-hoc RBAC). This template removes those
decisions: one login flow, one access model, one privacy posture, one worked example.

### Target users (of systems built from this template)
- **Super-admin (총괄 관리자)** — identified by a single authority in Zion 계정 (`ZADMIN-TEMPLATE-SUPER`,
  env-overridable). In the auth console this authority is mapped to the platform superadmin + each
  church's 정보통신부장 + 전산개발과장; the app **only** checks for the authority string, never the duties.
  Bootstraps the system, manages who else gets in, and can do everything.
- **Locally-granted staff (운영자)** — a logged-in Zion 계정 whose **고유번호** appears in the local
  access table. Sees and uses the feature screens they were granted.
- **Everyone else (logged-in but not granted)** — reaches the ZCS `noperm` (권한 없음) state. No data.

> Note: the template author (the developer/AI forking this) is a third audience, served by `CLAUDE.md`
> — out of scope for this product spec, but the reason the spec stays minimal.

---

## 2. User Stories

- **US-1 (Zion 로그인):** As a staff member, I want to sign in with my Zion 계정, so that I never
  manage a separate password and the system knows who I am.
- **US-2 (Super-admin detection):** As the super-admin, I want the system to recognize my super-admin
  authority automatically at login, so that I can always get in and set things up without anyone
  granting me access first.
- **US-3 (Grant access by 고유번호):** As the super-admin (or a delegate I authorize), I want to add a
  person's 고유번호 to an access list with a role, so that the right staff can use the system.
- **US-4 (Revoke access):** As the super-admin (or a delegate), I want to remove a 고유번호 from the
  access list, so that someone who left immediately loses access.
- **US-5 (Access gating):** As a logged-in user without access, I want a clear "권한 없음" screen
  instead of a broken page or someone else's data, so that I understand I must request access.
- **US-6 (Notices CRUD):** As granted staff, I want to create, read, update, and delete 공지사항, so
  that I can manage announcements — and see who authored each one.
- **US-7 (위아원 QR issuance):** As granted staff, I want to issue a signed 위아원 QR for an item, so
  that members can scan it with the 위아원 app to reach the intended action.

---

## 3. Acceptance Criteria (Given / When / Then)

QA-testable. Every "access" check assumes a successful Zion 로그인 first.

### Zion 로그인 (US-1)
- **AC-1.1** Given an unauthenticated visitor, When they open the app, Then they see only the Zion
  로그인 screen (ZCS `login`) and cannot reach any feature route.
- **AC-1.2** Given a visitor clicks 로그인, When they complete Zion 계정 authorization, Then the app
  exchanges the code for a token, fetches `/me` (고유번호/이름/지파/교회/직책) plus authorities, and
  lands them in an authenticated session.
- **AC-1.3** Given the `/me` or authorities lookup fails, When the callback is processed, Then the
  app **fails closed** (treated as no access / error screen), never as super-admin and never as
  granted staff.
- **AC-1.4** Given a logged-in user, When their session is idle past the configured timeout, Then
  they are logged out and must sign in again (server-session canon from `zauth-integration`).

### Super-admin detection (US-2)
- **AC-2.1** Given a user whose Zion authorities contain the configured super-admin authority string
  (`ZADMIN-TEMPLATE-SUPER`, read from one env-overridable config constant), When they log in, Then they
  have full access: all feature screens **and** the 고유번호 접근 관리 page, without any local grant.
- **AC-2.2** Given a user **without** that authority string, When they log in, Then they are NOT
  super-admin even if their 고유번호 is in the local table (local grants never confer super-admin).
- **AC-2.3** Given the authorities lookup is empty or errors, When evaluated, Then the user is treated
  as **not** super-admin (fail-closed).
- **AC-2.4** Given the detection logic, When it decides super-admin, Then it matches **only** the
  authority string and **never** inspects duty/직책 — the duty→authority mapping (정보통신부장 /
  전산개발과장 / platform superadmin) is a ZAuth-console/registration concern, not app logic.

### Grant access by 고유번호 (US-3)
- **AC-3.1** Given a super-admin on the 고유번호 접근 관리 page, When they add a 고유번호 with a role,
  Then a grant record is created and that person gets the role's access on their next request.
- **AC-3.2** Given a non-super-admin **without** the access-management delegate capability, When they
  try to open 고유번호 접근 관리 (UI or API), Then they are denied (`noperm` / 403).
- **AC-3.3** Given a duplicate 고유번호 is added, When saved, Then the existing grant is updated (no
  duplicate rows); the action is idempotent.
- **AC-3.4** Given a grant is created or changed, When saved, Then an audit entry records who acted,
  the target 고유번호, the role, and the timestamp.
- **AC-3.5** Given the input 고유번호 does not match any real member, When saved, Then the grant may
  still be stored (grant-by-identifier is allowed ahead of first login), but the row is clearly shown
  as "미로그인/미확인" until that person logs in. (Template default; document the trade-off.)

### Revoke access (US-4)
- **AC-4.1** Given a super-admin/delegate removes a 고유번호, When confirmed, Then the grant is
  deleted and that user hits `noperm` on their next request to a gated screen.
- **AC-4.2** Given a super-admin tries to revoke their own super-admin authority, When attempted,
  Then it is not possible here — super-admin comes from Zion authorities, not the local table, so the
  page offers nothing to remove it (prevents lock-out by design).
- **AC-4.3** Given a revoke action, When confirmed, Then an audit entry is recorded (actor, target,
  timestamp).

### Access gating (US-5)
- **AC-5.1** Given a logged-in user who is neither super-admin nor in the local table, When they open
  any feature route, Then they see the ZCS `noperm` (권한 없음) state and no member or notice data is
  loaded or returned by the API.
- **AC-5.2** Given a user with a feature role but not the delegate capability, When they open the
  고유번호 접근 관리 route directly, Then they get `noperm` (gating is enforced server-side, not just
  by hiding the menu).
- **AC-5.3** Given any gated API endpoint, When called by an ungranted session (e.g. via direct
  request), Then it returns 403 with no data — UI hiding is never the only defense.

### Notices CRUD (US-6)
- **AC-6.1** Given granted staff, When they open 공지사항, Then they see the notice list in a ZCS
  table (`tbl`), each row showing title, author display name, and created date.
- **AC-6.2** Given granted staff, When they create a notice, Then it is saved with the author stored
  as the actor's 고유번호, and the list shows the author by **name (+ 고유번호 in full)** — never
  주민번호, never any masked national-ID field.
- **AC-6.3** Given granted staff, When they edit or delete a notice, Then the change persists and is
  reflected in the list. (Template default: any granted staff may edit any notice; per-author
  ownership is an explicit extension point, not in the template.)
- **AC-6.4** Given an ungranted user, When they call any notices endpoint, Then 403 and no data
  (re-states AC-5.3 for this resource).

### 위아원 QR issuance (US-7)
- **AC-7.1** Given granted staff on the QR feature, When they issue a QR for an item, Then the app
  produces a static HMAC-signed payload `{v, ...fields, sig}` where `sig = HMAC-SHA256(QR_SECRET, ...)`,
  base64url-encoded, embedded in a plain HTTPS scan URL, rendered as a scannable QR image.
- **AC-7.2** Given a member scans the QR with the 위아원 app, When the scan URL is opened, Then the
  intended action/landing is reached. (The template ships issuance + the documented consume rules;
  the consuming endpoint is a documented pattern, see `CLAUDE.md`.)
- **AC-7.3** Given a QR is issued, When the payload is signed, Then `QR_SECRET` is read from env (the
  template owns its own secret and does **not** call an external WAO signing service).
- **AC-7.4** Given the QR or its scan URL, When handled anywhere, Then the signed payload is
  **never written to logs**, is treated as **single-use / short-TTL** per the documented rules, and is
  **stripped from the URL** after consumption. (Verifiable: grep logs for payload → none.)

---

## 4. Member Data Usage Table

Minimal by design. The template reads member data only from Zion 로그인 `/me` + authorities. No member
data is collected by forms, and none is synced into a local directory by this template.

| Field | Source | Purpose | Stored locally? | Displayed to | Logged? | Notes |
|-------|--------|---------|-----------------|--------------|---------|-------|
| 고유번호 (newNo) | `/me` | Identify the user; key for local access grants; notice author key | Yes — in grant table + as `notice.author_no` | Self; super-admin/delegate (on access page); staff (as notice author) | Audit log only (grant/revoke actor & target) | **Public working key. Shown in full, labeled '고유번호'.** Not national-ID-grade. |
| 이름 (name) | `/me` | Human-readable display (top bar, notice author, access list rows) | No (fetched per session; may cache for display only) | Self; staff; super-admin/delegate | No | Plaintext directory tier. Display only. |
| 지파 (tribe) | `/me` | Optional display / tribe-color identity chip in the shell | No | Self (and staff if shown in a row) | No | Display only. Tribe color used for identity, never as accent/brand. |
| 교회 (church) | `/me` | Optional display of affiliation | No | Self | No | Display only. Not used for data scoping in the template (see §5). |
| 직책 (duty) | `/me` | Optional display of affiliation | No | Self | No | Display only. **Not** used to derive permissions in this template (override). |
| user-authorities | authorities API | Detect the single super-admin authority | No | Not displayed | No | Only the super-admin flag is read; the raw codes/values never reach the UI. |
| 주민번호 (idNumber) | — | **NOT USED** | No | **Never** | No | National-ID-grade. Never fetched for display, never decrypted, never shown anywhere. |

Privacy posture (for the spec-stage privacy review):
- **Minimization:** only 고유번호 is persisted (grant table + notice author); all other fields are
  display-only per session. No contact, address, DOB, gender, or 주민번호 is touched.
- **Retention:** grant rows persist until revoked; audit rows persist per retention policy; notice
  author key persists with the notice. No retention of name/tribe/church/duty beyond the live session.
- **Exposure:** 고유번호 shown in full (public working key) but only on authenticated, gated screens.
  주민번호 never appears.
- **Logging:** no member PII in application logs; QR payloads never logged (AC-7.4); audit log is the
  only place identifiers are written, scoped to access-control actions.
- **Open question for quality-guardian:** confirm whether 고유번호 in the audit log needs additional
  access restriction (audit-of-audit) for this template tier.

---

## 5. Local Permission Model (replaces standard §5 catalog + §6 RBAC matrix)

This template deliberately does **not** ship a permission catalog/guide page or an RBAC matrix. The
**only permission-related screen is 고유번호 접근 관리**. Rationale: the target users are non-developers
who need one obvious, hard-to-misuse access lever — a list of 고유번호 with a role — not a duty-driven
matrix they cannot reason about.

### How access is decided (evaluation order, fail-closed)
1. **Authenticated?** No → Zion 로그인 screen. (No anonymous access.)
2. **Super-admin?** Zion authorities contain the configured super-admin authority string
   (`ZADMIN-TEMPLATE-SUPER`, env-overridable) → full access (all features + 고유번호 접근 관리). This
   string is the only thing read from user-authorities; duties are never inspected.
3. **Local grant?** Logged-in 고유번호 exists in the grant table → access per the grant's role.
4. **Otherwise** → ZCS `noperm` (권한 없음). No data returned by any API.

### Recommended minimal role set (keep it small — justify)
To stay beginner-safe, the template ships exactly **one local role plus one capability flag**, on top
of the implicit super-admin. More roles can be added later by editing one enum; this is documented as
the extension point.

| Identity | Source | Can use feature screens (notices, QR) | Can open 고유번호 접근 관리 | Notes |
|----------|--------|----------------------------------------|----------------------------|-------|
| 총괄 관리자 (super-admin) | Zion authority `ZADMIN-TEMPLATE-SUPER` (env-overridable) | Yes (all) | Yes | Bootstrap + escape hatch; not in local table; cannot be revoked here. |
| 운영자 (staff) — local grant | Local 고유번호 grant | Yes | Only if delegate flag set | The single local role. |
| └ 운영자 + 접근 관리 위임 (delegate) | Local grant with `can_manage_access = true` | Yes | Yes | Lets the super-admin delegate grant management without making someone super-admin. |
| (ungranted, logged-in) | — | No | No | `noperm`. |

Justification for one role: the worked example needs exactly two capability tiers — "use the app" and
"manage who can use the app." A single role + a delegate flag expresses both without inventing a
matrix. Adding role-specific feature limits or org data-scope is a documented extension, not core.

### Data scope (intentionally flat)
The template applies **no org (HQ/지파/교회) data scoping**. All granted staff see all notices; QR
issuance is not org-filtered. This is a deliberate simplification for a beginner template. The
member-data table notes tribe/church/duty are **display-only, not scope inputs**. Org-scoped filtering
is called out as a future extension so a fork can add it deliberately rather than inherit hidden rules.

### Required-pages note (deviation, recorded)
The house standard mandates a "permission guide/catalog" page and an "additional-grantee management"
page. Per the SSOT override, the catalog/guide page is **intentionally omitted** (no catalog exists to
guide). The grantee-management need is met by the single **고유번호 접근 관리** page, which is therefore
**mandatory and always in the MVP**. This deviation is intentional and approved in the request.

---

## 6. Screens (what the template ships)

| Screen | ZCS building blocks | Who reaches it |
|--------|---------------------|----------------|
| Zion 로그인 | `login` | Everyone (unauth) |
| App shell (top bar + sidebar) | `topbar`, `sidebar`, tribe-color identity chip, `badge` | All authenticated |
| 권한 없음 (no access) | `noperm` | Logged-in, ungranted |
| 공지사항 목록/작성/수정 | `tbl`, `modal` or `drawer`, `emptystate` | Super-admin + staff |
| 위아원 QR 발급 | form + QR render, `modal` | Super-admin + staff |
| 고유번호 접근 관리 | `tbl`, `modal`, `masked` (for any non-고유번호 sensitive display, though none expected) | Super-admin + delegate |

---

## 7. Milestones

### MVP (the template itself — all of this ships)
1. **Zion 로그인** (OAuth2 code→token, `/me` + authorities, fail-closed) — prerequisite for all.
2. **Super-admin detection** from the single configured Zion authority.
3. **Local access model**: grant table keyed by 고유번호 + the four-step fail-closed evaluation +
   ZCS `noperm` gating (enforced server-side).
4. **고유번호 접근 관리 page** (add/remove/role + delegate flag + audit) — mandatory.
5. **공지사항 (notices) CRUD** — the worked example (ZCS table/modal + author by name/고유번호).
6. **위아원 QR issuance** — one HMAC-signed static QR + the consume rules documented in `CLAUDE.md`.
7. **ZCS vendored** into `frontend/zcs/` + `npm run sync:zcs`; Korean-only copy via a single ko key file.
8. **`CLAUDE.md`** — the central deliverable (onboarding, 총회 prerequisite, env/secrets, login flow,
   the local permission model, ZCS usage, 위아원 QR, privacy/security cautions, "copy notices to add a
   feature," run-locally).
9. **Local dev** via docker-compose (frontend/nginx + Go backend + postgres) + infra handoff doc.

### Out of scope (explicitly NOT in the template — documented as extension points)
- Permission catalog/guide page and full RBAC matrix (intentionally removed).
- Org (HQ/지파/교회) data scoping / row-level filtering.
- Per-author ownership rules on notices.
- Additional local roles beyond 운영자 + delegate flag.
- Multi-language UI beyond Korean (keys are structured so it can be added later).
- Member-data sync into a local directory; any member field beyond 고유번호 persistence.
- K8s / GitLab CI artifacts (infra handoff doc only).
- Any dependency on an external WAO signing service (template owns `QR_SECRET`).

---

## 8. Assumptions & Preconditions

### P-1 — 총회 (General Assembly / HQ 전산팀) registration is a MANUAL prerequisite (blocking)
Using Zion 로그인 + member data is **not self-service**. Before the app works, the operator must
manually contact the 총회 (HQ / 전산팀) to:
1. Register the app and obtain a **`client_id` (= REST API Key; there is NO `client_secret`)**.
2. Register the OAuth **callback/redirect URL**.
3. If any server-to-server call is needed, obtain **Admin-API approval + an Admin Key**.
4. Have the app-specific authorities — including the **super-admin authority `ZADMIN-TEMPLATE-SUPER`** —
   registered in the auth console and **mapped to the right people** (platform superadmin + each
   church's 정보통신부장 + 전산개발과장). The duty→authority mapping lives entirely in the console;
   the app never references those duties.

Until this is done the app behaves "as if unregistered." `CLAUDE.md` must explain this as the **very
first onboarding step**, kindly and concretely. (Treat as an environment/config precondition, not an
in-app feature.)

### Other assumptions
- **A-1:** The super-admin authority string is a single env-overridable config constant, defaulting to
  `ZADMIN-TEMPLATE-SUPER` (verbatim, hyphenated), so forks can rename it without touching logic.
- **A-2:** `QR_SECRET` is provisioned as an env secret by the operator; rotation is documented.
- **A-3:** At least one person is mapped to the super-admin authority in the auth console before first
  use, so the system can be bootstrapped (no super-admin → no one can seed grants).
- **A-4:** 고유번호 is treated as the public working key (shown in full); 주민번호 is never accessed.
- **A-5:** All user-facing Korean copy is humanized before delivery (no AI-flavored Korean), per house rule.

---

## 9. Open Questions (for the team)
- **Q1 (backend):** Authority string is fixed (`ZADMIN-TEMPLATE-SUPER`, env-overridable). Confirm the
  authorities API response shape and match semantics for the Go backend (mirror `zauth-integration`
  backend-go canon) — exact "contains string", case-sensitive comparison.
- **Q2 (quality-guardian/privacy):** Does the audit log of grant/revoke (containing 고유번호) need its
  own access restriction or retention limit at this template tier?
- **Q3 (frontend/UX):** For AC-3.5, confirm the UI treatment of a grant whose 고유번호 has not yet
  logged in ("미확인" badge vs. plain row) — affects the 고유번호 접근 관리 table design.
- **Q4 (backend):** 위아원 QR — does the template need to ship a working *consume* endpoint, or only
  issuance + documented consume rules? SSOT says "one issuance pattern" + docs; confirming scope so we
  don't over-build.
