# ZCS Admin Template — Design System & Screen Spec (v1.1)

> **CR-02 (shell / nav / session & audit), 2026-07-01.** Sidebar redesigned to a config-driven,
> collapsible **nested nav (≥3 levels), no underlines** (background + left accent rail). Topbar's
> always-on 고유번호 chip + logout button replaced by a **☰ hamburger → 내 정보 drawer**; **logout moved
> to the sidebar footer**. Added **세션 관리** and **활동 감사 로그** screens (보안·감사 group, super-admin
> only); the in-page grant-audit tab folded into 활동 감사 로그. **위아원 QR 발급 removed from the nav**
> (reference page only). All nested-nav / a11y CSS lives in the override layer
> `frontend/src/styles/zcs-a11y.css` — the vendored `frontend/zcs/` is never edited (see §7 backports).

> **Design baseline: ZCS (Zion Console System), NOT ZDS.**
> ZCS is a plain-CSS class system at `/Users/mins/Workspace/zcs/` (cobalt accent `#2f5bd0`,
> 13px body / 32px controls, table- & bar-first, 12-tribe palette for *identification only*).
> ZDS v2, the Tailwind preset, sage green, and the arch signature are **out of scope** for this template.
> Every screen below is expressed with **existing ZCS classes**. Anything ZCS lacks is collected in
> §7 *Proposed ZCS Backports* — we do not invent a parallel kit.
>
> ZCS is **vendored** into the template at `frontend/zcs/` and linked via `styles.css` (single entry,
> imports the Pretendard webfont + `zcs/zcs.css`). `npm run sync:zcs` refreshes the vendored copy from
> the source folder. React components are thin wrappers that render ZCS markup/classes — no second
> styling layer, no raw hex in app code.

---

## 1. Design Tokens

There is **no project token table and no Tailwind preset.** Tokens are ZCS CSS variables defined once in
`zcs/zcs.css :root` and consumed by class. App code references **semantic classes/variables only**
(`var(--accent)`, `.mono`, `.tnum`), never raw hex.

Authoritative values (from `zcs/zcs.css`, do not restate elsewhere):

| Group | Variables | Notes |
|---|---|---|
| Surface / ink | `--bg #eef0f3` `--surface #fff` `--surface-2 #f7f8fa` `--ink #161a20` `--ink-2 #59616e` `--ink-3 #8b93a0` `--line #e4e7ec` `--line-2 #d3d8df` | `--ink-3` is **low-contrast (~3:1 on white)** — hints/meta/placeholder only, never essential copy (see §5). |
| Accent (single, cobalt) | `--accent #2f5bd0` `--accent-hover #2750bd` `--accent-weak #eaf0fd` `--accent-ink #1d49ad` | The **only** emphasis color. Buttons, active nav/tab, selection, focus ring, links. |
| Status | `--ok #1c8a4e / --ok-bg` · `--warn #b06a00 / --warn-bg` · `--bad #c0392b / --bad-bg` · `--neu #5f6b7a / --neu-bg` | Always paired with text/icon, never color-alone. |
| System | `--radius 6px` · `--shadow` · `--shadow-overlay` · `--sans Pretendard` · `--mono` | `--mono` + `.tnum` for 고유번호 fixed-width tabular. |
| 12-tribe palette | per-tribe hex (inline on `.gem`/`.chip .dot`) | **Identification only.** Never accent/brand. This template uses it on exactly one element: the signed-in user's tribe gem in the shell. |

**Project additions to ZCS tokens: none.** The template needs no new color, type, or spacing token; the
console palette covers every screen. (If a fork later needs one, add it to `zcs/zcs.css :root` and
re-run `sync:zcs` — do not add a parallel token system in app code.)

**ZCS gaps this template hits** (filled in-project, proposed back upstream in §7): `:focus-visible`
rings for non-input controls, a `prefers-reduced-motion` guard, and a QR-issuance display block.

---

## 2. Component Specs (per state)

Each entry: **React component file (PascalCase) → ZCS markup it renders → props → states**. The React
component name **equals** the frontend file name (1:1). This list is the shared component contract with
frontend-builder.

### 2.1 `AppShell` → `.app` (grid `212px 1fr`)
Wraps `Sidebar` + a `<main class="main">` containing `Topbar` + `<div class="content">`.
- Props: `children`, `nav` (active key), `user`.
- States: static layout; collapses to single column under 980px (see §6).

### 2.2 `Sidebar` → `.sidebar` + `.brand` + `.nav` (recursive) + `.sidebar-foot`  *(redesigned — CR-02)*

Renders a **typed nav tree** recursively (config-driven, not JSX). A fork adds nested menus by editing
the config, never the component. Engine supports **3 levels** (group → group/item → item).

**Nav config (typed tree) — `src/config/nav.ts`**
```ts
type NavCtx = { isSuper: boolean; canManageAccess: boolean };
type NavNode =
  | { kind: 'item';  label: string; icon?: Icon; to: string; visible?: (c: NavCtx) => boolean }
  | { kind: 'group'; label: string; icon?: Icon; children: NavNode[]; visible?: (c: NavCtx) => boolean };
```
Seed (demonstrates depth; 3rd level supported even where seed is 2 deep):
```
공지사항                         item  → /notices
접근 관리                        group (visible: isSuper || canManageAccess)
  └ 고유번호 접근 관리            item  → /access
보안·감사                        group (visible: isSuper)        ← super-admin only
  ├ 활동 감사 로그                item  → /audit
  └ 세션 관리                     item  → /sessions
```
> 3rd-level proof: a group child may itself be a `group` (e.g. 보안·감사 → 감사 → {활동 로그, 접근 로그}).
> The renderer recurses on `children`; depth is unbounded by design, indentation is computed per level.

**No underlines.** The current bug is `<a>`/text-decoration underlines on nav rows. Override layer resets
`text-decoration:none` on every nav control. Affordance is **background + a left accent rail**, never an
underline.

**Per-depth appearance** (override classes in `src/styles/zcs-a11y.css`; see §7 B7):
- **Group header** `.nav-group-toggle` — looks like `.nav-item` (32px, 13px, `#aeb6c2`) + a trailing
  `.nav-chev` chevron that rotates 90° when open. It is a `<button aria-expanded>`. Hover =
  `rgba(255,255,255,.05)` (ZCS). It never gets the cobalt fill (groups aren't routes).
- **Active-trail** — when a descendant route is active, the ancestor group header brightens text to
  `#e8ebf0` and shows a faint **left rail** (`inset 2px 0 0 rgba(143,166,230,.5)`), so the open path is
  legible at a glance without competing with the active leaf.
- **Leaf item** `.nav-item` (reused from ZCS). Active leaf = `.nav-item.active` (cobalt fill, white text)
  **plus** a solid left rail (`inset 3px 0 0 #fff` over the fill for a crisp edge) and `aria-current="page"`.
- **Indentation per level** via `--nav-depth` (CSS var the renderer sets): L1 `padding-left:10px`
  (ZCS default), L2 `26px`, L3 `40px`. Nested levels (L2+) draw a 1px vertical guide
  (`border-left:1px solid rgba(255,255,255,.07)`) so depth reads structurally, not just by spacing.
- **Collapse animation** = height/opacity, guarded by `prefers-reduced-motion` (chevron snaps, no slide).

**Open-state memory** — open/closed per group persisted in `localStorage`; on load, the group
containing the active route auto-expands.

- Props: `tree` (NavNode[]), `ctx` (NavCtx), `activePath`, `user`.
- **Visibility = server truth.** `visible(ctx)` only hides menus; every route is gated server-side
  (AC-5.2). 보안·감사 hidden for non-super; 접근 관리 hidden unless super/delegate.
- a11y: group toggle = real `<button>`, **Enter/Space** toggles, `aria-expanded`; arrow-key roving
  optional; `aria-current="page"` on active leaf; focus-visible ring tuned for the dark panel (§5/§7).
- States: default / hover / group open·closed / active-trail / active leaf. No loading (static).

**`.sidebar-foot` → identity + 로그아웃 (CR-02 #4/#5).** Keeps the current user obvious *and* hosts logout:
- `.avatar` (initial) + `.who-name` (이름) + `.who-role` (plain-Korean role) + a **로그아웃** control
  (`LogoutButton`, full-width dark `.btn.ghost` idiom or trailing `.icon-btn` with `aria-label="로그아웃"`).
- 로그아웃 → `POST /api/auth/logout` → route to login. Optional lightweight confirm ("로그아웃할까요?")
  to avoid accidental clicks; toast "로그아웃되었습니다" then redirect.

### 2.3 `Topbar` → `.topbar`  *(redesigned — CR-02 #3)*
- `.crumb` (breadcrumb) + `.page-title`, `.topbar-spacer`, right cluster.
- **Right cluster (new):** the user's **이름** (kept visible so the current user is always obvious) + a
  **hamburger** `HamburgerButton` (`.icon-btn`, `aria-label="내 정보"`, `aria-expanded`, `aria-haspopup`).
  The old always-on 고유번호 chip and the old logout button are **removed** — full identity now lives in
  the 내 정보 drawer (also a small privacy win: 고유번호 is no longer painted on every screen).
- Clicking the hamburger opens **`MyInfoDrawer`** (§2.3a).
- Props: `title`, `crumb`, `user`, `onOpenMyInfo`.
- States: default / hamburger hover·focus·expanded.

### 2.3a `MyInfoDrawer` → `.drawer-overlay` + `.drawer`  *(new — CR-02 #3)*
Right-side ZCS drawer opened from the topbar hamburger. Read-only "내 정보".
- `.drawer-head` → `.dt` "내 정보" + `.dx` close.
- `.drawer-body` → two `.dl` blocks:
  - **신원**: 이름 · **고유번호** (full, `.mono`, labeled "고유번호") · 지파 (`.gem.s` + name) · 교회 · 직책 ·
    역할 (plain Korean: **슈퍼어드민** / **운영자 · 접근 관리** / **운영자**). All display-only from session;
    no raw codes/ids, never 주민번호, never "ZAuth".
  - **현재 세션**: 로그인 시각 · 마지막 활동 · **자동 로그아웃까지 남은 시간** (live countdown, `.tnum`,
    e.g. "12분 30초 남음"); under ~2분 the row switches to `.alert.warning` "곧 자동 로그아웃됩니다".
- No logout here (logout is the sidebar footer). 
- Props: `open`, `user`, `session`, `onClose`.
- States: default / countdown-warning / closing. Esc + backdrop close; return focus to the hamburger.

### 2.4 `LoginScreen` → `.login` (two-column split)
- Left `.login-brand` (dark `#10141b`): `.lb-top` signature (한·영) + `.lb-foot` (부서/시스템/도메인).
- Right `.login-main` → `.login-card`: `.brand-mark`, `<h1>`, `.sub`, `.login-start` containing
  **`ZionLoginButton`**, `.login-foot` help line.
- Props: `onLogin`, `status` (`idle | redirecting | error`).
- States: **default** (button) / **loading** = `.oauth-redirect` interstitial (`.oauth-hop` + `.oauth-bar`)
  while bouncing to Zion / **error** = `.alert.danger` above the button. No empty/no-perm (pre-auth).

### 2.5 `ZionLoginButton` → `.btn-zion`
- Single credential entry point. Renders `.scj-mark` + label **"Zion 계정으로 로그인"**.
- **No password / sign-up / reset / social UI** — authentication is entirely the Zion platform's job.
- States: default / hover (`.btn-zion:hover`) / active (`:active`) / disabled (during redirect).

### 2.6 `Button` → `.btn` (`.primary` / `.sm` / `.ghost` / `.danger`) ; `IconButton` → `.icon-btn`
- Props: `variant`, `size`, `leadingIcon`, `loading`, `disabled`, `onClick`.
- States: default / hover / **focus → see §7 backport (focus-visible)** / disabled (`opacity` + `cursor`
  via wrapper) / **loading** = leading `.spinner.s` + disabled. Height 32 (sm 28).

### 2.7 `Field` + inputs → `.field` + `.input` / `.textarea` / `.select`
- `Field` wraps `label` (+ `.req` for required), control, `.hint`, `.err-msg`.
- Components: `TextField` (`.input`), `TextArea` (`.textarea` + optional `.char-count`),
  `Select` (`.select`), `InputWrap` (`.input-wrap` lead/trail icon).
- States: default / focus (`border-color:--accent` + 3px `--accent-weak` ring) / **error**
  (`.field.error` → red border + `.err-msg` with icon) / disabled (`.input:disabled`, grey).
- i18n: labels wrap; min control width set per screen, never fixed by px text length.

### 2.8 `DataTable` → `table.tbl` (in `.panel` / card, `.tbl-wrap` for overflow)
- `thead th` sticky; `.sortable` headers carry `.arr`; `.num` right-aligns numerics.
- Cells: `.cell-name` (이름 + optional `.en`), `.mono` for 고유번호, `.badge` for status, `.chip` for tribe.
- Props: `columns[]`, `rows[]`, `sort`, `onSort`, `onRowClick?`, `loading`, `empty`.
- States: **default** / **loading** = `.loadbox` (`.spinner.m` + "불러오는 중…") replacing tbody /
  **empty** = `EmptyState` in place of the table / **error** = `.alert.danger` above table + retry /
  **no-permission** = `NoPermission` replaces the whole panel.
- a11y: clickable rows must be keyboard-reachable — see §7 (row affordance) and §5.

### 2.9 `FilterBar` → `.filterbar`
- `.filter-search` (search input, focus-within ring) + optional `.select` filters + `.filter-meta`
  (result count, right-aligned).
- Props: `query`, `onQuery`, `filters?`, `meta` (e.g. "총 <b>12</b>건").
- States: default / focus-within / empty-result handled by the table's empty state.

### 2.10 `Pager` → `.pager`
- `.info` (range, `.tnum`) + `.pages` (`.pg`, `.pg.active`, `.pg:disabled` for ‹ ›).
- Props: `page`, `pageSize`, `total`, `onPage`. States: default / disabled ends / single page (hide pages).

### 2.11 `Modal` → `.overlay` + `.modal` (`.danger` variant)
- `.modal-head` (`.modal-icon` + `.mt` title + `.msub` + `.mx` close) / `.modal-body` (form or text) /
  `.modal-foot` (`.btn.ghost` cancel + primary/`.danger` confirm).
- Props: `open`, `title`, `danger`, `onClose`, `onConfirm`, `confirmLabel`, `loading`.
- States: default / **danger** (red icon + danger confirm) / **loading** (confirm shows `.spinner.s`,
  controls disabled) / error (inline `.alert.danger` in body).
- a11y: `role="dialog" aria-modal="true"`, Esc + backdrop close, focus trap (frontend), restore focus.

### 2.12 `Drawer` → `.drawer-overlay` + `.drawer`
- Right-side panel for record detail/side form. `.drawer-head` (`.dt`/`.dsub` + `.dx`) / `.drawer-body`
  (`.dl` etc.) / `.drawer-foot` (full-width `.btn`s). Used for notice detail (alternative to Modal).

### 2.13 `Badge` → `.badge` (`.success`/`.warning`/`.danger`/`.neutral`/`.brand`, `.plain` = no dot)
- Always carries a text label; the leading dot is decorative (color-blind safe). Used for grant
  status, "이름 미확인", delegate flag.

### 2.14 `Chip` → `.chip` ; `Gem` → `.gem` (`.s`/`.m`/`.l`)
- `Gem` is the **only** tribe-colored element (inline tribe hex). Used for the signed-in user's tribe
  in the shell and, optionally, a notice author's tribe.

### 2.15 `MaskedValue` → `.masked` (+ `.mreveal`)
- Available but **largely unused** in this template: 고유번호 is shown in full (`.mono`, not masked),
  and idNumber/주민번호 is **never displayed**. Kept in the kit so a fork that adds a sensitive field
  (e.g. 연락처) has the correct masked-by-default + reveal-on-permission pattern ready.
- Mask format if ever used: e.g. `010-****-5678`; reveal button needs a Korean `aria-label` (§5).

### 2.16 `EmptyState` → `.emptystate`
- `.es-ic` + `.es-t` (title) + `.es-d` (what it means + what to do) + `.es-act` (single recovery button).

### 2.17 `NoPermission` → `.noperm`
- `.np-ic` (shield) + `.np-t` + `.np-d` (plain-language explanation + how to request access).
- **Do NOT render `.np-code`** — it shows a developer permission string and violates the no-dev-terminology
  rule. Omit it entirely (or repurpose for a plain-language hint — see screen copy in §3.5).

### 2.18 `PageTitle` → `.pagetitle`
- `.pt-crumb` + `.pt-title` (+ optional count `.badge.brand.plain`) + `.pt-sub` + `.pt-act` (primary action).

### 2.19 `DefinitionList` → `.dl`
- Key/value rows for notice detail (작성자, 작성일, 본문). `.k.last`/`.v.last` drop the last border.

### 2.20 `Toast` → `.toast-stack` + `.toast` (`.success`/`.error`/`.warning`/`.info`)
- Bottom-right, auto-dismiss. Used for "저장했습니다", "권한을 부여했습니다", "권한을 회수했습니다", errors.

### 2.21 `Spinner` → `.spinner` (`.s`/`.m`/`.l`) ; `LoadBox` → `.loadbox`
- In-place loading. `LoadBox` for full-panel/table loading.

### 2.22 `Alert` → `.alert` (`.info`/`.success`/`.warning`/`.danger`)
- Inline banner. Used for the QR caution and login error.

### 2.23 `QrIssuePanel` → `.panel` + QR display + `.alert.warning`  *(uses §7 backport `qr-issue`)*
- `.panel-head` ("위아원 QR 발급") + `.panel-body` containing: target field(s) (`Field`/`Select`),
  a **`.btn.primary` "QR 코드 만들기"**, the generated QR image in a `.qr-frame`-style card
  (reuse the login frame's visual: white card, radius, shadow), a **download / copy-link** `.btn`,
  and a **`.alert.warning` caution block** (copy in §3.6).
- States: **idle** (no QR yet, empty hint) / **loading** (`.spinner.m` in the frame) / **issued**
  (QR shown + caution) / **error** (`.alert.danger` + retry) / **no-permission** (`NoPermission`).

---

## 3. Screen Wireframes (per state)

ASCII layouts. Korean = literal UI copy (humanized, no dev terminology). 고유번호 shown in full.

### 3.1 Zion 로그인 — `LoginScreen`

**Default**
```
┌───────────────────────────────┬───────────────────────────────┐
│  [dark brand panel #10141b]   │            (light)            │
│  ◇ 신천지예수교 증거장막성전   │      ◇                        │
│    SHINCHEONJI CHURCH OF JESUS │      행정시스템 로그인        │
│                               │      Zion 계정으로 로그인합니다.│
│                               │                               │
│   {부서명}                    │   ┌─────────────────────────┐ │
│   신천지 행정시스템 · {도메인} │   │ ◇  Zion 계정으로 로그인  │ │  ← .btn-zion
│                               │   └─────────────────────────┘ │
│                               │   계정 문의는 본부 시스템      │
│                               │   관리팀으로 연락해 주세요.    │  ← .login-foot
└───────────────────────────────┴───────────────────────────────┘
```
**Loading (redirecting)** → `.oauth-redirect`: hop animation + "Zion 계정으로 이동하고 있습니다…" + `.oauth-bar`.
**Error** → `.alert.danger` above the button: "로그인을 마치지 못했습니다. 잠시 후 다시 시도해 주세요."
**Empty / No-permission** → N/A (pre-authentication; no data, no gate yet).

> Single login button only. No password, sign-up, reset, or social login. Never the word "ZAuth".

### 3.2 App shell — `AppShell` (`Sidebar` + `Topbar`)

```
┌──────────────┬──────────────────────────────────────────────────────┐
│ ◇ 행정시스템 │  홈 › 공지사항                       김도현   [☰ 내 정보] │ ← Topbar: name + hamburger
│  ADMIN       ├──────────────────────────────────────────────────────┤
│              │                                                        │
│ 메뉴         │   (page content)                                       │
│ ● 공지사항   │                                                        │  ← active leaf (cobalt + rail)
│ ▾ 접근 관리   │                                                        │  ← group, open (chevron ▾)
│   │ ▸고유번호 │                                                        │  ← L2 leaf, guide line
│   │  접근관리 │                                                        │
│ ▾ 보안·감사   │                                                        │  ← group (super-admin only)
│   │ ▸활동     │                                                        │
│   │  감사로그 │                                                        │
│   │ ▸세션관리 │                                                        │
│ ────────────│                                                        │
│ (KD) 김도현  │                                                        │  ← .sidebar-foot
│  슈퍼어드민   │                                       [ 로그아웃 ]      │  ← logout (bottom-left)
└──────────────┴──────────────────────────────────────────────────────┘
```
- **No underlines anywhere in the nav.** Hover = subtle bg; active leaf = cobalt fill + left rail +
  `aria-current="page"`; open group = ▾ chevron + active-trail highlight on the path; L2+ rows indented
  with a 1px guide line. Keyboard: Enter/Space toggles a group, focus-visible ring tuned for dark.
- **Topbar right** = 이름 (current user always visible) + ☰ hamburger → `MyInfoDrawer` (full 고유번호,
  지파/교회/직책, 역할, session info). No always-on 고유번호 chip, no topbar logout button.
- **Logout** lives in the sidebar footer (bottom-left), beside the identity block.
- `.who-role` text per role: **슈퍼어드민** / **운영자 · 접근 관리** / **운영자**.
- Menu visibility: 공지사항 for all granted; 접근 관리 for super/delegate; 보안·감사 (활동 감사 로그 +
  세션 관리) **super-admin only**. **위아원 QR 발급 is no longer in the nav** (CR-02 #2).

### 3.3 공지사항 목록 — `NoticesPage`

**Default**
```
PageTitle:  공지사항                         [+ 새 공지 작성]   ← .pt-act, granted only
FilterBar:  [🔍 제목 검색            ]                     총 12건  ← .filter-meta
┌──────────────────────────────────────────────────────────────┐
│ 제목                         │ 작성자      │ 작성일           │ ← table.tbl thead
├──────────────────────────────────────────────────────────────┤
│ 6월 정기 모임 안내            │ 김도현      │ 2026-06-28       │
│ 시스템 점검 공지             │ 이서연      │ 2026-06-21       │
└──────────────────────────────────────────────────────────────┘
Pager:  1–12 / 12        ‹ 1 ›
```
- **작성자 cell = 이름 only (privacy mandate P-3).** The notices list/detail API returns the author's
  **name snapshot** captured at post time — **not** 고유번호. Author 고유번호 is persisted but never
  broadcast to all staff. Full 고유번호 appears **only** on the 고유번호 접근 관리 page (§3.7), which is
  super-admin/delegate-gated. Never 주민번호, never a masked national-ID field.
- Row click → notice detail (`Drawer` or `NoticeDetail` page via `.dl`).

**Loading** → table body replaced by `.loadbox` ("불러오는 중…").
**Empty** → `EmptyState`: 제목 "등록된 공지사항이 없습니다", 설명 "첫 공지사항을 작성해 보세요.",
  action `+ 새 공지 작성` (granted only; ungranted never reach this screen).
**Error** → `.alert.danger` above table: "목록을 불러오지 못했습니다." + `다시 시도` button.
**No-permission** → `NoPermission` (see 3.5) — but ungranted users never see the menu and the API returns 403.

### 3.4 공지사항 작성/수정 — `NoticeFormModal` (Modal) — and 상세 `NoticeDetail` (`.dl`)

**작성/수정 (Modal, default)**
```
┌──────────────── 새 공지 작성 ─────────────── ✕ ┐
│  제목 *   [______________________________]      │  ← Field + .input
│  내용 *   [                              ]      │  ← TextArea (.textarea)
│           [                              ]   142/2000  ← .char-count
├─────────────────────────────────────────────────┤
│                         [ 취소 ]  [ 저장 ]        │  ← .btn.ghost / .btn.primary
└─────────────────────────────────────────────────┘
```
- States: default / **error** (empty 제목 → `.field.error` + `.err-msg` "제목을 입력해 주세요.") /
  **loading** (저장 → `.spinner.s` in primary, controls disabled) → on success Toast "저장했습니다".
- 삭제: separate **danger Modal** "공지사항을 삭제할까요? 되돌릴 수 없습니다." → `.btn.danger` 삭제.

**상세 `NoticeDetail` (`.dl`)**
```
제목 (PageTitle or modal head)
작성자   김도현                ← name snapshot only (P-3); no 고유번호 here
작성일   2026-06-28 14:20
내용     (본문 …)
```

### 3.5 권한 없음 — `NoPermission`

**Default (logged-in but ungranted)**
```
                 🛡
        접근 권한이 없습니다
   이 시스템을 사용할 수 있는 권한이 아직 없습니다.
   사용이 필요하시면 시스템 관리자에게 권한을
   요청해 주세요.
```
- `.np-ic` shield + `.np-t` "접근 권한이 없습니다" + `.np-d` plain-language guidance.
- **No `.np-code`** (no permission code shown). Optional plain hint inside `.np-d`:
  "로그인한 계정: 김도현 (고유번호 00341130-00036) — 이 고유번호로 권한을 요청하시면 됩니다."
  (helps the admin grant the right person; uses 고유번호 only, never 주민번호).
- This is the terminal state for the whole shell when a logged-in user is neither super-admin nor granted.

### 3.6 위아원 QR 발급 — `QrIssuePanel`  *(reference page only — removed from nav, CR-02 #2)*

> The QR issuance page and its backend endpoint stay in the repo as a worked reference example, but it
> is **no longer linked from the shell nav**. Reachable only by direct route (kept for forks to study);
> if a fork drops the route entirely, the build must still pass. Spec below retained for that reference.

**Issued (default after generate)**
```
PageTitle:  위아원 QR 발급
┌─ 위아원 QR 발급 ───────────────────────────────────────────┐
│  대상 [ 선택 ▼ ]            [ QR 코드 만들기 ]               │
│                                                            │
│        ┌──────────────┐                                    │
│        │  ███ ▄▄ █ ███ │   [ 이미지 저장 ]  [ 링크 복사 ]    │
│        │  █ ▄ ◇ ▄ █ ▀ │                                    │
│        │  ███ ▀▀ █ ███ │                                    │
│        └──────────────┘                                    │
│  ⚠ 이 QR에는 서명된 보안 코드가 들어 있습니다.              │ ← .alert.warning
│     • 화면 캡처·메신저 공유 시 외부로 유출될 수 있습니다.   │
│     • 일정 시간이 지나면 만료되며, 한 번만 사용됩니다.       │
│     • 코드 값은 절대 따로 기록·저장하지 마세요.             │
└────────────────────────────────────────────────────────────┘
```
- QR rendered in a white framed card (reuse `.qr-frame` look). Caution = `.alert.warning`.
- States: **idle** (no QR, `.emptystate`-style hint "대상을 선택하고 QR 코드를 만들어 주세요.") /
  **loading** (`.spinner.m` in frame) / **issued** (above) / **error** (`.alert.danger` + 다시 시도) /
  **no-permission** (`NoPermission`).
- Copy never exposes the signed payload; the payload is never logged, single-use, short-TTL,
  stripped from the URL after consumption (documented in CLAUDE.md per AC-7.4).

### 3.7 고유번호 접근 관리 — `AccessManagementPage` (the ONLY permission screen)

> Deviation, recorded: this template **omits** the house "permission guide/catalog" page (there is no
> catalog to guide). The grantee-management need is met entirely by this one page. It is **mandatory**
> and always in the MVP. See §4-1.

**Default (super-admin / delegate)**
```
PageTitle:  고유번호 접근 관리          [+ 고유번호 추가]
설명:  고유번호를 추가하면 그 사람이 Zion 계정으로 로그인했을 때 시스템을 사용할 수 있습니다.

FilterBar:  [🔍 고유번호·이름 검색        ]                    총 8명
┌────────────────────────────────────────────────────────────────────┐
│ 고유번호           │ 이름        │ 역할             │ 등록일     │      │
├────────────────────────────────────────────────────────────────────┤
│ 00341130-00036    │ 김도현      │ 운영자 · 접근관리 │ 2026-06-01 │ [회수]│
│ 00882041-00112    │ 이서연      │ 운영자           │ 2026-06-10 │ [회수]│
│ 00609233-00318    │ (이름 미확인)│ 운영자           │ 2026-06-25 │ [회수]│ ← badge
└────────────────────────────────────────────────────────────────────┘
Pager:  1–8 / 8
```
- This page (and its API) is the **only surface that returns other people's 고유번호 in full** — and
  only to super-admin/delegate (privacy mandate P-3/P-6). Rows are addressed by an **opaque internal id**
  in the URL/API, never by 고유번호 (P-6); 고유번호 travels in the request body only.
- 고유번호 column: `.mono`, fixed-width tabular, **shown in full**.
- Role column: `.badge.brand` "운영자", plus `.badge.neutral.plain` "접근 관리" when delegate flag set.
- A grant whose 고유번호 has **never logged in** → 이름 cell shows `.badge.warning` **"이름 미확인"**
  (AC-3.5 / Q3 answer): we display the badge inline in place of a name, plain text, not a code.
- Super-admin's own access is **not** in this table and has **no 회수 button** (AC-4.2 — comes from
  Zion authorities; can't be revoked here → no lock-out).

**고유번호 추가 (Modal)**
```
┌──────────── 고유번호 추가 ──────────── ✕ ┐
│  고유번호 *  [ 00000000-00000        ]    │  ← TextField, .mono input, 13-digit format
│              형식: 00000000-00000         │  ← .hint
│  역할        ( • ) 운영자                  │  ← radio (.check.radio)
│              ( ) 운영자 · 접근 관리 위임   │
├────────────────────────────────────────────┤
│                      [ 취소 ]  [ 추가 ]      │
└────────────────────────────────────────────┘
```
- Validation: format error → `.field.error` "고유번호 형식을 확인해 주세요 (예: 00000000-00036)".
- Duplicate 고유번호 → idempotent update; Toast "이미 등록된 고유번호의 권한을 변경했습니다." (AC-3.3).
- On success → Toast "권한을 부여했습니다." + audit entry written (AC-3.4).

**회수 (danger Modal)**
```
권한을 회수할까요?
00882041-00112 이서연 님은 다음 로그인부터 시스템을 사용할 수 없습니다.
                              [ 취소 ]  [ 회수 ]   ← .btn.danger
```
- On confirm → grant deleted, Toast "권한을 회수했습니다.", audit entry (AC-4.3).

> **Audit moved (CR-02).** The grant/revoke audit history is **no longer an in-page tab here.** It is now
> part of the broader **활동 감사 로그** screen (§3.9) under the **보안·감사** nav group, **super-admin
> only**. This page (접근 관리) shows only the live grant list + add/revoke; delegates use it but see no
> audit. Removing the duplicate tab keeps one source of truth for history.

**States for this screen**
- **Loading** → `.loadbox` in the grant table.
- **Empty** → `EmptyState`: "등록된 운영자가 없습니다 / 고유번호를 추가해 첫 운영자를 등록하세요." + `+ 고유번호 추가`.
- **Error** → `.alert.danger` + 다시 시도.
- **No-permission** → `NoPermission` (a 운영자 *without* delegate who hits this route directly:
  AC-5.2; the menu is hidden and the API returns 403).

### 3.8 세션 관리 — `SessionsPage`  (보안·감사 group · **super-admin only**, CR-02 #5)

Active-session list with forced logout. Server-gated, fail-closed; delegates and 운영자 → `NoPermission`.

**Default**
```
PageTitle:  세션 관리
설명:  지금 로그인되어 있는 사용자 목록입니다. 필요하면 특정 세션을 강제로 종료할 수 있습니다.
FilterBar:  [🔍 이름·고유번호 검색       ]                         접속 중 7명
┌──────────────────────────────────────────────────────────────────────────────┐
│ 사용자                 │ 로그인 시각        │ 마지막 활동   │ 유휴 만료  │        │
├──────────────────────────────────────────────────────────────────────────────┤
│ 김도현 00341130-00036  │ 07-01 09:02       │ 방금 전       │ 29분 후    │ 현재세션│ ← badge.brand
│ 이서연 00882041-00112  │ 07-01 08:40       │ 12분 전       │ 17분 후    │ [강제 종료]│
│ 강하늘 00609233-00318  │ 06-30 22:11       │ 3시간 전      │ 만료 임박  │ [강제 종료]│ ← badge.warning
└──────────────────────────────────────────────────────────────────────────────┘
Pager:  1–7 / 7
```
- 사용자 = 이름 + 고유번호 in full (`.mono`). 시각/경과 = `.tnum`. "유휴 만료" countdown; 임박 시 `.badge.warning`.
- **현재 세션** row → `.badge.brand` "현재 세션"; its 강제 종료 button is guarded (extra confirm — self-revoke
  logs *you* out). Other rows → `.btn.sm.danger` "강제 종료".
- **강제 종료 (danger Modal):** "이 세션을 강제로 종료할까요? 해당 사용자는 즉시 로그아웃됩니다." → `.btn.danger`.
  Self-row variant: "현재 세션을 종료하면 회원님도 바로 로그아웃됩니다. 계속할까요?".
- On confirm → `DELETE /api/sessions/{opaqueId}` (super-admin only; opaque session id, never 고유번호 in URL),
  Toast "세션을 종료했습니다.", row removed; an audit entry (동작: 세션 강제 종료) is written → shows in §3.9.
- States: loading (`.loadbox`) / empty (`EmptyState` "접속 중인 세션이 없습니다") / error (`.alert.danger`) /
  no-permission (`NoPermission`). Tokens are never displayed.

### 3.9 활동 감사 로그 — `ActivityLogPage`  (보안·감사 group · **super-admin only**, read-only, CR-02 #6)

Unified, read-only history (replaces the old in-page grant audit tab). Covers 로그인/로그아웃, 공지 작성·
수정·삭제, 접근 권한 부여·회수, 세션 강제 종료. Server-gated, fail-closed.

**Default**
```
PageTitle:  활동 감사 로그
FilterBar:  [ 동작: 전체 ▼ ] [ 기간: 2026-06-01 ~ 07-01 ] [🔍 처리자 검색 ]        총 1,240건
┌──────────────────────────────────────────────────────────────────────────────┐
│ 시각              │ 처리자                │ 동작            │ 대상                  │
├──────────────────────────────────────────────────────────────────────────────┤
│ 07-01 09:14:02   │ 김도현 00341130-00036 │ 권한 부여        │ 고유번호 00609233-00318│
│ 07-01 09:02:11   │ 이서연 00882041-00112 │ 로그인           │ —                     │
│ 06-30 18:30:45   │ 김도현 00341130-00036 │ 공지 삭제        │ "시스템 점검 공지"      │
│ 06-30 16:02:09   │ 김도현 00341130-00036 │ 세션 강제 종료    │ 세션 (강하늘)          │
└──────────────────────────────────────────────────────────────────────────────┘
Pager:  1–50 / 1,240
```
- 처리자 = 이름 + 고유번호 (`.mono`). **동작 = plain-Korean label `.badge`, never a raw code/enum**:
  `로그인`·`로그아웃` (`.neutral`), `공지 작성`·`공지 수정` (`.brand`), `공지 삭제`·`권한 회수`·`세션 강제 종료`
  (`.warning`/`.danger`), `권한 부여` (`.brand`).
- 대상 = context-appropriate, minimal: a grant target's 고유번호, a notice title snapshot, or
  "세션 (이름)" — opaque/where relevant (P-6); never 주민번호, never raw ids in copy.
- **FilterBar:** 동작 `.select` + 기간 `DateInput` range + 처리자 search (cheap; optional if backend defers).
- Read-only: no row actions. States: loading / empty (`EmptyState` "기록이 없습니다") / error / no-permission.
- Retention: rows purged per `AUDIT_RETENTION_DAYS` (P-1; backend `server purge` extended to this table).

---

## 4. Per-Role Screen States

Three identities (PM spec §5): **super-admin** (Zion authority `ZADMIN-TEMPLATE-SUPER`),
**운영자** (local grant), **운영자+위임** (delegate flag), and **ungranted** (logged-in, no access).

| Screen | 총괄 관리자 (super-admin) | 운영자 (staff) | 운영자 · 접근 관리 (delegate) | Ungranted (logged-in) |
|---|---|---|---|---|
| Zion 로그인 | shown (pre-auth) | shown | shown | shown |
| App shell | full nav (공지사항 + 접근 관리 + 보안·감사); role "슈퍼어드민"; ☰ 내 정보; 로그아웃 footer | 공지사항 only; role "운영자" | 공지사항 + 접근 관리; role "운영자 · 접근 관리" | shell renders, but every route → `NoPermission` |
| 내 정보 (drawer) | yes (own data + session) | yes | yes | yes (own data only) |
| 공지사항 목록 | view + 작성/수정/삭제 | view + 작성/수정/삭제 | view + 작성/수정/삭제 | `NoPermission` (API 403) |
| 공지 작성/수정/삭제 | yes | yes | yes | n/a |
| 고유번호 접근 관리 | full (add/revoke/role + delegate flag); **own row absent, no self-revoke** | route hidden; direct access → `NoPermission` (403) | add/revoke/role/list (no audit here) | `NoPermission` (403) |
| 세션 관리 (보안·감사) | full (list + 강제 종료, self-revoke guarded) | menu hidden; direct → `NoPermission` (403) | menu hidden; direct → `NoPermission` (403) | `NoPermission` (403) |
| 활동 감사 로그 (보안·감사) | view (read-only, filter) | menu hidden; direct → `NoPermission` (403) | menu hidden; direct → `NoPermission` (403) | `NoPermission` (403) |
| 위아원 QR 발급 | **not in nav**; reachable by direct route only (reference) | not in nav | not in nav | `NoPermission` |

Notes:
- **No org (지파/교회) data scope** in this template (PM §5) — all granted roles see the same data.
  tribe/church/duty are display-only, never scope inputs. (Org scoping is a documented future extension.)
- "Scope reduction" rows that a normal RBAC template would carry (e.g. tribe-admin sees only own tribe)
  are intentionally **absent** here and called out as the extension point, so the frontend does not
  guess hidden filtering rules.
- Server-side gating is the source of truth for every cell above; menu hiding is cosmetic (AC-5.2/5.3).

## 4-1. Required Permission Pages — deviation recorded

The house standard mandates two pages: a **permission guide/catalog** and an **additional-grantee
management** page.

- **Permission guide / catalog — intentionally OMITTED.** Per the SSOT request and PM spec §5, this
  template ships **no permission catalog and no RBAC matrix**, so there is nothing to "guide." Adding a
  catalog page would invent UI for a model that does not exist here. This omission is **explicitly
  approved** in the request and must not be "corrected" back to the standard.
- **Additional-grantee management — PRESENT and MANDATORY.** Fully specified as **고유번호 접근 관리**
  (§3.7): 고유번호 search → member confirmation (name resolved on first login; "이름 미확인" badge until
  then) → role selection (운영자 + delegate flag) → grant; active-grant list with revoke. The audit/history
  view now lives in the dedicated **활동 감사 로그** screen (§3.9, super-admin only) — not as an in-page tab.
  Per-role states are in §4 (super-admin/delegate full; 운영자/ungranted → `NoPermission` + 403).

---

## 4-2. Privacy Constraints Baked Into the Design (spec-stage mandates)

These shape what each screen may render. Design-owned items (P-3, P-2, P-6 display side) are reflected
above; the rest are flagged here for the owning files so the contract stays consistent.

| ID | Mandate | Design reflection |
|---|---|---|
| **P-3** | Author 고유번호 not broadcast to staff | 공지사항 목록/상세 show **author name only** (name snapshot at post time). Full 고유번호 returned **only** by the 고유번호 접근 관리 API. (§3.3/§3.4) |
| **P-2** | Grant/revoke + activity audit is super-admin-only, write-only | Dedicated **활동 감사 로그** screen under 보안·감사, **super-admin only**, hidden for delegates; never on a feature API. (§3.9, §4) |
| **P-6** | No 고유번호 in URLs | Grant rows and notices addressed by an **opaque internal id** in routes; 고유번호 is body-only. UI never builds a link/route containing 고유번호. (§3.7) |
| **P-4** | `/me` whitelist `{newNo,name,tribe,church,duty}` | UI only ever binds these five fields; no screen assumes any other member field exists. → backend (`api_contracts.md`). |
| **P-5** | Safe logging (no 고유번호/QR/PII/bodies) | QR caution copy already says "코드 값을 기록·저장하지 마세요"; topbar/notice screens carry no client-side logging of identifiers. → backend logger + `api_contracts.md`. |
| **P-1** | Audit retention configurable, documented purge | Audit tab notes retention is bounded (`AUDIT_RETENTION_DAYS`). → `03_infra_env.md`. |

> Files I do not own (`api_contracts.md`, `03_infra_env.md`) carry the authoritative P-1/P-2/P-4/P-5/P-6
> wording; this table records only the UI-visible consequences so the design and the API contract agree.

## 5. Accessibility Checklist (WCAG 2.1 AA) + ZCS conformance

Self-reviewed against the Web Interface Guidelines knowledge base (focus visibility, target size, form
behavior, motion). Findings folded in below; items needing a CSS change are listed as backports in §7.

**Contrast (AA, 4.5:1 text / 3:1 UI)**
- ✅ `--ink #161a20` (~16:1), `--ink-2 #59616e` (~6:1) on white — pass for body/labels.
- ✅ white on `--accent #2f5bd0` (~5.3:1) — pass for primary buttons / active nav / pager active.
- ✅ `--accent #2f5bd0` on white (~5.3:1) — pass for links/`accent-ink` text.
- ⚠️ **`--ink-3 #8b93a0` on white ≈ 3:1 — FAILS AA for normal text.** Rule: use `--ink-3` only for
  decorative/secondary meta and placeholders; **never** for essential copy. Audit every screen: hints,
  `.filter-meta`, `.crumb`, `.pt-sub`, empty/noperm descriptions — anything load-bearing must be `--ink-2`.
  (`.np-d`, `.es-d` already use ink-2/ink — keep it that way; do not downgrade to ink-3.)
- ✅ Status badges pair text + colored background tokens; verify `--warn #b06a00` on `--warn-bg` and
  `--bad`/`--ok` on their bg meet 4.5:1 (muted ZCS pairs are designed for this — confirm at build).

**Do not convey by color alone** ✅ — every `.badge` has a text label (+ decorative dot); status,
delegate flag, "이름 미확인", audit 작업 all carry words/icons, not color only.

**Keyboard & focus**
- ✅ Inputs/selects/textarea/search show a visible focus ring (border `--accent` + 3px `--accent-weak`).
- ⚠️ **`.btn`, `.nav-item`, `.pg`, `.tab`, `.check`, `.icon-btn` define hover but NO `:focus-visible`
  style.** Keyboard users get only the browser default outline (often invisible on dark sidebar /
  cobalt fills). **Backport B1 (§7):** add a `:focus-visible` outline token for all interactive controls,
  with a **light variant** (`#8fa6e6`) for the dark sidebar so the ring is visible there.
- ✅ **Nested nav (CR-02):** group header is a real `<button>` with `aria-expanded`; **Enter/Space**
  toggles; the open/closed state is programmatically exposed. Active leaf carries `aria-current="page"`.
  Focus order follows visual order; collapsed groups remove their children from the tab order. The
  nested-nav override (§7 B7) ships the dark `:focus-visible` ring.
- ⚠️ **Clickable table rows** (`table.tbl tbody tr { cursor:pointer }`) are not keyboard-operable as
  drawn. Make the primary action a real focusable control in the row (the 강제 종료 / row-open button is
  already a `<button>`) or add `tabindex`/`role` + key handlers. **Backport B2 (§7):** row-affordance pattern.
- ✅ Modal/Drawer (incl. `MyInfoDrawer`): `role="dialog" aria-modal="true"`, Esc + backdrop dismiss;
  frontend must add focus trap + **return focus to the hamburger** that opened it.

**Forms**
- ✅ Required marked with `.req` (not color-only — include `*` and `aria-required`).
- ✅ Errors via `.field.error` + `.err-msg` with icon and text; associate `aria-describedby`,
  set `aria-invalid` on the control.
- ✅ Korean error copy is specific and actionable ("고유번호 형식을 확인해 주세요 (예: …)").

**Labels / aria**
- `MaskedValue` `.mreveal` and all `.icon-btn` / `.mx` / `.dx` need Korean `aria-label`
  (e.g. `aria-label="값 보기"`, `aria-label="닫기"`).
- **Hamburger** `HamburgerButton`: `aria-label="내 정보"`, `aria-haspopup="dialog"`, `aria-expanded`.
- **Logout** footer control: `aria-label="로그아웃"` if icon-only.
- `NoPermission` / `EmptyState` should be in a landmark/region with the title as heading.
- 고유번호 in `MyInfoDrawer` / tables needs SR context: `aria-label="고유번호 00341130-00036"`.
- Nav `<nav aria-label="주 메뉴">`; group toggles label the region they control.

**Motion**
- ⚠️ ZCS has `@keyframes` (spinner, toast, modal pop, qr sweep, oauth bar) — **plus the new nav
  collapse + chevron rotation (CR-02)** — with **no `prefers-reduced-motion` guard. Backport B3 (§7):**
  wrap non-essential animation in a reduced-motion media query (nav collapse becomes instant, chevron snaps).

**Target size** ✅ — 32px controls / 28px (`.btn.sm`, `.pg`) meet the 24px AA minimum; primary login
button is 50px. Keep `.pg` at ≥28px.

**No-dev-terminology check (house rule, treated as a11y/clarity gate)** ✅ — no permission codes, enum
values, internal IDs, schema field names, or the word "ZAuth" in any visible copy. `.np-code` removed.
고유번호 labeled 고유번호 and shown in full; 주민번호/idNumber never rendered.

---

## 6. Responsive / i18n

**Breakpoints (ZCS-native):**
- `≤ 980px`: `.grid-2/.grid-2b` collapse to one column; `.stat-strip` → 2 columns (ZCS default).
- `≤ 860px`: `.login` collapses to single column (`.login-brand` hidden) — login stays usable on mobile.
- Shell: the `212px` sidebar should collapse to an off-canvas drawer under ~860px. **Backport B4 (§7):**
  ZCS has no mobile shell pattern — define a hamburger + `.drawer`-style nav for narrow screens.
- Tables: wrap in `.tbl-wrap` (horizontal scroll) so 고유번호 (`white-space:nowrap`, never wraps) and
  action columns stay legible on small screens.

**i18n (Korean-only now, key-ready):**
- All visible text comes from a **single `ko` locale key file** (no hard-coded strings in components),
  so another language can be added later by adding a locale file — structure per the `i18n` skill
  (local-JSON in git, no external platform).
- Layouts must tolerate variable-length text: no fixed-width by character count; labels/buttons wrap or
  size to content; min-widths on inputs, not max truncation of essential copy.
- 고유번호 stays `.mono` + tabular (`.tnum`) and `white-space:nowrap` regardless of locale.
- Korean copy in this spec is written to read naturally (no AI-flavored Korean); final ko file values
  are humanized before delivery per house rule.

---

## 7. Proposed ZCS Backports

Gaps found while specifying this template. **Per CLAUDE.md §5 + CR-02, the vendored `frontend/zcs/` is
never edited.** Each addition is implemented in the **template override layer**
(`frontend/src/styles/zcs-a11y.css`) and *proposed upstream* to `zcs/zcs.css` so ZCS keeps completing
itself. We do **not** create a parallel kit; these extend ZCS in its own idiom and tokens.

| ID | Gap | Proposed addition (override layer → backport) | Rationale |
|---|---|---|---|
| **B1** | No `:focus-visible` ring on `.btn`, `.nav-item`, `.pg`, `.tab`, `.check`, `.icon-btn`, `.mreveal` | `*:focus-visible { outline:2px solid var(--accent); outline-offset:2px }` + a **dark-panel variant** (`#8fa6e6`) for `.sidebar` controls | Keyboard accessibility (WCAG 2.4.7). Inputs have it; controls don't. |
| **B2** | Clickable `table.tbl` rows aren't keyboard-operable | Row pattern: primary action is a focusable `<a>/<button>` in a cell; full-row click is a mouse-only enhancement | WCAG 2.1.1 keyboard operability. |
| **B3** | Animations lack a reduced-motion guard (now incl. nav collapse/chevron) | `@media (prefers-reduced-motion: reduce){ * { animation-duration:.001ms!important; transition:none } }` scoped to non-essential motion | WCAG 2.3.3 / vestibular safety. |
| **B4** | No mobile/off-canvas shell for `.sidebar` under ~860px | `.sidebar.is-open` off-canvas variant + topbar toggle (reuse `.drawer-overlay` dimming) | Console assumes desktop width; admin template needs a usable narrow layout. |
| **B5** | No dedicated QR **issuance** display block (`.qr-frame` exists only inside `.login`) | Generic `.qr-card` (login-frame look) usable outside `.login`, paired with `.alert.warning` | This template renders an admin-generated QR; ZCS only had login-auth QR. |
| **B6** | `.noperm .np-code` encourages showing a permission code | Make `.np-code` optional; end-user products render a plain-language hint, not a code | No-dev-terminology house rule. |
| **B7** *(CR-02)* | ZCS `.nav` has **no nested/collapsible group idiom** and nav rows show underlines | **Nested-nav class set** (override layer): `.nav-group`, `.nav-group-toggle` (+ `.nav-chev` rotate), `.nav-sub` (collapsible region), depth via `--nav-depth` (L2 26px / L3 40px) with a 1px guide line, active-trail left rail (`inset 2px 0 0 rgba(143,166,230,.5)`), active-leaf rail, and `text-decoration:none` reset on all nav controls. Keyboard: toggle `<button aria-expanded>`, Enter/Space, dark `:focus-visible`. | The sidebar needs ≥3-level config-driven nesting and a clean active state without underlines. |

---

## Component Name List (shared contract with frontend-builder)

1:1 component file ↔ ZCS markup. Frontend builds these as thin wrappers over vendored ZCS classes.

```
AppShell · Sidebar · NavTree (recursive) · NavGroup · NavItem · Topbar
HamburgerButton · MyInfoDrawer · LogoutButton
LoginScreen · ZionLoginButton
Button · IconButton
Field · TextField · TextArea · Select · InputWrap
DataTable · FilterBar · Pager
Modal · Drawer
Badge · Chip · Gem · MaskedValue
EmptyState · NoPermission · PageTitle · DefinitionList
Toast · Spinner · LoadBox · Alert
QrIssuePanel
Config: nav.ts (typed NavNode tree, ≥3 levels, per-node visible(ctx))
Pages: NoticesPage · NoticeFormModal · NoticeDetail · AccessManagementPage
       SessionsPage · ActivityLogPage · QrIssuePage (reference, unlinked)
```

> **CR-02 deltas:** Sidebar now renders `NavTree` recursively from `nav.ts` (no underlines; collapsible
> groups; ≥3 levels). Topbar loses the always-on 고유번호 chip + logout button, gains `HamburgerButton`
> → `MyInfoDrawer`. Logout moves to the sidebar footer (`LogoutButton`). New pages: `SessionsPage`,
> `ActivityLogPage` (both 보안·감사, super-admin only). `QrIssuePage` removed from nav (reference only).
> Nested-nav + a11y CSS live in `frontend/src/styles/zcs-a11y.css` (override layer), never in vendored ZCS.
