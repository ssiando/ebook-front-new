# Changelog — Zion Login canon retrofit (2026-07-05)

The template was retrofitted to the **Zion Login downstream canon**
(`review/zion-login-integrated/01_zion_login_canon.md`, now embedded at
`.claude/skills/zion-login-integrated`). What changed:

- **Session token.** The session token is now the **ZAuth-issued `access_token`
  itself**; the server stores only `SHA-256(token)` in the session row and never
  persists or logs the raw token. The self-issued HS256 JWT is gone —
  `JWT_SECRET` and `JWT_EXPIRE_MINUTES` no longer exist (absolute lifetime
  follows the token's `exp` claim). Sessions are periodically revalidated
  against Zion Login (`OAUTH2_VALIDATE_URL` = `{API_URL}/api/auth/v1_0/validate`,
  at most every `SESSION_REVALIDATE_SECONDS`, default 300), **fail-closed**: any
  non-valid outcome kills the session. Idle window, heartbeat, usage tracking,
  and the 세션 관리 screen are unchanged.
- **Super-admin detection.** The custom console authority
  `ZADMIN-TEMPLATE-SUPER` and the `SUPER_ADMIN_AUTHORITY` env are gone.
  Super-admin = holder of ZAuth's canonical global master authority
  **`DO_EVERYTHING`** (in `roleBased` permissions), detected once at login via
  user-authorities — the only use of that API. Bootstrap needs no console work
  and no DB seeding.
- **총회 registration prerequisites.** Only the `client_id` (REST API Key) is
  needed. No client_secret (unchanged), **no callback-URL console
  registration** (`redirect_uri` auto-detects from `X-Forwarded-Proto` + `Host`;
  `OAUTH2_REDIRECT_URI` remains an optional override), and **no custom
  authority registration**.
- **Embedded skill.** The Zion Login integrated canon skill lives at
  `.claude/skills/zion-login-integrated` and governs all
  login/auth/member-data/permission work; on conflict it wins.

**Older `_workspace/` documents were NOT rewritten.** Wherever
`00_input/request.md`, `01_pm_spec.md`, `02_design_system.md`,
`03_infra_env.md`, `04_review_report.md`, `05_qa_report.md`, or
`api_contracts.md` describe the HS256 session token / `JWT_SECRET` boot guard /
`ZADMIN-TEMPLATE-SUPER` / callback-URL registration, they reflect the
**pre-retrofit design**; this changelog and the README are authoritative.
